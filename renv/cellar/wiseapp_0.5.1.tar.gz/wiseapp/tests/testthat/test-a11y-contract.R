# Static accessibility contracts (WCAG 2.2 AA review findings in
# review/archive/REVIEW-2026-10-06.md section 9). These read custom.css and render UI
# fragments with htmltools, so they run without a browser.

a11y_css_rules <- function() {
  path <- file.path("..", "..", "inst", "app", "www", "custom.css")
  skip_if_not(file.exists(path), "custom.css not found")
  css <- paste(readLines(path, warn = FALSE), collapse = "\n")
  css <- gsub("(?s)/\\*.*?\\*/", "", css, perl = TRUE)
  m <- gregexpr("[^{}]+\\{[^{}]*\\}", css)[[1L]]
  rules <- regmatches(css, list(m))[[1L]]
  data.frame(
    selector = trimws(sub("\\{.*$", "", rules)),
    body = sub("^[^{]*\\{", "", sub("\\}\\s*$", "", rules)),
    stringsAsFactors = FALSE
  )
}

# Bodies of every rule whose selector list contains `selector` exactly.
a11y_css_bodies <- function(rules, selector) {
  hit <- vapply(strsplit(rules$selector, ","), function(s) {
    selector %in% trimws(gsub("\\s+", " ", s))
  }, logical(1))
  rules$body[hit]
}

# WCAG 2.x contrast ratio between two hex colours.
a11y_contrast <- function(fg, bg) {
  lum <- function(h) {
    v <- grDevices::col2rgb(h)[, 1] / 255
    v <- ifelse(v <= 0.03928, v / 12.92, ((v + 0.055) / 1.055)^2.4)
    sum(c(0.2126, 0.7152, 0.0722) * v)
  }
  l <- sort(c(lum(fg), lum(bg)), decreasing = TRUE)
  (l[1] + 0.05) / (l[2] + 0.05)
}

# `fg` composited at `alpha` over `bg`.
a11y_blend <- function(fg, bg, alpha) {
  f <- grDevices::col2rgb(fg)[, 1]
  b <- grDevices::col2rgb(bg)[, 1]
  grDevices::rgb(t(round(alpha * f + (1 - alpha) * b)), maxColorValue = 255)
}

a11y_decl <- function(bodies, prop) {
  m <- regmatches(bodies, regexpr(paste0("(^|[;\\s])", prop,
                                         ":\\s*[^;]+"), bodies, perl = TRUE))
  trimws(sub(paste0("^.*", prop, ":\\s*"), "", m))
}

test_that("CR-A11Y-01: info icons keep a visible keyboard focus outline", {
  rules <- a11y_css_rules()
  focus <- paste(a11y_css_bodies(rules, ".wise-info-icon:focus-visible"),
                 collapse = ";")
  expect_match(focus, "outline:\\s*2px solid")
  # No rule may strip the outline from the icon on focus.
  for (sel in c(".wise-info-icon:focus", ".wise-info-icon:focus-visible")) {
    expect_false(any(grepl("outline:\\s*(none|0)",
                           a11y_css_bodies(rules, sel))), info = sel)
  }
})

test_that("R2-A11Y-01: sidebar accordion headers keep a focus indicator", {
  rules <- a11y_css_rules()
  focus <- paste(
    a11y_css_bodies(rules, ".sidebar .accordion-button:focus-visible"),
    collapse = ";"
  )
  expect_match(focus, "outline:\\s*2px solid")
})

test_that("R2-A11Y-02: theme focus ring is a solid brand-blue ring", {
  local_mocked_bindings(get_golem_version = function(...) "0.0.0",
                        .package = "golem")
  deps <- htmltools::resolveDependencies(
    htmltools::findDependencies(app_ui(NULL))
  )
  bs <- Filter(function(d) identical(d$name, "bootstrap"), deps)
  skip_if(length(bs) == 0L, "bootstrap dependency not found")
  css_files <- file.path(bs[[1L]]$src$file, bs[[1L]]$stylesheet)
  css <- paste(unlist(lapply(css_files[file.exists(css_files)], readLines,
                             warn = FALSE)), collapse = "\n")
  # Inputs, selects and nav links: opaque 2px #0071bc, not a 25% alpha glow.
  expect_match(css, "\\.form-control:focus\\{[^}]*box-shadow:0 0 0 2px #0071bc",
               ignore.case = TRUE)
  expect_match(css, "\\.nav-link:focus-visible[^{]*\\{[^}]*box-shadow:0 0 0 2px #0071bc",
               ignore.case = TRUE)
  expect_match(css, "--bs-accordion-btn-focus-box-shadow: 0 0 0 2px #0071bc",
               ignore.case = TRUE)
})

test_that("R2-A11Y-02: buttons and selected pills meet 3:1 non-text contrast", {
  rules <- a11y_css_rules()
  btn <- paste(a11y_css_bodies(rules, "body .btn"), collapse = ";")
  expect_match(btn, "--bs-btn-focus-box-shadow:[^;]*4px var\\(--bs-primary")
  pill <- paste(
    a11y_css_bodies(rules, '.toggle-slider input[type="radio"]:checked + span'),
    collapse = ";"
  )
  expect_match(pill, "inset 0 0 0 1px var\\(--bs-primary")
})

test_that("CR-A11Y-02: small muted and status text reaches 4.5:1", {
  rules <- a11y_css_rules()
  # Text rules flagged in the review; all sit on white or near-white cards.
  sels <- c(".step1-headline-note", ".headline-card-note", ".diagnostic-note",
            ".wise-table .se", ".wise-table .t2-note", ".selection-card-op",
            ".selection-card-chevron", ".step2-summary-separator",
            ".pipeline-done", ".pipeline-failed")
  for (sel in sels) {
    col <- a11y_decl(a11y_css_bodies(rules, sel), "color")
    expect_length(col, 1L)
    expect_true(grepl("^#[0-9a-fA-F]{6}$", col), info = sel)
    expect_gte(a11y_contrast(col, "#f8fafc"), 4.5)
  }
  # Hero text is translucent white on a navy-to-blue gradient; check every
  # text rule against the lightest (last) gradient stop.
  bg <- a11y_css_bodies(rules, ".hero-panel")
  stops <- regmatches(bg, gregexpr("#[0-9a-fA-F]{6}", bg))[[1L]]
  lightest <- stops[length(stops)]
  for (sel in c(".hero-panel h1", ".hero-panel .hero-subtitle",
                ".hero-panel p", ".hero-panel .hero-team")) {
    op <- a11y_decl(a11y_css_bodies(rules, sel), "opacity")
    alpha <- if (length(op)) as.numeric(op) else 1
    expect_gte(a11y_contrast(a11y_blend("#ffffff", lightest, alpha),
                             lightest), 4.5)
  }
  link <- a11y_decl(a11y_css_bodies(rules, ".hero-panel a"), "color")
  expect_gte(a11y_contrast(link, lightest), 4.5)
})

test_that("CR-A11Y-04: unlabeled pill toggles are named by aria_label", {
  tag <- pill_toggle("x", choices = c(A = "a", B = "b"), aria_label = "Pick")
  expect_identical(tag$attribs[["aria-label"]], "Pick")
  expect_null(tag$attribs[["aria-labelledby"]])
  # A visible label keeps the native aria-labelledby association.
  tag <- pill_toggle("x", choices = c(A = "a"), label = "Shown",
                     aria_label = "Pick")
  expect_identical(tag$attribs[["aria-labelledby"]], "x-label")
  expect_null(tag$attribs[["aria-label"]])
  # Disabled pills go through the tree walk; the name must survive it.
  tag <- pill_toggle("x", choices = c(A = "a", B = "b"), disabled = TRUE,
                     aria_label = "Pick")
  expect_identical(tag$attribs[["aria-label"]], "Pick")
  tag <- wave_toggle_slider("w", choices = c(`2010` = "k1", `2015` = "k2"))
  expect_identical(tag$attribs[["aria-label"]], "Survey wave")
})

test_that("CR-A11Y-04: every label-less pill toggle in R/ passes aria_label", {
  srcs <- Sys.glob(file.path("..", "..", "R", "*.R"))
  skip_if(length(srcs) == 0, "R sources not found")
  bad <- character(0)
  walk <- function(e, file) {
    if (!is.call(e)) return(invisible(NULL))
    fn <- e[[1L]]
    nm <- if (is.symbol(fn)) as.character(fn) else ""
    if (nm %in% c("pill_toggle", "wave_toggle_slider")) {
      an <- names(as.list(e))
      if (is.null(an)) an <- rep("", length(e))
      # label is the fourth formal; count positional args to detect it.
      named <- an[-1L]
      pos <- sum(!nzchar(named))
      formals_left <- setdiff(c("inputId", "choices", "selected", "label"),
                              named)
      has_label <- "label" %in% named && !is.null(e[["label"]])
      if (!"label" %in% named && pos >= match("label", formals_left, 99L)) {
        has_label <- TRUE
      }
      if (!has_label && nm == "pill_toggle" && !"aria_label" %in% named) {
        bad <<- c(bad, paste(file, deparse(e)[1L]))
      }
    }
    for (i in seq_along(e)[-1L]) {
      a <- e[[i]]
      if (!missing(a) && is.call(a)) walk(a, file)
    }
    invisible(NULL)
  }
  for (f in srcs) {
    for (ex in parse(f, keep.source = FALSE)) walk(ex, basename(f))
  }
  expect_identical(bad, character(0), info = paste(bad, collapse = " | "))
})

test_that("CR-A11Y-04: slider focus targets get role and name in custom.js", {
  path <- file.path("..", "..", "inst", "app", "www", "custom.js")
  skip_if_not(file.exists(path), "custom.js not found")
  js <- paste(readLines(path, warn = FALSE), collapse = "\n")
  expect_match(js, "setAttribute('role', 'slider')", fixed = TRUE)
  expect_match(js, "aria-labelledby", fixed = TRUE)
  expect_match(js, "aria-valuenow", fixed = TRUE)
})

test_that("CR-A11Y-04: social protection select and slider have hidden labels", {
  src <- file.path("..", "..", "R", c("mod_3_01_sp.R", "fct_sp_ui.R"))
  skip_if_not(all(file.exists(src)), "R sources not found")
  code <- paste(unlist(lapply(src, readLines, warn = FALSE)), collapse = "\n")
  expect_match(code, 'visually-hidden", "Targeting"', fixed = TRUE)
  expect_match(code, 'visually-hidden", "Transfers per year"', fixed = TRUE)
})

test_that("R2-A11Y-05: skip link, main landmark and heading levels", {
  local_mocked_bindings(get_golem_version = function(...) "0.0.0",
                        .package = "golem")
  r <- htmltools::renderTags(app_ui(NULL))
  html <- as.character(r$html)
  # The skip link comes before the navbar and targets the main landmark.
  expect_lt(regexpr('class="skip-link" href="#main-content"', html, fixed = TRUE),
            regexpr("<nav", html, fixed = TRUE))
  expect_match(html, 'id="main-content" role="main" tabindex="-1"',
               fixed = TRUE)
  expect_identical(lengths(regmatches(html, gregexpr('role="main"', html))),
                   1L)
  # Theme and component dependencies survive the tagQuery rewrite.
  deps <- vapply(r$dependencies, `[[`, "", "name")
  expect_true(all(c("bootstrap", "bslib-component-js") %in% deps))
  # Headings no longer jump from h1 to h4/h5 on the step pages.
  expect_false(grepl("<h5", html, fixed = TRUE))
  expect_false(grepl('<h4 class="step-question"', html, fixed = TRUE))
  expect_match(html, '<h1 class="step-question"', fixed = TRUE)
  expect_match(as.character(welfare_equation_ui()), '<h2 class="h5"',
               fixed = TRUE)
})

test_that("R2-A11Y-05: connection status is a polite live region", {
  src <- file.path("..", "..", "R", "mod_0_overview.R")
  skip_if_not(file.exists(src), "R sources not found")
  code <- paste(readLines(src, warn = FALSE), collapse = "\n")
  hits <- gregexpr(
    'uiOutput\\(ns\\("connection_status_ui"\\),\\s*role = "status", `aria-live` = "polite"\\)',
    code
  )[[1L]]
  expect_equal(sum(hits > 0), 2L)
})

test_that("R2-A11Y-05: info icons and CSV buttons have specific names", {
  pop <- as.character(info_popover("Body", title = "Aggregation"))
  expect_match(pop, 'aria-label="More information: Aggregation"', fixed = TRUE)
  expect_match(as.character(info_popover("Body")),
               'aria-label="More information"', fixed = TRUE)
  btn <- as.character(wise_reactable_csv_button("t1", "step1_coef_table"))
  expect_match(btn, 'aria-label="Download CSV: step1 coef table"', fixed = TRUE)
})

test_that("CR-A11Y-05: map legend info markers expose a describing tooltip", {
  html <- .wx_info_marker("Share of days <b>above</b> the threshold")
  expect_match(html, 'role="tooltip"', fixed = TRUE)
  id <- sub('.*aria-describedby="([^"]+)".*', "\\1", html)
  expect_match(html, paste0('id="', id, '"'), fixed = TRUE)
  expect_match(html, "&lt;b&gt;above", fixed = TRUE)
  # Ids are unique across markers on one page
  ids <- vapply(1:3, function(i) {
    sub('.*aria-describedby="([^"]+)".*', "\\1", .wx_info_marker("x"))
  }, "")
  expect_equal(anyDuplicated(ids), 0L)
  expect_match(.wx_tip_css(), ".wx-tip-dismissed", fixed = TRUE)
  js <- paste(readLines(file.path("..", "..", "inst", "app", "www", "custom.js"),
                        warn = FALSE), collapse = "\n")
  expect_match(js, "wx-tip-dismissed", fixed = TRUE)
})

test_that("R2-A11Y-04: categorical series colours reach 3:1 on white", {
  lum <- function(h) {
    v <- grDevices::col2rgb(h)[, 1] / 255
    v <- ifelse(v <= 0.03928, v / 12.92, ((v + 0.055) / 1.055)^2.4)
    sum(v * c(0.2126, 0.7152, 0.0722))
  }
  ratio <- function(h) 1.05 / (lum(h) + 0.05)
  # Black and the brand blue pass trivially; check every series colour
  expect_true(all(vapply(.okabe_ito, ratio, 0) >= 3))
  # The marker colour is also used for 10 px text, which needs 4.5:1
  expect_gte(ratio(.wise_marker_alt), 4.5)
})

test_that("CR-A11Y-09: the page keeps its lang and theme attributes", {
  page <- bslib::page_navbar(title = "x", lang = "en", bslib::nav_panel("a", "b"))
  out <- add_main_landmark(page)
  expect_identical(attr(out, "lang"), "en")
  expect_false(is.null(attr(out, "bs_theme")))
  expect_identical(class(out), class(page))
})

test_that("CR-A11Y-09: custom.js repairs generated icon, tablist, table and separator markup", {
  js <- paste(readLines(file.path("..", "..", "inst", "app", "www", "custom.js"), warn = FALSE),
    collapse = "\n")
  expect_match(js, "i[role=\"presentation\"][aria-label]", fixed = TRUE)
  expect_match(js, "ul[role=\"tablist\"] > li", fixed = TRUE)
  expect_match(js, "a[data-bs-toggle=\"tab\"]:not([role])", fixed = TRUE)
  expect_match(js, ".rt-tr-group:not([role])", fixed = TRUE)
  expect_match(js, ".rt-no-data", fixed = TRUE)
  expect_match(js, "shown.bs.tab", fixed = TRUE)
  expect_match(js, "aria-valuenow", fixed = TRUE)
})

test_that("R2-A11Y-05/06: untitled info icons are named by JS and have 24 px hit areas", {
  www <- file.path("..", "..", "inst", "app", "www")
  js <- paste(readLines(file.path(www, "custom.js"), warn = FALSE), collapse = "\n")
  expect_match(js, "More information", fixed = TRUE)
  expect_match(js, "MutationObserver", fixed = TRUE)
  css <- paste(readLines(file.path(www, "custom.css"), warn = FALSE), collapse = "\n")
  expect_match(css, "\\.wise-info-icon::before\\s*\\{[^}]*inset:\\s*-8px", perl = TRUE)
  expect_match(.wx_tip_css(), ".wx-tip::before{content:'';position:absolute;inset:-6px;}",
               fixed = TRUE)
})
