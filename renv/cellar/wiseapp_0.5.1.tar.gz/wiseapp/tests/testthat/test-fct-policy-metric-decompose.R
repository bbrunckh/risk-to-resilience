annual_channel_fixture <- function(engine = "rif", binned = FALSE, transform = "none",
                                   zero_policy = FALSE, interaction = TRUE) {
  n <- 12L
  base <- data.frame(welfare = seq(1, 6, length.out = n),
    temp = seq(10, 21), rain = rep(1:3, 4), x = rep(0:1, 6),
    loc_id = rep(1:2, 6), int_month = rep(c(1L, 6L), 6),
    code = "BFA", year = "2018", survname = "wave-a", weight = seq_len(n))
  if (binned) base$temp <- factor(rep(c("low", "mid", "high"), 4))
  policy <- base
  if (!zero_policy) {
    policy$x <- 1
    policy[[SP_TRANSFER_COL]] <- seq(0.5, 3, length.out = n)
  }
  terms <- c(if (binned) c("tempmid", "temphigh") else "temp", "rain", "x")
  if (interaction) terms <- c(terms, if (binned) c("tempmid:x", "x:temphigh") else "x:temp", "rain:x")
  if (engine == "rif") {
    grid <- expand.grid(model = 3L, term = terms, tau = c(0.1, 0.5, 0.9),
      stringsAsFactors = FALSE)
    grid$estimate <- seq_len(nrow(grid)) / 100
    model <- list(engine = "rif", rif_grid = grid, taus = c(0.1, 0.5, 0.9),
      train_data = if (transform == "log") transform(base, welfare = log(welfare)) else base,
      weather_terms = c("temp", "rain"))
  } else {
    train <- expand.grid(temp = if (binned) levels(base$temp) else c(10, 30), rain = c(1, 3), x = 0:1)
    if (binned) train$temp <- factor(train$temp, levels = levels(base$temp))
    y <- 2 + as.numeric(train$temp) / 10 + train$rain / 20 + train$x / 5 +
      if (interaction) as.numeric(train$temp) * train$x / 50 + train$rain * train$x / 100 else 0
    train$welfare <- if (transform == "log") exp(y) else y
    lhs <- if (transform == "log") "log(welfare)" else "welfare"
    rhs <- if (interaction) "(temp + rain) * x" else "temp + rain + x"
    model <- list(engine = "fixest", fit3 = lm(as.formula(paste(lhs, "~", rhs)), train),
      train_data = train, weather_terms = c("temp", "rain"))
  }
  ctx <- .build_decomposition_context(base, policy, model,
    list(name = "welfare", transform = transform, type = "numeric"),
    skip_coef = TRUE, run_identity = "annual-run")
  ids <- rep(c(3L, 1L, 12L, 5L, 3L), 2)
  weather <- base[ids, c("code", "year", "survname", "loc_id", "int_month", "temp", "rain")]
  years <- rep(c(2030L, 2031L), each = 5)
  weather$timestamp <- as.Date(sprintf("%d-%02d-01", years, weather$int_month))
  if (binned) weather$temp <- factor(rep(c("high", "low", "mid", "high", "low"), 2), levels = levels(base$temp)) else {
    weather$temp <- seq(0, 45, length.out = length(ids))
  }
  weather$rain <- rep(c(0, 2, 8, 1, 10), 2)
  pipe <- list(y_point = rep(0, length(ids)), svy_row_id = ids, sim_year = years,
    weight = base$weight[ids], id_vec = ids)
  pipe$weather_exposure <- c(list(status = "ok", table = weather,
    row_index = seq_along(ids), prediction_row_id = seq_along(ids)),
    pipe[c("svy_row_id", "sim_year", "weight", "id_vec")])
  list(base = base, policy = policy, model = model, context = ctx, pipeline = pipe)
}

metric_channel_fixture <- function(engine = "rif", transform = "none", residuals = "none",
                                   zero_policy = FALSE, binned = FALSE) {
  fx <- annual_channel_fixture(engine, binned, transform, zero_policy)
  prepared <- .prepare_policy_annual_channels(fx$context, "annual-run")
  pipe <- fx$pipeline
  pipe$y_point <- seq(1, 2, length.out = length(pipe$y_point))
  shared <- step2_shared_context(data.frame(id = seq_len(12), .resid = seq(-0.2, 0.2, length.out = 12)), "id")
  hist <- list(pipeline = pipe, so = fx$context$so, shared_context = shared, residuals = residuals)
  policy <- .apply_policy_annual_pipeline(pipe, prepared, "annual-run")$pipeline
  policy_hist <- hist; policy_hist$pipeline <- policy
  list(fx = fx, prepared = prepared, hist = hist, policy_hist = policy_hist)
}
test_that("metric states use canonical aggregates and reconcile for all metrics and engines", {
  for (engine in c("fixest", "rif")) for (trans in c("none", "log")) {
    fx <- metric_channel_fixture(engine, trans)
    for (method in names(.WISE_METRIC_REGISTRY)) {
      result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
        fx$prepared, method, 3, "none")
      expect_identical(result$status, "ok", info = paste(engine, trans, method, result$reason))
      actual <- aggregate_pipeline_per_year(fx$hist$pipeline, method, pov_line = 3,
        residuals = "none", is_log = trans == "log", skip_coef = TRUE,
        shared_context = fx$hist$shared_context)
      expect_equal(result$annual$baseline, vapply(actual, `[[`, numeric(1), "value"))
      actual_policy <- aggregate_pipeline_per_year(fx$policy_hist$pipeline, method, pov_line = 3,
        residuals = "none", is_log = trans == "log", skip_coef = TRUE,
        shared_context = fx$hist$shared_context)
      expect_equal(result$annual$policy, vapply(actual_policy, `[[`, numeric(1), "value"))
      expect_equal(result$annual$total, result$annual$main + result$annual$repositioning + result$annual$interaction)
      expect_equal(result$summary$total, result$summary$policy - result$summary$baseline)
      decile_annual <- result$scenarios[["Historical"]]$decile_annual
      expect_true(all(c("decile", "baseline", "after_main", "after_repositioning",
        "policy", "main", "repositioning", "interaction", "resilience", "total") %in%
        names(decile_annual)))
      expect_equal(decile_annual$total,
        decile_annual$main + decile_annual$repositioning + decile_annual$interaction)
    }
  }
})


test_that("metric states match the aggregated policy arm under residuals with a covariate lever and a transfer (DOC-11)", {
  for (mode in c("original", "resample")) for (method in c("mean", "headcount_ratio", "gini")) {
    fx <- metric_channel_fixture("fixest", "log", mode)
    expect_true(!is.null(fx$policy_hist$pipeline$sp_level))
    result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
      fx$prepared, method, 3, mode)
    expect_identical(result$status, "ok", info = result$reason)
    actual <- aggregate_pipeline_per_year(fx$policy_hist$pipeline, method, pov_line = 3,
      residuals = mode, is_log = TRUE, skip_coef = TRUE, shared_context = fx$hist$shared_context)
    expect_equal(result$annual$policy, vapply(actual, `[[`, numeric(1), "value"),
      info = paste(mode, method))
  }
})

test_that("level channels add the transfer once, with a covariate lever (DOC-11)", {
  fx <- metric_channel_fixture("fixest", "log", "none")
  base <- fx$hist$pipeline
  ch <- .policy_annual_channels(base, fx$prepared, "annual-run")
  tr <- fx$fx$policy[[SP_TRANSFER_COL]][base$svy_row_id]
  lvl <- exp(base$y_point)
  lc <- .policy_level_channels(ch, TRUE, lvl)
  covar <- ch$delta_main_covar
  expect_gt(max(abs(covar)), 0)
  expect_equal(lc[, 1], lvl * (exp(covar) - 1) + tr)
  expect_equal(lc[, 4], lvl * (exp(covar + ch$delta_res1 + ch$delta_res2) - 1) + tr)
  expect_equal(lc[, 1] + lc[, 2] + lc[, 3] + lc[, 5], lc[, 4])
  res <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
    fx$prepared, "mean", 3, "none")
  w <- base$weight
  by_year <- vapply(split(seq_along(w), base$sim_year), function(i) stats::weighted.mean(lc[i, 4], w[i]), 1)
  expect_equal(unname(by_year), res$annual$total)
})

test_that("the quantile model adds the transfer after repositioning (DOC-11)", {
  fx <- metric_channel_fixture("rif", "log", "original")
  expect_false(is.null(fx$policy_hist$pipeline$sp_level))
  base <- fx$hist$pipeline
  ch <- .policy_annual_channels(base, fx$prepared, "annual-run")
  tr <- fx$fx$policy[[SP_TRANSFER_COL]][base$svy_row_id]
  expect_gt(max(abs(ch$delta_res1 + ch$delta_res2)), 0)
  oracle <- exp(base$y_point + ch$delta_main_covar + ch$delta_res1 + ch$delta_res2) + tr
  pol <- fx$policy_hist$pipeline
  expect_equal(exp(pol$y_point - pol$sp_log) + pol$sp_level, oracle)
  for (method in c("mean", "headcount_ratio", "gini")) {
    result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
      fx$prepared, method, 3, "none")
    expect_identical(result$status, "ok", info = result$reason)
    actual <- aggregate_pipeline_per_year(pol, method, pov_line = 3, residuals = "none",
      is_log = TRUE, skip_coef = TRUE, shared_context = fx$hist$shared_context)
    expect_equal(result$annual$policy, vapply(actual, `[[`, numeric(1), "value"), info = method)
  }
  lc <- .policy_level_channels(ch, TRUE, exp(base$y_point))
  expect_equal(lc[, 4], oracle - exp(base$y_point))
  fx <- metric_channel_fixture("fixest", "none", "original")
  expect_null(fx$policy_hist$pipeline$sp_level)
})

test_that("adverse support interpolates deterministic year keys and fails closed", {
  low <- adverse_year_support(1:20, 2030:2049, .05, "low")
  high <- adverse_year_support(1:20, 2030:2049, .05, "high")
  expect_equal(low$baseline_value, 1.5)
  expect_equal(high$baseline_value, 19.5)
  expect_equal(c(low$year_lo, low$year_hi), c(2030, 2031))
  expect_equal(c(low$weight_lo, low$weight_hi), c(.5, .5))
  tied <- adverse_year_support(c(1, 1, 2:19), 2049:2030, .05, "low")
  expect_equal(tied$year_lo, 2048)
  expect_equal(apply_adverse_year_support(c(NA, 4), c(2030, 2031), low)$status, "unavailable")
  expect_equal(adverse_year_support(1:19, 2030:2048, .05, "low")$status, "unavailable")
  expect_equal(adverse_year_support(c(NA_real_, NA_real_), 2030:2031, .05, "low")$n_years_excluded, 2L)
})

test_that("one residual realization is reused across states and compact shared context resolves", {
  for (engine in c("fixest", "rif")) for (trans in c("none", "log")) {
    for (mode in c("none", "original", "resample")) {
      fx <- metric_channel_fixture(engine, trans, mode, zero_policy = TRUE)
      result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
        fx$prepared, "mean", requested_residuals = mode)
      expect_identical(result$status, "ok")
      expect_equal(result$annual$total, c(0, 0))
      expect_equal(result$annual$main, c(0, 0))
      expect_identical(unique(result$annual$effective_residuals), mode)
      canonical <- aggregate_pipeline_per_year(fx$hist$pipeline, "mean", residuals = mode,
        is_log = trans == "log", skip_coef = TRUE, shared_context = fx$hist$shared_context)
      expect_equal(result$annual$baseline, vapply(canonical, `[[`, numeric(1), "value"))
    }
  }
  fx <- metric_channel_fixture()
  fx$hist$shared_context <- fx$policy_hist$shared_context <- list(train_aug = data.frame(id = 1:12))
  for (mode in c("original", "resample")) {
    result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(), fx$prepared,
      "mean", requested_residuals = mode)
    expect_identical(result$status, "ok")
    expect_identical(result$metadata$effective_residuals, "none")
    for (skip_coef in c(TRUE, FALSE)) {
      canonical <- aggregate_pipeline_per_year(fx$hist$pipeline, "mean", residuals = mode,
        is_log = FALSE, skip_coef = skip_coef, shared_context = fx$hist$shared_context)
      expect_equal(result$annual$baseline, vapply(canonical, `[[`, numeric(1), "value"))
    }
  }
})

test_that("baseline-anchored supports reuse ranks and average models equally", {
  annual <- data.frame(model_id = rep(c("a", "b", "c"), c(50, 40, 20)),
    sim_year = c(1:50, 1:40, 1:20), baseline = c(1:50, 1:40, 1:20))
  annual$after_static_main <- annual$baseline + rep(c(0.5, 4, -3), c(50, 40, 20))
  annual$after_main <- annual$after_static_main + rep(c(0.5, 1, 1), c(50, 40, 20))
  annual$after_repositioning <- annual$after_main + rev(annual$baseline) / 10
  annual$policy <- annual$after_repositioning + sin(annual$sim_year) * 5
  annual <- .policy_metric_contributions(annual)
  summary <- .policy_metric_summary(annual, "future")
  expect_equal(summary$baseline, mean(c(mean(1:50), mean(1:40), mean(1:20))))
  expect_false(isTRUE(all.equal(summary$baseline, mean(annual$baseline))))
  for (tail in c("low", "high")) {
    result <- .policy_metric_tails(annual, "future", tail)
    valid <- result[result$status == "ok", ]
    expect_equal(valid$total, valid$main + valid$sp_shock + valid$repositioning + valid$interaction)
    expect_equal(valid$total, valid$policy - valid$baseline)
    expect_true(all(result$status[result$return_period == 50] == "unavailable"))
    expect_true(all(result$scope == "baseline_anchored"))
    q <- valid[valid$scope == "baseline_anchored" & valid$return_period == 20, ]
    by_model <- attr(result, "adverse_by_model")
    rows <- by_model[by_model$return_period == 20 & by_model$status == "ok", ]
    expect_equal(q$total, mean(rows$total))
    expect_equal(q$baseline, mean(rows$baseline))
    expect_equal(q$total, q$main + q$sp_shock + q$repositioning + q$interaction)
    expect_true(all(attr(result, "adverse_support")$adverse_basis == "baseline_selected_metric"))
  }
})

test_that("endpoint parity failures preserve independent Results summaries and never alter support", {
  fx <- metric_channel_fixture()
  aggregate <- function(hist) list(Historical = list(out = aggregate_pipeline_table(
    hist$pipeline, "mean", residuals = "none", is_log = FALSE, skip_coef = TRUE,
    model_ids = "Historical")))
  b <- aggregate(fx$hist); p <- aggregate(fx$policy_hist)
  run <- function(prepared = fx$prepared, policy = fx$policy_hist) .policy_metric_decomposition(
    fx$hist, policy, list(), list(), prepared, "mean", requested_residuals = "none",
    endpoint_series_baseline = b, endpoint_series_policy = p)
  expect_identical(run()$status, "ok")
  missing <- run(NULL)
  expect_identical(missing$status, "unavailable")
  expect_equal(missing$endpoint_summary$value, run()$summary$total)
  bad <- fx$policy_hist; bad$pipeline$y_point[1] <- bad$pipeline$y_point[1] + 1
  mismatch <- run(policy = bad)
  expect_identical(mismatch$status, "unavailable")
  expect_match(mismatch$reason, "Final cumulative state")
  expect_equal(mismatch$endpoint_summary, run()$endpoint_summary)
  bad <- fx$policy_hist; bad$pipeline$weight <- rev(bad$pipeline$weight)
  expect_identical(run(policy = bad)$status, "unavailable")
  b$Historical$out$value_all[[1L]] <- 999
  expect_match(run()$reason, "endpoint baseline aggregate parity")
})

test_that("mechanisms remain model scale and preserve bins, ranks and missing engine channels", {
  for (engine in c("fixest", "rif")) {
    fx <- metric_channel_fixture(engine, binned = TRUE)
    result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
      fx$prepared, "headcount_ratio", 3, "none")
    expect_identical(result$status, "ok")
    expect_true(all(result$mechanisms$annual$scale == "model_scale"))
    expect_true(any(result$mechanisms$annual$contrast == "fitted_reference_category_contrast"))
    category_units <- result$mechanisms$annual$weather_units[
      result$mechanisms$annual$contrast == "fitted_reference_category_contrast"]
    expect_true(all(category_units == "category contrast; no per-unit slope"))
    if (engine == "fixest") {
      expect_true(all(is.na(result$mechanisms$annual$repositioning)))
      expect_identical(result$mechanisms$repositioning_status, "Not modeled by this engine")
    } else {
      expect_equal(result$mechanisms$fitted_curve, fx$prepared$context$rif_grid)
      expect_true(any(result$mechanisms$annual$tau_pre != result$mechanisms$annual$tau_post))
    }
  }
})

test_that("strict poverty crossings and changing inverse-welfare eligibility remain canonical", {
  fx <- metric_channel_fixture("fixest")
  pipe <- fx$hist$pipeline
  # Three equally weighted rows per year, first household crosses exactly to 3.
  keep <- c(1L, 2L, 3L, 6L, 7L, 8L)
  for (field in c("y_point", "svy_row_id", "sim_year", "id_vec")) pipe[[field]] <- pipe[[field]][keep]
  pipe$y_point <- rep(c(2, 3, 4), 2)
  pipe$weight <- NULL
  for (field in c("row_index", "prediction_row_id", "svy_row_id", "sim_year", "id_vec")) {
    pipe$weather_exposure[[field]] <- pipe$weather_exposure[[field]][keep]
  }
  pipe$weather_exposure$weight <- NULL
  values <- as.list(fx$prepared)
  values$delta_main <- rep(0, fx$prepared$context$n)
  values$delta_main[pipe$svy_row_id[1L]] <- 1
  for (v in names(values$products)) {
    values$products[[v]]$interaction[] <- 0
    values$products[[v]]$repositioning[] <- 0
  }
  prepared <- list2env(values, parent = emptyenv()); lockEnvironment(prepared, bindings = TRUE)
  fx$hist$pipeline <- pipe
  fx$policy_hist$pipeline <- .apply_policy_annual_pipeline(pipe, prepared, "annual-run")$pipeline
  result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
    prepared, "headcount_ratio", 3, "none")
  expect_identical(result$status, "ok")
  expect_equal(result$annual$baseline, rep(1 / 3, 2))
  expect_equal(result$annual$policy, c(0, 0))
  expect_equal(result$summary$main, -1 / 3)
  expect_match(format_metric_value(result$summary$main, result$metadata, change = TRUE), "33.33 pp")
  pipe$y_point <- rep(c(-0.5, 3, 4), 2)
  fx$hist$pipeline <- pipe
  fx$policy_hist$pipeline <- .apply_policy_annual_pipeline(pipe, prepared, "annual-run")$pipeline
  inverse <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(),
    prepared, "avg_poverty", requested_residuals = "none")
  expect_identical(inverse$status, "ok")
  expect_equal(inverse$annual$excluded_baseline, c(1L, 1L))
  expect_equal(inverse$annual$excluded_policy, c(0L, 0L))
  expect_equal(inverse$summary$total, inverse$summary$main)
})

test_that("member exposures and dropped endpoint support are not confused across scenarios", {
  fx <- metric_channel_fixture()
  second <- fx$hist$pipeline
  second$weather_exposure$table$temp <- second$weather_exposure$table$temp * 2
  owners <- list(future = list(pipelines = list(a = fx$hist$pipeline, b = second),
    shared_context = fx$hist$shared_context, so = fx$hist$so))
  policy <- owners
  policy$future$pipelines <- lapply(owners$future$pipelines, function(x) {
    .apply_policy_annual_pipeline(x, fx$prepared, "annual-run")$pipeline
  })
  endpoint <- function(owner) list(future = list(out = aggregate_pipeline_table(
    owner$future$pipelines, "mean", residuals = "none", is_log = FALSE,
    skip_coef = TRUE, model_ids = c("a", "b"))))
  b <- endpoint(owners); p <- endpoint(policy)
  run <- function() .policy_metric_decomposition(fx$hist, fx$policy_hist, owners, policy,
    fx$prepared, "mean", requested_residuals = "none", endpoint_series_baseline = b,
    endpoint_series_policy = p)
  actual <- run()
  expect_identical(actual$status, "ok")
  expect_identical(actual$metadata$focus_scenario, "future")
  expect_false(isTRUE(all.equal(actual$annual$total[actual$annual$member == "a"],
    actual$annual$total[actual$annual$member == "b"])))
  expect_equal(actual$summary$total[actual$summary$scenario == "future"], actual$endpoint_summary$value)
  p$future$out$value_all[[1L]][2L] <- NA_real_
  actual <- run()
  expect_identical(actual$status, "ok")
  expect_equal(actual$summary$n_dropped_model_years[actual$summary$scenario == "future"], 1L)
  expect_equal(actual$summary$total[actual$summary$scenario == "future"], actual$endpoint_summary$value)
})

test_that("unselected policy missingness does not change baseline adverse support", {
  fx <- metric_channel_fixture()
  pipe <- fx$hist$pipeline
  # Retain exact row anchors but expand their valid calendar years to 20 years.
  repeat_rows <- rep(seq_len(5), 20)
  for (field in c("y_point", "svy_row_id", "weight", "id_vec")) pipe[[field]] <- pipe[[field]][repeat_rows]
  pipe$sim_year <- rep(2030:2049, each = 5)
  pipe$y_point <- rep(seq(1, 20), each = 5)
  weather <- pipe$weather_exposure$table[repeat_rows, ]
  weather$timestamp <- as.Date(sprintf("%d-%02d-01", pipe$sim_year, weather$int_month))
  pipe$weather_exposure <- c(list(status = "ok", table = weather,
    row_index = seq_along(repeat_rows), prediction_row_id = seq_along(repeat_rows)),
    pipe[c("svy_row_id", "sim_year", "weight", "id_vec")])
  fx$hist$pipeline <- pipe
  fx$policy_hist$pipeline <- .apply_policy_annual_pipeline(pipe, fx$prepared, "annual-run")$pipeline
  agg <- function(hist) list(Historical = list(out = aggregate_pipeline_table(hist$pipeline,
    "mean", residuals = "none", is_log = FALSE, skip_coef = TRUE, model_ids = "Historical")))
  b <- agg(fx$hist); p <- agg(fx$policy_hist)
  # Missing policy year drops that year from paired expected support, not baseline thresholds.
  p$Historical$out$value_all[[1]][1] <- NA_real_
  result <- .policy_metric_decomposition(fx$hist, fx$policy_hist, list(), list(), fx$prepared,
    "mean", requested_residuals = "none", endpoint_series_baseline = b, endpoint_series_policy = p)
  expect_identical(result$status, "ok")
  expect_equal(result$summary$n_model_years, 19L)
  expected <- result$return_period[result$return_period$scope == "baseline_anchored" &
    result$return_period$return_period == 5, ]
  expect_identical(expected$status, "ok")
  expect_true(is.finite(expected$total))
  expect_true(all(result$return_period$scope == "baseline_anchored"))
})

test_that("R2-PERF-06: metric decomposition is memoised per method and poverty line", {
  fx <- metric_channel_fixture("fixest")
  fx$hist$residuals <- "none"
  fx$policy_hist$residuals <- "none"
  technical <- list2env(as.list(fx$prepared$context), parent = emptyenv())
  lockEnvironment(technical, bindings = TRUE)
  calls <- 0L
  original <- .policy_metric_decomposition
  local_mocked_bindings(
    .policy_metric_decomposition = function(...) {
      calls <<- calls + 1L
      original(...)
    }, .package = "wiseapp")
  api <- NULL
  shiny::testServer(function(input, output, session) {
    api <<- .wire_results_pane(input, output, session,
      shiny::reactive(fx$hist), shiny::reactive(list()),
      shiny::reactive(fx$policy_hist), shiny::reactive(list()),
      selected_hist = shiny::reactive(NULL), residuals = shiny::reactive("resample"),
      decomp_context = shiny::reactive(technical), annual_channels = shiny::reactive(fx$prepared))
  }, {
    session$setInputs(cmp_agg_method = "mean")
    mean_first <- api$metric_decomposition()
    expect_identical(calls, 1L)
    session$setInputs(cmp_agg_method = "headcount_ratio", cmp_pov_line = 3)
    session$elapse(500); session$flushReact()
    pov3 <- api$metric_decomposition()
    expect_identical(calls, 2L)
    session$setInputs(cmp_pov_line = 5)
    session$elapse(500); session$flushReact()
    api$metric_decomposition()
    expect_identical(calls, 3L)
    # Revisits are served from the cache, bit-identical to the first result.
    session$setInputs(cmp_agg_method = "mean")
    session$elapse(500); session$flushReact()
    expect_identical(api$metric_decomposition(), mean_first)
    session$setInputs(cmp_agg_method = "headcount_ratio", cmp_pov_line = 3)
    session$elapse(500); session$flushReact()
    expect_identical(api$metric_decomposition(), pov3)
    expect_identical(calls, 3L)
  })
})

test_that("R2-PERF-06b: exposure validation runs once per member per run and results are unchanged", {
  fx <- metric_channel_fixture("fixest")
  fx$hist$residuals <- "none"
  fx$policy_hist$residuals <- "none"
  calls <- 0L
  original <- .validate_policy_annual_exposure
  local_mocked_bindings(
    .validate_policy_annual_exposure = function(...) { calls <<- calls + 1L; original(...) },
    .package = "wiseapp")
  run <- function(method, cache) .policy_metric_decomposition(fx$hist, fx$policy_hist,
    list(), list(), fx$prepared, method, 3, "none", validation_cache = cache)
  cache <- new.env(parent = emptyenv())
  first <- run("mean", cache)
  after_first <- calls
  expect_gt(after_first, 0L)
  second <- run("headcount_ratio", cache)
  expect_identical(calls, after_first)
  expect_identical(first, run("mean", NULL))
  expect_identical(second$status, "ok")
  expect_identical(second, run("headcount_ratio", NULL))
})

test_that("the real shared Results calculation follows edits without re-preparing or predicting", {
  fx <- metric_channel_fixture("fixest")
  fx$hist$residuals <- "none"
  fx$policy_hist$residuals <- "none"
  local_mocked_bindings(
    .prepare_policy_annual_channels = function(...) stop("channel preparation forbidden"),
    run_sim_pipeline = function(...) stop("prediction rerun forbidden"),
    predict_outcome = function(...) stop("prediction rerun forbidden"),
    .package = "wiseapp")
  # Published technical context may be a finalized clone of the prepared source.
  technical <- list2env(as.list(fx$prepared$context), parent = emptyenv())
  lockEnvironment(technical, bindings = TRUE)
  api <- NULL
  shiny::testServer(function(input, output, session) {
    api <<- .wire_results_pane(input, output, session,
      shiny::reactive(fx$hist), shiny::reactive(list()),
      shiny::reactive(fx$policy_hist), shiny::reactive(list()),
      selected_hist = shiny::reactive(NULL), residuals = shiny::reactive("resample"),
      decomp_context = shiny::reactive(technical), annual_channels = shiny::reactive(fx$prepared))
  }, {
    session$setInputs(cmp_agg_method = "mean")
    result <- api$metric_decomposition()
    expect_identical(result$status, "ok")
    expect_true(is.finite(api$expected_paired_effect_summary()$value))
    expect_identical(result$metadata$requested_residuals, "none")
    session$setInputs(cmp_agg_method = "headcount_ratio", cmp_pov_line = 3)
    session$elapse(500); session$flushReact()
    poverty <- api$metric_decomposition()
    expect_identical(poverty$status, "ok")
    expect_true(is.finite(api$expected_paired_effect_summary()$value))
    session$setInputs(cmp_pov_line = 5)
    session$elapse(500); session$flushReact()
    edited <- api$metric_decomposition()
    expect_identical(edited$status, "ok")
    expect_equal(edited$metadata$threshold_value, 5)
    expect_true(is.finite(api$expected_paired_effect_summary()$value))
    expect_equal(edited$mechanisms$summary, poverty$mechanisms$summary)
  })
})

test_that("annual continuous and category channels equal explicit reference row by row", {
  for (engine in c("fixest", "rif")) for (binned in c(FALSE, TRUE)) for (trans in c("none", "log")) {
    fx <- annual_channel_fixture(engine, binned, trans)
    p <- .prepare_policy_annual_channels(fx$context, "annual-run")
    expect_true(environmentIsLocked(p))
    actual <- .policy_annual_channels(fx$pipeline, p, "annual-run")
    reference <- .policy_annual_channels_reference(fx$pipeline, fx$context, "annual-run")
    for (field in grep("^delta_", names(reference), value = TRUE)) {
      expect_equal(actual[[field]], reference[[field]], tolerance = 1e-12)
    }
    expect_equal(actual$delta_total, actual$delta_main + actual$delta_res1 + actual$delta_res2)
    expect_identical(actual$repositioning_modeled, engine == "rif")
    expect_true(actual$interaction_included)
    expect_false(any(grepl("^sd_", names(actual))))
    block <- .policy_annual_channels(fx$pipeline, p, "annual-run", rows = c(10L, 1L, 3L))
    expect_equal(block$delta_total, actual$delta_total[c(10L, 1L, 3L)])
    expect_identical(fx$pipeline$y_point, rep(0, 10))
  }
})

test_that("weather channels act on the change from survey-time weather (R2-BUG-06)", {
  for (engine in c("fixest", "rif")) for (binned in c(FALSE, TRUE)) {
    fx <- annual_channel_fixture(engine, binned, "none")
    p <- .prepare_policy_annual_channels(fx$context, "annual-run")
    # Exposure equal to each household's own survey weather: no weather change,
    # so repositioning and interaction must vanish.
    pipe <- fx$pipeline
    tab <- pipe$weather_exposure$table
    ids <- pipe$svy_row_id
    for (v in c("temp", "rain")) tab[[v]] <- fx$base[[v]][ids]
    pipe$weather_exposure$table <- tab
    same <- .policy_annual_channels(pipe, p, "annual-run")
    expect_equal(same$delta_res1, rep(0, length(ids)), tolerance = 1e-12)
    expect_equal(same$delta_res2, rep(0, length(ids)), tolerance = 1e-12)
    expect_equal(same$delta_total, same$delta_main, tolerance = 1e-12)
    ref <- .policy_annual_channels_reference(pipe, fx$context, "annual-run")
    expect_equal(ref$delta_res1, rep(0, length(ids)), tolerance = 1e-12)
    expect_equal(ref$delta_res2, rep(0, length(ids)), tolerance = 1e-12)
  }
})

test_that("log-outcome transfer is realised against the predicted year-t level (R2-BUG-07)", {
  for (engine in c("fixest", "rif")) {
    fx <- annual_channel_fixture(engine, transform = "log")
    p <- .prepare_policy_annual_channels(fx$context, "annual-run")
    pipe <- fx$pipeline
    pipe$y_point <- seq(-0.5, 2.5, length.out = length(pipe$y_point))
    out <- .policy_annual_channels(pipe, p, "annual-run")
    transfer <- fx$policy[[SP_TRANSFER_COL]][pipe$svy_row_id]
    expect_equal(exp(pipe$y_point + out$delta_sp) - exp(pipe$y_point), transfer,
      tolerance = 1e-10)
    expect_equal(out$delta_main, out$delta_sp + out$delta_main_covar)
    expect_equal(out$delta_total, out$delta_main + out$delta_res1 + out$delta_res2)
    ref <- .policy_annual_channels_reference(pipe, fx$context, "annual-run")
    for (field in grep("^delta_", names(ref), value = TRUE)) {
      expect_equal(out[[field]], ref[[field]], tolerance = 1e-12)
    }
    # Missing prediction: falls back to the observed-baseline effect.
    pipe$y_point[2] <- NA_real_
    na <- .policy_annual_channels(pipe, p, "annual-run")
    expect_equal(na$delta_sp[2], p$delta_sp[pipe$svy_row_id[2]])
  }
})

test_that("zero policy gives zero annual channels", {
  for (engine in c("fixest", "rif")) {
    fx <- annual_channel_fixture(engine)
    zero <- annual_channel_fixture(engine, zero_policy = TRUE)
    out <- .policy_annual_channels(zero$pipeline,
      .prepare_policy_annual_channels(zero$context, "annual-run"), "annual-run")
    expect_equal(out$delta_total, rep(0, 10))
    expect_equal(out$delta_res1, rep(0, 10))
    expect_equal(out$delta_res2, rep(0, 10))
  }
})

test_that("rows with missing outcome or lever values are untreated and counted (R2-BUG-13)", {
  for (engine in c("fixest", "rif")) for (transform in c("none", "log")) {
    fx <- annual_channel_fixture(engine, transform = transform)
    clean <- .policy_annual_channels(fx$pipeline,
      .prepare_policy_annual_channels(fx$context, "annual-run"), "annual-run")
    base <- fx$base
    base$welfare[12] <- NA # missing outcome
    base$x[3] <- NA        # missing lever covariate (policy sets x = 1)
    ctx <- .build_decomposition_context(base, fx$policy, fx$model,
      list(name = "welfare", transform = transform, type = "numeric"),
      skip_coef = TRUE, run_identity = "annual-run")
    expect_identical(ctx$n_na_untreated, 2L)
    prepared <- .prepare_policy_annual_channels(ctx, "annual-run")
    expect_identical(prepared$status, "ok", info = paste(engine, transform))
    out <- .policy_annual_channels(fx$pipeline, prepared, "annual-run")
    na_rows <- fx$pipeline$svy_row_id %in% c(3L, 12L)
    expect_equal(out$delta_total[na_rows], rep(0, sum(na_rows)))
    expect_equal(out$delta_total[!na_rows], clean$delta_total[!na_rows],
      info = paste(engine, transform))
  }
  expect_identical(annual_channel_fixture("fixest")$context$n_na_untreated, 0L)
})

test_that("same household ranks stay fixed while annual hazard protection varies", {
  fx <- annual_channel_fixture()
  p <- .prepare_policy_annual_channels(fx$context, "annual-run")
  out <- .policy_annual_channels(fx$pipeline, p, "annual-run")
  expect_equal(out$delta_main[1], out$delta_main[6])
  expect_false(isTRUE(all.equal(out$delta_res1[1], out$delta_res1[6])))
  expect_identical(p$tau_i_pre, fx$context$tau_i_pre)
  expect_identical(p$tau_i_post, fx$context$tau_i_post)
  # R2-BUG-06: row 1 has weather 0 against survey temp 12 (sample row 3), so the
  # anchored weather change is non-zero; the reference implementation agrees.
  ref <- .policy_annual_channels_reference(fx$pipeline, fx$context, "annual-run")
  expect_equal(out$delta_res1[1], ref$delta_res1[1], tolerance = 1e-12)
  expect_true(any(p$products$temp$repositioning != 0))
})

test_that("annual adapter rejects missing, stale, mismatched and invalid exposure context", {
  fx <- annual_channel_fixture(binned = TRUE)
  p <- .prepare_policy_annual_channels(fx$context, "annual-run")
  run <- function(pipe) .policy_annual_channels(pipe, p, "annual-run")
  expect_error(.prepare_policy_annual_channels(fx$context, "stale"), "run identity mismatch")
  expect_error(.policy_annual_channels(fx$pipeline, p, "stale"), "run identity mismatch")
  bad <- fx$pipeline; bad$weather_exposure <- NULL
  expect_error(run(bad), "mapping unavailable")
  for (field in c("svy_row_id", "sim_year", "weight", "id_vec")) {
    bad <- fx$pipeline; bad[[field]] <- rev(bad[[field]])
    expect_error(run(bad), "ordering mismatch")
  }
  bad <- fx$pipeline; bad$weather_exposure$table$temp <- as.character(bad$weather_exposure$table$temp)
  expect_error(run(bad), "invalid weather category")
  bad <- fx$pipeline; bad$weather_exposure$table$rain[1] <- NA
  expect_error(run(bad), "Missing exact weather")
  bad <- fx$pipeline; bad$weather_exposure$table$survname[1] <- "wrong-wave"
  expect_error(run(bad), "survey identity mismatch")
  bad <- fx$pipeline; bad$weather_exposure$table$timestamp[1] <- as.Date("2000-01-01")
  expect_error(run(bad), "anchor does not match")
  bad <- fx$pipeline; bad$weather_exposure$prediction_row_id[2] <- 1L
  expect_error(run(bad), "Invalid prediction-row")
  bad <- fx$pipeline; bad$svy_row_id[1] <- 999L; bad$weather_exposure$svy_row_id <- bad$svy_row_id
  expect_error(run(bad), "Invalid prediction-row")
  expect_error(.policy_annual_channels(fx$pipeline, p, "annual-run", c(1, 1)), "row selection")
  values <- as.list(fx$context)
  values$svy_baseline$survname <- NULL
  ctx <- list2env(values, parent = emptyenv()); lockEnvironment(ctx, bindings = TRUE)
  expect_error(.policy_annual_channels(fx$pipeline,
    .prepare_policy_annual_channels(ctx, "annual-run"), "annual-run"), "Survey join identity unavailable")
})

test_that("unsupported methods and missing model channels are explicit", {
  for (engine in c("ranger", "xgboost")) {
    expect_identical(.policy_annual_channel_status(list(engine = engine, so = list()))$status, "unsupported")
  }
  fx <- annual_channel_fixture()
  values <- as.list(fx$context)
  values$model_type <- "logistic"
  ctx <- list2env(values, parent = emptyenv()); lockEnvironment(ctx, bindings = TRUE)
  expect_identical(.prepare_policy_annual_channels(ctx, "annual-run")$status, "unsupported")
  values$model_type <- NULL; values$so$type <- "binary"
  ctx <- list2env(values, parent = emptyenv()); lockEnvironment(ctx, bindings = TRUE)
  expect_identical(.prepare_policy_annual_channels(ctx, "annual-run")$status, "unsupported")
  fx <- annual_channel_fixture("fixest", interaction = FALSE)
  p <- .prepare_policy_annual_channels(fx$context, "annual-run")
  out <- .policy_annual_channels(fx$pipeline, p, "annual-run")
  expect_false(out$interaction_included)
  expect_false(out$repositioning_modeled)
  expect_equal(out$delta_res2, rep(0, 10))
})

test_that("flat RIF weather curves and reference categories preserve mechanism semantics", {
  fx <- annual_channel_fixture(binned = TRUE)
  model <- fx$model
  model$rif_grid$estimate[model$rif_grid$term %in% c("tempmid", "temphigh", "rain")] <- 0.1
  ctx <- .build_decomposition_context(fx$base, fx$policy, model,
    list(name = "welfare", transform = "none"), skip_coef = TRUE,
    run_identity = "annual-run")
  p <- .prepare_policy_annual_channels(ctx, "annual-run")
  out <- .policy_annual_channels(fx$pipeline, p, "annual-run")
  expect_true(any(p$tau_i_pre != p$tau_i_post))
  expect_equal(out$delta_res1, rep(0, 10))
  expect_equal(p$products$temp$interaction[, match("low", p$products$temp$categories)], rep(0, ctx$n))
  expect_equal(out$delta_total,
    .policy_annual_channels_reference(fx$pipeline, ctx, "annual-run")$delta_total)
})

test_that("central preparation does not request coefficient covariance", {
  fx <- annual_channel_fixture("fixest")
  local_mocked_bindings(vcov = function(...) stop("SE work forbidden"), .package = "stats")
  ctx <- .build_decomposition_context(fx$base, fx$policy, fx$model,
    list(name = "welfare", transform = "none"), skip_coef = TRUE,
    run_identity = "annual-run")
  expect_identical(.prepare_policy_annual_channels(ctx, "annual-run")$status, "ok")
})

test_that("production corrections and compact member summaries share annual channel blocks", {
  for (engine in c("fixest", "rif")) for (binned in c(FALSE, TRUE)) for (trans in c("none", "log")) {
    fx <- annual_channel_fixture(engine, binned, trans)
    p <- fx$pipeline
    p$y_point <- seq(1, 2, length.out = length(p$y_point))
    hist <- list(pipeline = p, shared_context = list(train_aug = fx$base), residuals = "original")
    second <- p
    if (!binned) second$weather_exposure$table$temp <- second$weather_exposure$table$temp * 2
    scenarios <- list(future = list(pipelines = list(a = p, b = second), year_range = c("2030", "2031")))
    run <- function(chunk_size) apply_policy_delta_to_baseline(
      fx$base, fx$policy, fx$model, fx$context$so, hist, scenarios,
      decomp_context = fx$context, run_identity = "annual-run", chunk_size = chunk_size
    )
    out <- run(3L)
    one_block <- run(100L)
    reference <- .policy_annual_channels_reference(p, fx$context, "annual-run")
    expect_equal(out$hist_sim$pipeline$y_point, p$y_point + reference$delta_total)
    expect_identical(out$hist_sim$pipeline[names(p)[names(p) != "y_point"]], p[names(p)[names(p) != "y_point"]])
    expect_identical(out$hist_sim$shared_context, hist$shared_context)
    expect_identical(out$correction_version, "row_aligned_annual_v1")
    expect_equal(out$decomp_scenarios, one_block$decomp_scenarios, tolerance = 1e-12)
    tbl <- out$decomp_scenarios$channel_summary
    expect_equal(nrow(tbl), 6L)
    expect_setequal(tbl$member, c("Historical", "a", "b"))
    for (member in c("a", "b")) {
      pipe <- scenarios$future$pipelines[[member]]
      ch <- .policy_annual_channels(pipe, out$annual_channels, "annual-run")
      expect_equal(out$saved_scenarios$future$pipelines[[member]]$y_point, pipe$y_point + ch$delta_total)
      for (yr in unique(pipe$sim_year)) {
        idx <- which(pipe$sim_year == yr)
        row <- tbl[tbl$member == member & tbl$sim_year == yr, ]
        for (field in c("delta_main", "delta_res1", "delta_res2", "delta_total")) {
          expect_equal(row[[paste0("sum_", field)]] / row[[paste0("weight_", field)]],
            weighted.mean(ch[[field]][idx], pipe$weight[idx]))
        }
      }
    }
    expect_identical(p$y_point, seq(1, 2, length.out = length(p$y_point)))
  }
})

test_that("production validates once per pipeline and fails closed without prediction or SE work", {
  fx <- annual_channel_fixture()
  hist <- list(pipeline = fx$pipeline)
  calls <- 0L
  validate <- .validate_policy_annual_exposure
  local_mocked_bindings(
    .validate_policy_annual_exposure = function(...) { calls <<- calls + 1L; validate(...) },
    .policy_central_delta = function(...) stop("Period mean forbidden"),
    run_sim_pipeline = function(...) stop("Prediction forbidden")
  )
  out <- apply_policy_delta_to_baseline(fx$base, fx$policy, fx$model, fx$context$so,
    hist, decomp_context = fx$context, run_identity = "annual-run", chunk_size = 1L)
  expect_equal(calls, 1L)
  bad <- fx$pipeline
  bad$weather_exposure$table$rain[1] <- NA_real_
  expect_error(apply_policy_delta_to_baseline(fx$base, fx$policy, fx$model, fx$context$so,
    hist, list(good = list(pipelines = list(a = fx$pipeline)), bad = list(pipelines = list(b = bad))),
    decomp_context = fx$context, run_identity = "annual-run"), "Missing exact weather")
  expect_identical(out$hist_sim$pipeline$policy_correction$run_identity, "annual-run")
  expect_error(apply_policy_delta_to_baseline(fx$base, fx$policy, fx$model, fx$context$so,
    hist, decomp_context = fx$context, run_identity = "stale"), "run identity mismatch")
  for (engine in c("fixest", "rif")) {
    zero <- annual_channel_fixture(engine, zero_policy = TRUE)
    out <- apply_policy_delta_to_baseline(zero$base, zero$policy, zero$model, zero$context$so,
      list(pipeline = zero$pipeline), decomp_context = zero$context, run_identity = "annual-run")
    expect_identical(out$hist_sim$pipeline$y_point, zero$pipeline$y_point)
  }
})

test_that("adverse decomposition is unavailable without enough baseline years", {
  fx <- annual_channel_fixture()
  other <- fx$pipeline
  other$weather_exposure$table$temp <- other$weather_exposure$table$temp * 10
  out <- apply_policy_delta_to_baseline(fx$base, fx$policy, fx$model, fx$context$so,
    list(pipeline = fx$pipeline),
    list(future = list(pipelines = list(a = fx$pipeline, b = other))),
    decomp_context = fx$context, run_identity = "annual-run")
  compact <- out$decomp_scenarios
  expect_true(all(c("sum_baseline_level", "weight_baseline_level") %in%
    names(compact$channel_summary)))
  expect_true(all(c("sum_baseline_level", "weight_baseline_level") %in%
    names(compact$decile_summary)))
  expect_true("Historical" %in% compact$scenario_order)
  # Too few simulated years for a 1-in-20 rank: unavailable, not a fallback year.
  expect_equal(nrow(.compact_future_decomp(compact, "future", "adverse_20", fx$context$so)), 0L)
  expect_equal(nrow(.compact_future_decile_summary(compact, "future", "adverse_20", fx$context$so)), 0L)
})

test_that("compact level channels convert log effects per household before averaging", {
  fx <- annual_channel_fixture(transform = "log")
  out <- apply_policy_delta_to_baseline(fx$base, fx$policy, fx$model, fx$context$so,
    list(pipeline = fx$pipeline), decomp_context = fx$context, run_identity = "annual-run")
  rows <- out$decomp_scenarios$channel_summary
  ch <- .policy_annual_channels(fx$pipeline, out$annual_channels, "annual-run")
  w <- fx$pipeline$weight %||% rep(1, length(fx$pipeline$y_point))
  # R2-BUG-07: level channels are taken against the predicted year-t level.
  b <- exp(fx$pipeline$y_point)
  year <- fx$pipeline$sim_year == rows$sim_year[[1L]]
  # DOC-11: the cash part is the level amount T, not scaled by the other channels
  per_row <- (exp(ch$delta_main_covar + ch$delta_res1 + ch$delta_res2) - 1) * b +
    (exp(ch$delta_sp) - 1) * b
  expected <- stats::weighted.mean(per_row[year], w[year])
  expect_equal(rows$sum_lvl_total[[1L]] / rows$weight_lvl_total[[1L]], expected)
  # Not the (biased) conversion of the averaged log effect.
  naive <- (exp(stats::weighted.mean(ch$delta_total[year], w[year])) - 1) *
    stats::weighted.mean(b[year], w[year])
  expect_false(isTRUE(all.equal(expected, naive, tolerance = 1e-12)))
})

test_that("exposure validation reuses the structure of a validated member and still fails closed", {
  fx <- annual_channel_fixture(binned = TRUE)
  ctx <- fx$context
  validate <- function(pipe, cache) .validate_policy_annual_exposure(pipe, ctx, NULL, cache)
  cache <- new.env(parent = emptyenv())
  first <- validate(fx$pipeline, cache)
  expect_identical(first, validate(fx$pipeline, NULL))
  expect_false(is.null(cache$validated_structure))

  # A sibling member differs only in its weather values: same result as an
  # uncached validation, and the structure stays cached.
  sibling <- fx$pipeline
  sibling$weather_exposure$table$rain <- sibling$weather_exposure$table$rain + 1
  expect_identical(validate(sibling, cache), validate(sibling, NULL))
  expect_false(is.null(cache$validated_structure))

  # Every structural or weather defect is still caught with a primed cache.
  cases <- list(
    list(function(p) { p$weather_exposure$table$temp <- as.character(p$weather_exposure$table$temp); p }, "invalid weather category"),
    list(function(p) { p$weather_exposure$table$rain[1] <- NA; p }, "Missing exact weather"),
    list(function(p) { p$weather_exposure$table$rain[1] <- Inf; p }, "Nonfinite"),
    list(function(p) { p$weather_exposure$table$rain <- NULL; p }, "Missing exact weather"),
    list(function(p) { p$weather_exposure$table$survname[1] <- "wrong-wave"; p }, "survey identity mismatch"),
    list(function(p) { p$weather_exposure$table$timestamp[1] <- as.Date("2000-01-01"); p }, "anchor does not match"),
    list(function(p) { p$weather_exposure$prediction_row_id[2] <- 1L; p }, "Invalid prediction-row"),
    list(function(p) { p$weight <- p$weight + 1; p$weather_exposure$weight <- p$weight; p }, "weight mismatch")
  )
  for (case in cases) {
    expect_error(validate(case[[1]](fx$pipeline), cache), case[[2]])
    # A failed member must not poison the cache for the next good one.
    expect_identical(validate(fx$pipeline, cache), first)
  }

  # A different run context never reuses another context's validation.
  other <- fx$context
  other_ctx <- annual_channel_fixture(binned = TRUE)$context
  expect_false(identical(other, other_ctx))
  expect_error(
    .validate_policy_annual_exposure(
      within(fx$pipeline, svy_row_id[1] <- 999L), other_ctx, NULL, cache),
    "Invalid prediction-row|ordering mismatch")
})

test_that("a primed exposure cache leaves the annual policy run and metric decomposition unchanged", {
  fx <- metric_channel_fixture("fixest")
  fx$hist$residuals <- "none"
  fx$policy_hist$residuals <- "none"
  member <- fx$hist$pipeline
  sibling <- member
  sibling$weather_exposure$table$rain <- sibling$weather_exposure$table$rain * 1.5
  scenarios <- list(future = list(pipelines = list(a = member, b = sibling),
    shared_context = fx$hist$shared_context))
  out <- apply_policy_delta_to_baseline(fx$fx$base, fx$fx$policy, fx$fx$model,
    fx$fx$context$so, fx$hist, scenarios, decomp_context = fx$fx$context,
    run_identity = "annual-run")
  # Reference: each member through its own, never shared, validation.
  for (name in c("a", "b")) {
    pipe <- scenarios$future$pipelines[[name]]
    ref <- .apply_policy_annual_pipeline(pipe, fx$prepared, "annual-run",
      scenario = "future", member = name, owner = scenarios$future)
    expect_identical(out$saved_scenarios$future$pipelines[[name]]$y_point,
      ref$pipeline$y_point)
  }
})

test_that("residual draws are shared across members and never reused across different inputs", {
  train <- data.frame(id = 1:12, .resid = seq(-0.2, 0.2, length.out = 12))
  ids <- c(3L, 1L, 99L, 5L)
  for (mode in c("original", "resample", "none")) {
    cache <- new.env(parent = emptyenv())
    expected <- draw_residuals_vec(mode, train, 4L, ids, "id",
      seed = wise_seed(WISEAPP_DEFAULT_SEED, "residual", 2030L))
    first <- .policy_metric_residuals(cache, mode, train, "id", ids, 4L, 2030L)
    expect_identical(first, expected, info = mode)
    expect_identical(.policy_metric_residuals(cache, mode, train, "id", ids, 4L, 2030L), expected)
  }

  draws <- 0L
  real <- draw_residuals_vec
  local_mocked_bindings(
    draw_residuals_vec = function(...) { draws <<- draws + 1L; real(...) },
    .package = "wiseapp")
  cache <- new.env(parent = emptyenv())
  call <- function(mode = "original", tr = train, i = ids, n = length(ids), year = 2030L) {
    .policy_metric_residuals(cache, mode, tr, "id", i, n, year)
  }
  call(); call()
  expect_identical(draws, 1L)
  # Each changed input is a miss and gives the value an uncached draw gives.
  other_train <- transform(train, .resid = rev(.resid))
  for (case in list(
    list(year = 2031L), list(i = c(3L, 1L, 99L, 6L)), list(i = ids[1:3], n = 3L),
    list(mode = "resample"), list(tr = other_train)
  )) {
    before <- draws
    got <- do.call(call, case)
    expect_identical(draws, before + 1L)
    mode <- case$mode %||% "original"
    tr <- case$tr %||% train
    i <- case$i %||% ids
    n <- case$n %||% length(ids)
    year <- case$year %||% 2030L
    expect_identical(got, real(mode, tr, n, i, "id",
      seed = wise_seed(WISEAPP_DEFAULT_SEED, "residual", year)))
  }
})

test_that("the metric decomposition draws residuals once per year and scenario, with unchanged results", {
  fx <- metric_channel_fixture("fixest", residuals = "original")
  member <- fx$hist$pipeline
  sibling <- member
  sibling$weather_exposure$table$rain <- sibling$weather_exposure$table$rain * 1.5
  baseline <- list(future = list(pipelines = list(a = member, b = sibling),
    shared_context = fx$hist$shared_context))
  policy <- lapply(baseline, function(s) {
    s$pipelines <- lapply(s$pipelines, function(p)
      .apply_policy_annual_pipeline(p, fx$prepared, "annual-run")$pipeline)
    s
  })
  run <- function() .policy_metric_decomposition(fx$hist, fx$policy_hist, baseline,
    policy, fx$prepared, "mean", NULL, "original", focus_scenario = "future")
  draws <- 0L
  real <- draw_residuals_vec
  local_mocked_bindings(
    draw_residuals_vec = function(...) { draws <<- draws + 1L; real(...) },
    .package = "wiseapp")
  shared <- run()
  years <- length(unique(member$sim_year))
  # Historical (1 member) + future (2 members sharing their draws).
  expect_identical(draws, 2L * years)
  # Reference: a cache that never hits reproduces the pre-cache computation.
  fresh <- .policy_metric_residuals
  local_mocked_bindings(
    .policy_metric_residuals = function(cache, ...) fresh(new.env(parent = emptyenv()), ...),
    .package = "wiseapp")
  draws <- 0L
  expect_identical(run(), shared)
  expect_identical(draws, 3L * years)
})

test_that("grouped metric statistics give the same annual and decile results as the resolver", {
  for (engine in c("fixest", "rif")) for (trans in c("none", "log")) {
    fx <- metric_channel_fixture(engine, trans)
    for (method in names(.WISE_METRIC_REGISTRY)) {
      args <- list(fx$hist, fx$policy_hist, list(), list(), fx$prepared, method, 3, "none")
      fast <- do.call(.policy_metric_decomposition, args)
      local({
        local_mocked_bindings(welfare_group_stats = function(...) NULL, .package = "wiseapp")
        slow <- do.call(.policy_metric_decomposition, args)
        expect_identical(fast$annual, slow$annual, info = paste(engine, trans, method))
        expect_identical(fast$decile_annual, slow$decile_annual, info = paste(engine, trans, method))
        expect_identical(fast$summary, slow$summary, info = paste(engine, trans, method))
      })
    }
  }
})

test_that("compact policy channels match a direct recomputation per year and per decile", {
  fx <- annual_channel_fixture()
  out <- apply_policy_delta_to_baseline(fx$base, fx$policy, fx$model, fx$context$so,
    list(pipeline = fx$pipeline), list(future = list(pipelines = list(a = fx$pipeline))),
    decomp_context = fx$context, run_identity = "annual-run", chunk_size = 3L)
  compact <- out$decomp_scenarios
  chan_a <- compact$channel_summary[compact$channel_summary$member == "a", ]
  dec_a <- compact$decile_summary[compact$decile_summary$member == "a", ]
  pipe <- fx$pipeline
  ch <- .policy_annual_channels(pipe, out$annual_channels, "annual-run")
  decile <- fx$context$baseline_deciles[pipe$svy_row_id]
  for (yr in unique(pipe$sim_year)) {
    sel <- pipe$sim_year == yr
    # Year totals cover every row, with or without a baseline decile.
    expect_equal(chan_a$sum_delta_total[chan_a$sim_year == yr],
      sum(ch$delta_total[sel] * pipe$weight[sel]), tolerance = 1e-12)
    expect_equal(chan_a$weight_delta_total[chan_a$sim_year == yr],
      sum(pipe$weight[sel]), tolerance = 1e-12)
    for (d in unique(decile[sel & is.finite(decile)])) {
      cell <- sel & is.finite(decile) & decile == d
      row <- dec_a[dec_a$sim_year == yr & dec_a$decile == d, ]
      expect_equal(nrow(row), 1L)
      expect_equal(row$sum_delta_total, sum(ch$delta_total[cell] * pipe$weight[cell]),
        tolerance = 1e-12)
      expect_equal(row$n_households, sum(cell))
      expect_equal(row$weighted_population, sum(pipe$weight[cell]), tolerance = 1e-12)
    }
  }
  # No decile cell for a (year, decile) without rows.
  expect_equal(nrow(dec_a), nrow(unique(
    data.frame(y = pipe$sim_year, d = decile)[is.finite(decile), ])))
})

test_that("the main effect adds the interview-weather interaction, never the repositioning (MR-12)", {
  for (engine in c("fixest", "rif")) for (binned in c(FALSE, TRUE)) {
    fx <- annual_channel_fixture(engine, binned, "none")
    p <- .prepare_policy_annual_channels(fx$context, "annual-run")
    w0 <- setNames(lapply(fx$context$weather_vars, function(v) fx$base[[v]]), fx$context$weather_vars)
    at_interview <- .policy_explicit_channels(fx$context, w0)
    if (engine == "rif") expect_gt(max(abs(at_interview$delta_res1)), 0)
    # The context's own main effect (SP + covariates) plus gamma * dD * W0 only
    expect_equal(p$delta_main, fx$context$delta_main + at_interview$delta_res2, tolerance = 1e-14)
    expect_equal(p$delta_main_covar, p$delta_main - p$delta_sp, tolerance = 1e-14)
    # The linear model has no repositioning at all
    if (engine == "fixest") expect_equal(at_interview$delta_res1, rep(0, fx$context$n))
  }
})
