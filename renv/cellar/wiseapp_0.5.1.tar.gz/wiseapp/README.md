# `{wiseapp}`

## Overview

`{wiseapp}` is a Shiny application for estimating how weather affects welfare,
simulating weather and climate scenarios, and evaluating adaptation policies.

See the [User guide](https://datanalytics.worldbank.org/wise-app-docs) for full
documentation. The data preparation workflow is available in the
[wise-app-data repository](https://github.com/worldbank/wise-app-data).

## Installation

Install the development version from GitHub with `pak`:

```r
pak::pkg_install("worldbank/wise-app")
```

## Run

Launch the application with:

```r
wiseapp::run_app()
```

## Agent skills

Task guides for coding agents (Claude Code, Kilo, Codex and others) are in
[`.agents/skills/`](.agents/skills). This is the only copy in the repository;
`AGENTS.md` lists them. Current Kilo and Codex discover this folder directly;
no copy is needed. Kilo can refresh with `/reload`; Codex lists skills with
`/skills` (restart if an update does not appear). For other tools:

- link the folder (macOS and Linux, from the repository root), for example for
  Claude Code: `ln -s ../.agents/skills .claude/skills`; `.claude/skills` is
  git-ignored;
- or copy `.agents/skills/*` into the tool's skills folder (for example
  `.claude/skills/`), and repeat after a skill changes. On Windows, from the
  repository root in PowerShell: `New-Item -ItemType Directory -Force .claude/skills`;
  `Copy-Item .agents/skills/* .claude/skills/ -Recurse -Force`.

Edit skills only in `.agents/skills/`.
