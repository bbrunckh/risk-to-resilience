# Model results helpers ----
# Outcome preparation, coefficient helpers, and plot/table builders.
# Outcome preparation, coefficient helpers, and plot/table builders.
# Used by mod_1_07_results_server(). Stateless and testable without Shiny.    #


# Outcome preparation ----

#' Prepare the outcome column in survey_weather before model fitting
#'
#' Applies three sequential transformations in order:
#' 1. **LCU back-conversion** - multiply by `ppp2021` when `units == "LCU"`.
#'    Applies only to an existing continuous (log-transformed) monetary
#'    outcome column, e.g. `welfare`. Constructed indicators such as `poor`
#'    are unitless and are never back-converted.
#' 2. **Log transform** - `log()` when `transform == "log"`.
#' 3. **Binary poor indicator** - `welfare < povline` when `name == "poor"`
#'    and `povline` is non-NA. The stored `welfare` column is in 2021 PPP,
#'    so a poverty line expressed in LCU (`units == "LCU"`) is first divided
#'    by the per-observation `ppp2021` factor to place the comparison on a
#'    common scale.
#'
#' @param df A data frame containing the outcome column and optionally
#'   `welfare` and `ppp2021`.
#' @param so A one-row data frame as returned by `build_selected_outcome()`.
#'   Must contain columns `name`, `units`, `transform`, and `povline`.
#'
#' @return `df` with the outcome column mutated in place.
#'
#' @export
prepare_outcome_df <- function(df, so) {
  name <- as.character(so$name[1])
  units <- as.character(so$units[1])
  trans <- as.character(so$transform[1])
  povline <- so$povline[1]

  if ("ppp2021" %in% names(df) && name %in% names(df)) {
    df <- df |> dplyr::mutate(
      !!name := outcome_level_scale(.data[[name]], so, .data$ppp2021)
    )
  }
  if (isTRUE(trans == "log")) {
    df <- df |> dplyr::mutate(!!name := log(.data[[name]]))
  }
  if (isTRUE(name == "poor") && !is.na(povline) && "welfare" %in% names(df)) {
    line <- .povline_to_ppp(povline, df, units == "LCU")
    df <- df |>
      dplyr::mutate(!!name := as.numeric(.data[["welfare"]] < line))
  }

  df
}


# Outcome scale helpers (CR-BUG-02) ----
#
# The stored survey outcome is 2021 PPP. A continuous (log-transformed)
# outcome in LCU is trained, predicted and reported in 2021 LCU, i.e. stored
# welfare times `ppp2021`. Every place that combines the stored baseline outcome
# (or an SP transfer, which is stored on the same scale) with model-scale
# values - the RIF quantile assignment, the decomposition channels, the level
# conversion - must go through these two helpers, so there is one definition of
# the model scale and `prepare_outcome_df()` uses the same one.

#' Stored outcome values on the outcome-currency level scale
#'
#' Multiplies by `ppp2021` when the outcome is a log-transformed LCU outcome,
#' exactly as `prepare_outcome_df()` does before fitting. Every other outcome
#' (PPP, binary, non-log) and any call without a `ppp2021` vector passes
#' through unchanged.
#'
#' @param y Numeric vector on the stored (2021 PPP) scale, or an SP transfer.
#' @param so Selected-outcome metadata (`units`, `transform`); NULL or missing
#'   fields leave `y` unchanged.
#' @param ppp Numeric vector of `ppp2021` factors, one per element of `y`
#'   (NULL when the data carry no deflators).
#' @return Numeric vector, same length as `y`.
#' @keywords internal
outcome_level_scale <- function(y, so, ppp = NULL) {
  if (is.null(ppp) || !isTRUE(as.character(so$units[1L]) == "LCU") ||
    !isTRUE(as.character(so$transform[1L]) == "log")) {
    return(y)
  }
  if (length(ppp) != length(y)) {
    stop("outcome_level_scale(): `ppp` must have one value per outcome value.",
      call. = FALSE
    )
  }
  y * suppressWarnings(as.numeric(ppp))
}

#' Stored outcome values on the scale the model was trained on
#'
#' `outcome_level_scale()`, then `log()` when the outcome is log-transformed.
#' This is the scale of `train_data[[outcome]]`, of the RIF empirical CDF and
#' of every `delta_*` channel.
#'
#' @inheritParams outcome_level_scale
#' @param floor Optional lower bound applied before the log (the
#'   decomposition uses `1e-10`); ignored for non-log outcomes.
#' @return Numeric vector, same length as `y`.
#' @keywords internal
outcome_to_model_scale <- function(y, so, ppp = NULL, floor = NULL) {
  lvl <- outcome_level_scale(y, so, ppp)
  if (!isTRUE(as.character(so$transform[1L]) == "log")) {
    return(lvl)
  }
  if (!is.null(floor)) lvl <- pmax(lvl, floor)
  log(lvl)
}

# `ppp2021` column of a survey frame, or NULL when it carries no deflators.
.outcome_ppp <- function(svy) {
  if (is.data.frame(svy) && "ppp2021" %in% names(svy)) svy$ppp2021 else NULL
}

# Stop when baseline and training outcomes are plainly on different scales.
# A PPP baseline against an LCU-trained model differs by log(ppp2021) (about 5
# on the log scale for many currencies), far beyond any real difference
# between a baseline round and the training sample.
.assert_outcome_scales_match <- function(baseline, train, is_log, where) {
  b <- stats::median(baseline[is.finite(baseline)])
  t <- stats::median(train[is.finite(train)])
  if (!is.finite(b) || !is.finite(t)) {
    return(invisible(TRUE))
  }
  gap <- if (isTRUE(is_log)) abs(b - t) else abs(log(abs(b) / abs(t)))
  if (is.finite(gap) && gap > log(10)) {
    stop(
      where, ": the baseline outcome (median ", signif(b, 3),
      ") and the training outcome (median ", signif(t, 3),
      ") are on different scales. A currency mismatch (2021 PPP vs LCU) is the",
      " usual cause.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}


#' Ensure a derived outcome column exists without applying transforms
#'
#' The `poor` outcome is synthesized from `welfare` and the selected poverty
#' line. Step 2 survey snapshots can omit that derived column, so callers that
#' operate on those snapshots must restore it before reading the outcome.
#' Existing columns are left untouched. Unlike `prepare_outcome_df()`, this
#' helper never logs or currency-converts values.
#'
#' @param df A survey data frame.
#' @param so Outcome metadata containing `name`, `units`, and `povline`.
#' @return `df`, with a derivable missing outcome column added.
#' @export
ensure_outcome_column <- function(df, so) {
  if (is.null(df) || !is.data.frame(df) || is.null(so)) {
    return(df)
  }

  name <- as.character(so$name %||% NA_character_)[1]
  if (is.na(name) || !nzchar(name) || name %in% names(df)) {
    return(df)
  }
  if (!identical(name, "poor") || !"welfare" %in% names(df)) {
    return(df)
  }

  povline <- suppressWarnings(as.numeric(so$povline %||% NA_real_)[1])
  if (!is.finite(povline)) {
    return(df)
  }

  units <- as.character(so$units %||% NA_character_)[1]
  line <- .povline_to_ppp(povline, df, identical(units, "LCU"))
  df[[name]] <- as.numeric(df[["welfare"]] < line)
  df
}


# Scale a user-specified poverty line to match the stored welfare column
# (2021 PPP). LCU lines are divided by the per-observation ppp2021 factor;
# PPP lines - and data loaded without deflators, where no load-time
# conversion took place - are compared directly.
.povline_to_ppp <- function(pl, df, is_lcu) {
  if (isTRUE(is_lcu) && "ppp2021" %in% names(df)) pl / df$ppp2021 else pl
}


# Coefficient helpers ----

#' Extract the Variance-Covariance Matrix from a fixest Fit
#'
#' Tries the fit-time VCV first (respecting the cluster/VCV specification
#' passed at estimation), then progressively simpler alternatives
#' (`COEF_VCOV_SPEC`, one-way `~loc_id` clusters, `"HC1"`, `"iid"`), and
#' finally plain `stats::vcov()`.
#'
#' @param fit A native `fixest` model object.
#'
#' @return A variance-covariance matrix, or `NULL` when extraction fails.
#'
#' @export
.fixest_vcov <- function(fit) {
  # Try the fit-time VCV first (respects cluster= arg passed at estimation)
  v <- tryCatch(stats::vcov(fit), error = function(e) NULL)
  if (!is.null(v)) {
    return(v)
  }
  for (spec in list(COEF_VCOV_SPEC, ~loc_id, "HC1", "iid")) {
    v <- tryCatch(stats::vcov(fit, vcov = spec), error = function(e) NULL)
    if (!is.null(v)) {
      return(v)
    }
  }
  stats::vcov(fit)
}

# RIF sub-fit (one fixest per tau) for `tau`, or NULL. `taus` is the full
# quantile grid in the order the fixest_multi was estimated.
.rif_subfit <- function(fit_multi, taus, tau) {
  if (is.null(fit_multi) || !length(taus)) {
    return(NULL)
  }
  if (inherits(fit_multi, "fixest")) {
    return(fit_multi)
  }
  i <- which.min(abs(taus - tau))
  tryCatch(fit_multi[[i]], error = function(e) NULL)
}

# Standard error of a weighted sum of coefficients, sqrt(w' V w), from the
# fit's full VCV so polynomial terms keep their covariance (R2-BUG-19). Falls
# back to the independent-terms formula when the VCV or a term is unavailable.
.rif_combined_se <- function(fit, terms, weights, se) {
  keep <- weights != 0
  terms <- terms[keep]
  w <- weights[keep]
  V <- if (is.null(fit)) NULL else tryCatch(.fixest_vcov(fit), error = function(e) NULL)
  if (!is.null(V) && length(terms) && all(terms %in% colnames(V))) {
    v <- as.numeric(t(w) %*% V[terms, terms, drop = FALSE] %*% w)
    return(sqrt(max(v, 0)))
  }
  sqrt(sum((weights * se)^2, na.rm = TRUE))
}

.fixest_vcov_spec <- function(fit) {
  # Try the fit-time VCV first (respects cluster= arg passed at estimation)
  ok <- tryCatch(
    {
      summary(fit)
      TRUE
    },
    error = function(e) FALSE
  )
  if (ok) {
    return(NULL)
  } # NULL signals "use default"
  for (spec in list(COEF_VCOV_SPEC, ~loc_id, "HC1", "iid")) {
    ok <- tryCatch(
      {
        summary(fit, vcov = spec)
        TRUE
      },
      error = function(e) FALSE
    )
    if (ok) {
      return(spec)
    }
  }
  "iid"
}

.fixest_coeftable <- function(fit) {
  # Try the fit-time VCV first (respects cluster= arg passed at estimation)
  ct <- tryCatch(as.data.frame(fixest::coeftable(fit)), error = function(e) NULL)
  if (!is.null(ct)) {
    return(ct)
  }
  for (spec in list(COEF_VCOV_SPEC, ~loc_id, "HC1", "iid")) {
    ct <- tryCatch(
      as.data.frame(fixest::coeftable(fit, vcov = spec)),
      error = function(e) NULL
    )
    if (!is.null(ct)) {
      return(ct)
    }
  }
  as.data.frame(fixest::coeftable(fit))
}


weather_coef_names <- function(fit, weather_terms) {
  all_coefs <- names(stats::coef(fit))

  # Build safe word-boundary pattern
  pattern <- paste0("\\b(", paste(weather_terms, collapse = "|"), ")\\b")

  # Return matching coefficient names
  all_coefs[grepl(pattern, all_coefs)]
}


#' Detect survey columns modified between training data and a counterfactual
#'
#' Compares two household-level data frames column-by-column. Returns the names
#' of columns whose values differ for at least one household. Used to identify
#' policy-modified variables in Module 3 simulations (`apply_policy_to_svy()`
#' flips e.g. `electricity`, `internet`, `employed`) so the coefficient-
#' uncertainty mask can be extended beyond weather terms.
#'
#' Both inputs are expected at the household grain (one row per household).
#' Joins on `id_col` if present in both; otherwise falls back to a row-order
#' comparison clipped to the shorter frame.
#'
#' @param svy_modified Data frame. Survey after counterfactual modification.
#' @param svy_train Data frame. Reference training data.
#' @param id_col Character or NULL. Optional household ID column for joining.
#' @param exclude_cols Character vector. Columns to skip (outcome, weights, FE,
#'   metadata, SP transfer column).
#'
#' @return Character vector of modified column names (possibly empty).
#'
#' @export
detect_modified_cols <- function(svy_modified, svy_train,
                                 id_col = NULL,
                                 exclude_cols = character()) {
  if (is.null(svy_modified) || is.null(svy_train)) {
    return(character())
  }

  common <- intersect(names(svy_modified), names(svy_train))
  candidates <- setdiff(common, c(id_col, exclude_cols))
  if (length(candidates) == 0L) {
    return(character())
  }

  if (!is.null(id_col) && id_col %in% names(svy_modified) &&
    id_col %in% names(svy_train)) {
    keep <- intersect(svy_modified[[id_col]], svy_train[[id_col]])
    if (length(keep) == 0L) {
      return(character())
    }
    m <- svy_modified[match(keep, svy_modified[[id_col]]), candidates,
      drop = FALSE
    ]
    t <- svy_train[match(keep, svy_train[[id_col]]), candidates, drop = FALSE]
  } else {
    n <- min(nrow(svy_modified), nrow(svy_train))
    if (n == 0L) {
      return(character())
    }
    m <- svy_modified[seq_len(n), candidates, drop = FALSE]
    t <- svy_train[seq_len(n), candidates, drop = FALSE]
  }

  changed <- vapply(candidates, function(col) {
    a <- m[[col]]
    b <- t[[col]]
    if (length(a) != length(b)) {
      return(TRUE)
    }
    any((a != b) | (is.na(a) != is.na(b)), na.rm = TRUE)
  }, logical(1))

  candidates[changed]
}


#' Attach an active-coefficient mask to a Cholesky vcov object
#'
#' Wrapper that builds the additive-decomposition active mask
#' (\code{\link{build_active_coef_mask}}) and attaches it to `chol_obj` for
#' downstream consumption by \code{\link{compute_factor_loading}} (linear
#' engine) and \code{interpolate_F_loading()} (RIF engine).
#'
#' Active terms = `weather_terms` plus any columns whose values differ
#' between `svy_modified` and `train_data` (excluding weather, outcome,
#' weights, FE columns, and `SP_TRANSFER_COL`).
#'
#' The mask is only built when `residuals == "original"` and
#' `propagate_all_covariate_uncertainty == FALSE`. Otherwise the function
#' returns `chol_obj` unchanged (legacy full propagation).
#'
#' Handles both linear shape (`chol_obj` is a list with `$L`, `$beta`, ...)
#' and RIF shape (`chol_obj` is a list of per-tau lists). For RIF, the mask
#' is attached via `attr(chol_obj, "active_mask")`; per-tau attachment is
#' not needed because all tau fits share coefficient ordering.
#'
#' @param chol_obj Output of `compute_chol_vcov()` or NULL.
#' @param svy_modified Household-level survey (possibly policy-modified).
#'   Compared against `svy_reference` to detect which covariates changed
#'   between baseline and counterfactual.
#' @param svy_reference Household-level survey to diff against. For Module 2
#'   this is the (unmodified) baseline survey, so the diff is empty and
#'   `active_terms = weather_terms`. For Module 3 this is the pre-policy
#'   baseline `svy_baseline`, so the diff returns exactly the policy-modified
#'   columns. If NULL, falls back to `train_data` (legacy comparison).
#' @param train_data Training-data data frame. Used as the reference when
#'   `svy_reference` is NULL.
#' @param weather_terms Character vector of weather variable names.
#' @param outcome_col Character or NULL. Outcome column name to exclude from
#'   the diff (e.g. `"welfare"`). The outcome is log-transformed in
#'   `train_data` but not in `svy`, so it would otherwise be flagged as
#'   "modified" - defensively excluded even though no coefficient is named
#'   after it.
#' @param residuals Character. Residual mode (`"original"`, `"resample"`, ...).
#' @param propagate_all_covariate_uncertainty Logical. TRUE disables the
#'   mask (legacy behaviour).
#'
#' @return `chol_obj` with `$active_mask` (or `attr(., "active_mask")` for
#'   RIF) set when appropriate; otherwise unchanged.
#'
#' @export
attach_active_mask <- function(chol_obj,
                               svy_modified,
                               train_data,
                               weather_terms,
                               residuals,
                               svy_reference = NULL,
                               outcome_col = NULL,
                               propagate_all_covariate_uncertainty = FALSE) {
  if (is.null(chol_obj)) {
    return(chol_obj)
  }
  if (isTRUE(propagate_all_covariate_uncertainty)) {
    return(chol_obj)
  }

  # Determine coefficient names from either shape. RIF chol_obj is a list of
  # per-tau lists (each with $L, $beta); linear chol_obj is a single list with
  # $L and $beta at the top level.
  is_rif_shape <- is.list(chol_obj) && !("L" %in% names(chol_obj)) &&
    length(chol_obj) > 0L &&
    is.list(chol_obj[[1]]) && "beta" %in% names(chol_obj[[1]])

  # Gating: the cancellation argument applies under (a) "original" residuals
  # for the linear engine - the per-household residual is held fixed across beta
  # draws and absorbs uncertainty on unchanged coefficients - or (b) any
  # residuals mode for the RIF engine, because the RIF prediction is
  # y_baseline + delta_i and the level y_baseline plays the same role as the
  # fixed residual on the linear path. Under "resample" with the
  # linear engine, residuals are drawn independently of beta and the
  # cancellation does not hold.
  if (!is_rif_shape && !identical(residuals, "original")) {
    return(chol_obj)
  }
  coef_names <- if (is_rif_shape) {
    names(chol_obj[[1]]$beta)
  } else if (is.list(chol_obj) && "beta" %in% names(chol_obj)) {
    names(chol_obj$beta)
  } else {
    NULL
  }
  if (is.null(coef_names)) {
    return(chol_obj)
  }

  # Prefer comparing against the pre-counterfactual baseline survey
  # (svy_reference) - that is *exactly* what we want to diff against.
  # Fall back to train_data when the baseline is not available; in that
  # case the comparison is correct iff the user simulates on the same
  # underlying survey they trained on (common case).
  reference <- svy_reference %||% train_data

  id_col <- intersect(
    c(RESID_KEY_COL, "pid", "hhid", "fid"),
    intersect(names(svy_modified), names(reference))
  )
  id_col <- if (length(id_col) > 0L) id_col[[1L]] else NULL

  weight_cols <- grep("^weight$|^hhweight$|^wgt$|^pw$",
    union(names(svy_modified), names(reference)),
    value = TRUE, ignore.case = TRUE
  )
  exclude_cols <- c(
    SP_TRANSFER_COL, ".svy_row_id",
    "year", "sim_year", "int_month",
    "code", "survname", "loc_id",
    weather_terms, weight_cols, outcome_col
  )

  modified <- detect_modified_cols(svy_modified, reference,
    id_col = id_col,
    exclude_cols = exclude_cols
  )
  active_terms <- unique(c(weather_terms, modified))
  if (length(active_terms) == 0L) {
    return(chol_obj)
  }

  mask <- tryCatch(
    build_active_coef_mask(coef_names, active_terms),
    error = function(e) {
      warning(
        "[attach_active_mask] mask construction failed: ",
        conditionMessage(e)
      )
      NULL
    }
  )
  if (is.null(mask)) {
    return(chol_obj)
  }

  # Build L_active: Cholesky factor of the active block of Sigma. For the
  # lower-triangular factor emitted by compute_chol_vcov(),
  # Sigma[mask, mask] = L[mask, ] %*% t(L[mask, ]), so the full K x K
  # covariance reconstruction is unnecessary. Legacy or differently oriented
  # factors use the old route after this validation fails.
  cholesky_active_block <- function(L_full) {
    valid_factor <- is.matrix(L_full) && nrow(L_full) == ncol(L_full) &&
      all(is.finite(L_full))
    if (valid_factor) {
      upper <- L_full[upper.tri(L_full)]
      scale <- max(1, max(abs(L_full)))
      valid_factor <- !length(upper) ||
        max(abs(upper)) <= sqrt(.Machine$double.eps) * scale
    }

    active_rows <- L_full[mask, , drop = FALSE]
    active_covariance <- if (valid_factor) {
      tcrossprod(active_rows)
    } else {
      Sigma_full <- L_full %*% t(L_full)
      Sigma_full[mask, mask, drop = FALSE]
    }

    tryCatch(t(chol(active_covariance)),
      error = function(e) {
        warning(
          "[attach_active_mask] Cholesky of active block failed: ",
          conditionMessage(e),
          " - falling back to no masking."
        )
        NULL
      }
    )
  }

  if (is_rif_shape) {
    L_active_list <- lapply(chol_obj, function(x) cholesky_active_block(x$L))
    if (any(vapply(L_active_list, is.null, logical(1)))) {
      return(chol_obj)
    }
    for (k in seq_along(chol_obj)) {
      chol_obj[[k]]$L_active <- L_active_list[[k]]
    }
    attr(chol_obj, "active_mask") <- mask
  } else {
    L_active <- cholesky_active_block(chol_obj$L)
    if (is.null(L_active)) {
      return(chol_obj)
    }
    chol_obj$L_active <- L_active
    chol_obj$active_mask <- mask
  }

  # Diagnostic so users can verify the additive-decomposition SE is in
  # effect. Printed once per simulation run.
  kept <- names(mask)[mask]
  message(sprintf(
    "[active_mask] additive-decomposition SE active: keeping %d/%d coefficients (%s engine). Active: %s",
    sum(mask), length(mask),
    if (is_rif_shape) "RIF" else "linear",
    paste(kept, collapse = ", ")
  ))
  chol_obj
}


#' Build a logical mask over coefficient names for the active variable set
#'
#' Returns a length-K logical vector flagging coefficients whose names involve
#' any term in `active_terms` (via word-boundary regex). Used by the additive-
#' decomposition SE: when residuals are held fixed per household ("original"),
#' uncertainty on coefficients for variables that do not change between
#' baseline and counterfactual cancels through the residual term, so only the
#' active subset contributes to `var_coef`.
#'
#' The intercept (if present) is forced to FALSE.
#'
#' @param coef_names Character vector. Names from `coef(fit)` /
#'   `names(chol_obj$beta)`, in the same order as the design-matrix columns.
#' @param active_terms Character vector. Raw variable names whose coefficients
#'   (and any interactions involving them) should remain active.
#'
#' @return Named logical vector of length `length(coef_names)`, or NULL if
#'   `active_terms` is empty.
#'
#' @export
build_active_coef_mask <- function(coef_names, active_terms) {
  active_terms <- active_terms[nzchar(active_terms)]
  if (length(active_terms) == 0L) {
    warning(
      "[build_active_coef_mask] no active terms supplied; ",
      "returning NULL (caller will fall back to full propagation)."
    )
    return(NULL)
  }

  # Escape regex metacharacters in term names (e.g. dots in column names).
  esc <- gsub("([][{}().+*^$|?\\\\])", "\\\\\\1", active_terms)

  # Word-boundary match plus a fallback for fixest factor expansions that use
  # "::" between variable and level (e.g. "tx::level1:urban").
  pattern <- paste0(
    "(\\b(", paste(esc, collapse = "|"), ")\\b)",
    "|((^|[^A-Za-z0-9_])(", paste(esc, collapse = "|"),
    ")(::|$))"
  )

  mask <- grepl(pattern, coef_names)
  names(mask) <- coef_names

  if ("(Intercept)" %in% coef_names) mask[["(Intercept)"]] <- FALSE
  mask
}


#' Build a human-readable label for a coefficient name
#'
#' Splits on `":"` and applies `label_fun` to each component, joining
#' with `" * "`.
#'
#' @param coef_name Scalar character coefficient name, e.g. `"tx:urban"`.
#' @param label_fun Function mapping a variable name to a readable label.
#'   Defaults to `identity`.
#'
#' @return Scalar character label.
#'
#' @export
coef_label <- function(coef_name, label_fun = identity) {
  parts <- strsplit(coef_name, ":")[[1]]
  paste(vapply(parts, label_fun, character(1)), collapse = " \u00d7 ")
}

# Pretty polynomial term name: I(I(t^2)) / I(t^2) -> "<label of t>^2".
.pretty_poly_label <- function(term, label_fun = identity) {
  m <- regmatches(term, regexec(
    "^I\\((?:I\\()?([^\\^]+)\\^([23])\\)\\)?$",
    term
  ))[[1]]
  if (length(m) != 3) {
    return(term)
  }
  lab <- tryCatch(label_fun(m[2]), error = function(e) m[2])
  if (is.null(lab) || is.na(lab) || !nzchar(lab)) lab <- m[2]
  paste0(lab, if (m[3] == "2") "\u00b2" else "\u00b3")
}


#' Build a named coefficient map for jtools
#'
#' Returns a named vector where names are human-readable labels and values
#' are raw coefficient names, suitable for the `coefs` argument of
#' `jtools::plot_summs()` / `jtools::export_summs()`.
#'
#' @param coef_names Character vector of raw coefficient names.
#' @param label_fun  Function mapping variable names to readable labels.
#'
#' @return Named character vector.
#'
#' @export
make_coef_map <- function(coef_names, label_fun = identity) {
  one_label <- function(term) {
    parts <- strsplit(as.character(term), ":", fixed = TRUE)[[1]]
    parts <- vapply(parts, function(part) {
      poly <- .pretty_poly_label(part, label_fun)
      if (!identical(poly, part)) return(poly)
      m <- regexec("^([^\\[\\(]+)([\\[\\(].*)$", part)
      hit <- regmatches(part, m)[[1]]
      if (length(hit) == 3L) {
        return(.cut_bin_label(hit[[3]]))
      }
      tryCatch(label_fun(part), error = function(e) part)
    }, character(1))
    paste(parts, collapse = " \u00d7 ")
  }
  readable <- vapply(coef_names, one_label, character(1))
  stats::setNames(coef_names, readable)
}


# Engine helpers ----

#' Extract the native model object from a fit_model result
#'
#' For `"fixest"`, `"ranger"`, and `"xgboost"` engines the object stored by
#' `fit_model()` is already a native R model object - no unwrapping needed.
#' For the `"rif"` engine, each fit is a `fixest_multi` (list of 9 models).
#' This function returns the object as-is; use `extract_rif_median()` to
#' get a single representative model for diagnostics.
#'
#' @param fit    A model object as stored in `fit_model()$fit1` etc.
#' @param engine Scalar character engine key (e.g. `"fixest"`).
#'
#' @return The native model object.
#'
#' @export
extract_native_fit <- function(fit, engine = "fixest") {
  fit
}


#' Resolve a fitted model's design matrix, preferring the cached copy
#'
#' `fit_model()` strips the embedded data from each fixest fit's `$call` to
#' save memory, after which `stats::model.matrix(fit)` errors (fixest tries to
#' re-fetch the now-removed data). Before slimming, `fit_model()` caches fit3's
#' design matrix in `attr(fit, "wise_mm")`. This helper returns that cached
#' matrix when present and otherwise recomputes (for unslimmed fits, or
#' non-fit3 fits that were never cached).
#'
#' @param model A fitted model object (typically `fixest`).
#'
#' @return A data frame design matrix, or `NULL` if it cannot be resolved.
#'
#' @export
resolve_model_matrix <- function(model) {
  cached <- attr(model, "wise_mm")
  if (!is.null(cached)) {
    return(as.data.frame(cached))
  }
  tryCatch(
    as.data.frame(stats::model.matrix(model)),
    error = function(e) NULL
  )
}


#' Extract the median quantile model from a RIF fixest_multi
#'
#' For diagnostic functions that require a single fixest model, this extracts
#' the median quantile (tau = 0.5, index 5) from the 9-quantile stack.
#' Returns the input unchanged for non-RIF engines.
#'
#' @param fit    A model object (fixest_multi for RIF, or single model).
#' @param engine Scalar character engine key.
#'
#' @return A single fixest model object.
#'
#' @export
extract_rif_median <- function(fit, engine = "fixest") {
  if (identical(engine, "rif") && (inherits(fit, "fixest_multi") || is.list(fit))) {
    # Index 5 = tau = 0.5 (median)
    idx <- min(5L, length(fit))
    fit[[idx]]
  } else {
    fit
  }
}


#' Test whether a fit_model result represents a logistic model
#'
#' Checks `model_type` in the list returned by `fit_model()`.
#'
#' @param fit_list Named list returned by `fit_model()`, containing at least
#'   `$model_type` and `$engine`.
#'
#' @return Scalar logical.
#'
#' @export
is_logistic_fit <- function(fit_list) {
  mt <- tolower(fit_list$model_type %||% "")
  isTRUE(grepl("logistic|logit|binary", mt))
}




#' Get first displayed bin label for a binned weather variable
#'
#' Uses factor level order when present, otherwise sorted unique character values.
#'
#' @param df A data frame containing column `hv`.
#' @param hv Scalar character. Weather variable column name.
#'
#' @return Character scalar first bin label, or `NA_character_`.
#' @export
get_first_bin_label <- function(df, hv) {
  if (is.null(df) || is.na(hv) || !(hv %in% names(df))) {
    return(NA_character_)
  }

  x <- df[[hv]]
  x <- x[!is.na(x)]
  if (length(x) == 0) {
    return(NA_character_)
  }

  labels <- if (is.factor(x)) levels(x) else sort(unique(as.character(x)))
  if (length(labels) == 0) {
    return(NA_character_)
  }

  labels[[1]]
}

# Plot / table builders ----




#' Tidy regression results behind the Step 1 coefficient table
#'
#' Returns the estimates behind the coefficient table as one long data frame
#' so the "Download CSV" link under the table hands over usable numbers.
#'
#' @param fit1,fit2,fit3 fixest model objects (ignored on the RIF path).
#' @param engine    Estimation engine; `"rif"` reads `rif_grid` instead.
#' @param rif_grid  RIF coefficient grid (term, tau, model, estimate, ...).
#' @param label_fun Function mapping variable names to human labels.
#'
#' @return A data.frame, or NULL when nothing can be extracted.
#' @noRd
make_regtable_df <- function(fit1, fit2, fit3,
                             engine = "fixest",
                             rif_grid = NULL,
                             label_fun = identity) {
  # --- RIF: one row per (term, quantile) from the full specification --------
  if (identical(engine, "rif") && !is.null(rif_grid)) {
    g <- rif_grid[rif_grid$model == 3L, , drop = FALSE]
    if (nrow(g) == 0) {
      return(NULL)
    }
    keep <- intersect(
      c("term", "tau", "estimate", "std.error", "statistic", "p.value"),
      names(g)
    )
    out <- g[order(g$term, g$tau), keep, drop = FALSE]
    out$term <- vapply(as.character(out$term), function(x) {
      lbl <- tryCatch(label_fun(x), error = function(e) x)
      if (length(lbl) == 1 && !is.na(lbl) && nzchar(lbl)) lbl else x
    }, character(1))
    # Same column names as the fixest branch below, so both engines export a
    # CSV with the same header.
    rename <- c(
      term = "Variable", tau = "Quantile", estimate = "Estimate",
      std.error = "Std. error", statistic = "Statistic",
      p.value = "p value"
    )
    hit <- names(out) %in% names(rename)
    names(out)[hit] <- unname(rename[names(out)[hit]])
    out$Model <- "(3) FE + Controls"
    front <- intersect(c("Model", "Variable", "Quantile"), names(out))
    return(out[, c(front, setdiff(names(out), front)), drop = FALSE])
  }

  # --- fixest: one row per (specification, term) ----------------------------
  specs <- list(
    "(1) No FE"           = fit1,
    "(2) FE"              = fit2,
    "(3) FE + Controls"   = fit3
  )
  rows <- lapply(names(specs), function(nm) {
    fit <- specs[[nm]]
    if (!inherits(fit, "fixest")) {
      return(NULL)
    }
    ct <- tryCatch(.fixest_coeftable(fit), error = function(e) NULL)
    if (is.null(ct) || nrow(ct) == 0) {
      return(NULL)
    }
    terms <- rownames(ct)
    data.frame(
      Model = nm,
      Variable = vapply(terms, function(x) {
        lbl <- tryCatch(label_fun(x), error = function(e) x)
        if (length(lbl) == 1 && !is.na(lbl) && nzchar(lbl)) lbl else x
      }, character(1)),
      Term = terms,
      Estimate = unname(ct[, 1]),
      `Std. error` = unname(ct[, 2]),
      `p value` = unname(ct[, 4]),
      Observations = tryCatch(stats::nobs(fit), error = function(e) NA_integer_),
      check.names = FALSE,
      stringsAsFactors = FALSE,
      row.names = NULL
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (length(rows) == 0) {
    return(NULL)
  }
  do.call(rbind, rows)
}


# Model fit diagnostic plots ----

# Clean label for a cut()-style bin level: "[22.1, 26.6]" or "t(26.6, 28.4]"
# -> "22.1 - 26.6". Falls back to the trimmed input for odd shapes.
.cut_bin_label <- function(lvl) {
  s <- trimws(lvl)
  if (startsWith(s, "t(") || startsWith(s, "t[")) s <- substr(s, 2, nchar(s))
  if (startsWith(s, "[") || startsWith(s, "(")) s <- substr(s, 2, nchar(s))
  if (endsWith(s, "]") || endsWith(s, ")")) s <- substr(s, 1, nchar(s) - 1)
  parts <- strsplit(s, ",", fixed = TRUE)[[1]]
  if (length(parts) == 2) {
    paste0(trimws(parts[1]), " \u2013 ", trimws(parts[2]))
  } else {
    trimws(s)
  }
}

#' Compute model fit statistics as a data frame
#'
#' Returns a two-column data frame (`Statistic`, `Value`) using
#' `fixest::fitstat()` / `fixest::r2()`. R-squared style statistics use the
#' same formatting as the At-a-glance fit snippet (`<0.01` below 0.005,
#' an em dash when unavailable) so the two never appear to disagree.
#'
#' @param model       A native fixest model object (or a list / fixest_multi
#'   of per-quantile models for the RIF engine).
#' @param is_logistic Scalar logical.
#' @param engine      Scalar character engine key (`"rif"` switches to the
#'   per-quantile table).
#' @param taus        Optional numeric vector of RIF quantiles; defaults to
#'   `seq(0.1, 0.9, by = 0.1)` when `engine = "rif"`.
#'
#' @return A data frame with columns `Statistic` and `Value` (RIF: one row
#'   per quantile with columns `Quantile`, `N`, `R^2`, `Within R^2`).
#'
#' @export
calc_fit_stats <- function(model, is_logistic, engine = "fixest", taus = NULL) {
  fmt_r2 <- function(x) {
    x <- suppressWarnings(as.numeric(x))
    if (!is.finite(x)) {
      "\u2014"
    } else if (x < 0.005) {
      "<0.01"
    } else {
      sprintf("%.2f", x)
    }
  }
  fmt_int <- function(x) {
    x <- suppressWarnings(as.numeric(x))
    if (!is.finite(x)) "\u2014" else formatC(x, format = "f", digits = 0, big.mark = ",")
  }

  # RIF: per-quantile R^2 table
  if (identical(engine, "rif") && (inherits(model, "fixest_multi") || is.list(model))) {
    taus <- taus %||% seq(0.1, 0.9, by = 0.1)
    n <- min(length(model), length(taus))
    rows <- lapply(seq_len(n), function(i) {
      v <- .fit_stat_values(model[[i]], FALSE)
      row_i <- data.frame(
        Quantile = paste0("\u03c4 = ", sprintf("%g", taus[i])),
        N = fmt_int(v[["nobs"]]),
        R2 = fmt_r2(v[["r2"]]),
        stringsAsFactors = FALSE
      )
      row_i[["Within R\u00b2"]] <- fmt_r2(v[["wr2"]])
      names(row_i) <- c("Quantile", "N", "R\u00b2", "Within R\u00b2")
      row_i
    })
    return(do.call(rbind, rows))
  }

  v <- .fit_stat_values(model, is_logistic)
  if (!is_logistic) {
    data.frame(
      Statistic = c("Observations", "R\u00b2", "Adj. R\u00b2", "Within R\u00b2"),
      Value = c(fmt_int(v[["nobs"]]), fmt_r2(v[["r2"]]), fmt_r2(v[["ar2"]]), fmt_r2(v[["wr2"]])),
      stringsAsFactors = FALSE
    )
  } else {
    data.frame(
      Statistic = c("Observations", "McFadden R\u00b2", "AIC"),
      Value = c(fmt_int(v[["nobs"]]), fmt_r2(v[["pr2"]]), fmt_int(v[["aic"]])),
      stringsAsFactors = FALSE
    )
  }
}

# Raw fit statistics of one model, `NA` where a statistic cannot be computed:
# observations, R2, adjusted R2 and within R2 (linear); observations,
# McFadden R2 and AIC (binary).
.fit_stat_values <- function(model, is_logistic) {
  num <- function(expr) tryCatch(suppressWarnings(as.numeric(expr)), error = function(e) NA_real_)
  nobs <- num(stats::nobs(model))
  if (!is_logistic) {
    return(c(
      nobs = nobs,
      r2 = num(fixest::r2(model, "r2")),
      ar2 = num(fixest::r2(model, "ar2")),
      wr2 = num(fixest::r2(model, "wr2"))
    ))
  }
  pr2 <- tryCatch(suppressWarnings(as.numeric(fixest::r2(model, "pr2"))), error = function(e) {
    # fixest::r2() only knows fixest models; fall back to McFadden from
    # the log-likelihoods so stats::glm fits are covered too.
    ll <- tryCatch(as.numeric(stats::logLik(model)), error = function(e2) NA_real_)
    ll0 <- tryCatch(
      {
        y <- stats::model.response(stats::model.frame(model))
        p0 <- mean(y)
        if (p0 <= 0 || p0 >= 1) {
          NA_real_
        } else {
          sum(y * log(p0) + (1 - y) * log(1 - p0))
        }
      },
      error = function(e2) NA_real_
    )
    1 - ll / ll0
  })
  c(nobs = nobs, pr2 = pr2, aic = num(stats::AIC(model)))
}

#' Raw model fit statistics, one row per statistic
#'
#' The values behind `calc_fit_stats()` before formatting: `nobs`, `r2`, `ar2`,
#' `wr2` (linear and RIF) or `nobs`, `pr2`, `aic` (binary). RIF models give
#' the statistics of every quantile.
#'
#' @inheritParams calc_fit_stats
#' @return A data frame: `tau` (`NA` unless RIF), `statistic`, `value`.
#' @noRd
fit_stats_raw <- function(model, is_logistic, engine = "fixest", taus = NULL) {
  one <- function(m, tau, logistic) {
    v <- .fit_stat_values(m, logistic)
    data.frame(tau = tau, statistic = names(v), value = unname(v), stringsAsFactors = FALSE)
  }
  if (identical(engine, "rif") && (inherits(model, "fixest_multi") || is.list(model))) {
    taus <- taus %||% seq(0.1, 0.9, by = 0.1)
    n <- min(length(model), length(taus))
    out <- lapply(seq_len(n), function(i) one(model[[i]], taus[i], FALSE))
    out <- do.call(rbind, out)
    return(out[out$statistic %in% c("nobs", "r2", "wr2"), , drop = FALSE])
  }
  one(model, NA_real_, is_logistic)
}




# Echarts counterparts of the Results / Model fit figures (guidelines section 7) ----
# Static ggplot renderers are archived under dev/archive/static_plots; these interactive
# echarts4r widgets draw the same statistics, computed with the same parameters.

# Transparent polygon band (lo..hi) plus an estimate line: the echarts idiom
# replacing a static ribbon geom. Returns three series (dummy, polygon band, line)
# to preserve 3-series index compatibility for all callers.
.e_ribbon_series <- function(nm, x, est, lo, hi, fill, line,
                             line_width = 2, show_points = FALSE,
                             point_size = 5, z = 2) {
  stopifnot(length(x) == length(est), length(lo) == length(x),
            length(hi) == length(x))
  ok <- is.finite(x) & is.finite(est) & is.finite(lo) & is.finite(hi)
  x <- x[ok]
  est <- est[ok]
  lo <- lo[ok]
  hi <- hi[ok]
  if (!length(x)) {
    return(NULL)
  }
  ord <- order(x)
  x <- x[ord]
  est <- est[ord]
  lo <- lo[ord]
  hi <- hi[ord]

  js_ribbon <- htmlwidgets::JS("function(params, api) {
    if (params.dataIndex !== 0) return;
    var count = params.dataInsideLength || 0;
    if (!count) return;
    var pts = [];
    for (var i = 0; i < count; i++) {
      pts.push(api.coord([api.value(0, i), api.value(2, i)]));
    }
    for (var i = count - 1; i >= 0; i--) {
      pts.push(api.coord([api.value(0, i), api.value(3, i)]));
    }
    return {
      type: 'polygon',
      shape: { points: pts },
      style: { fill: api.visual('color'), opacity: 0.18 }
    };
  }")

  band_data <- lapply(seq_along(x), function(i) list(x[i], est[i], hi[i], lo[i]))
  line_data <- lapply(seq_along(x), function(i) {
    list(
      value = list(x[i], est[i]), confLow = lo[i], confHigh = hi[i]
    )
  })

  list(
    list(
      name = nm, type = "line", data = list(), symbol = "none", silent = TRUE, z = z,
      lineStyle = list(opacity = 0), itemStyle = list(color = fill, opacity = 1),
      tooltip = list(show = FALSE), legendHoverLink = FALSE
    ),
    list(
      name = nm, type = "custom",
      renderItem = js_ribbon,
      data = band_data,
      itemStyle = list(color = fill),
      areaStyle = list(color = fill, opacity = 0.18),
      silent = TRUE, z = z,
      tooltip = list(show = FALSE), legendHoverLink = FALSE
    ),
    list(
      name = nm, type = "line", data = line_data, symbol = if (show_points) "circle" else "none", z = z + 1,
      lineStyle = list(color = line, width = line_width),
      itemStyle = list(color = line),
      symbolSize = if (show_points) point_size else 1,
      showSymbol = show_points
    )
  )
}

.e_effect_tooltip <- function(percent = FALSE, trigger = "axis", label_prefix = NULL) {
  fmt <- if (percent) {
    "function(v){var n=Number(v); return isFinite(n) ? n.toLocaleString('en-US',{minimumFractionDigits:1,maximumFractionDigits:1})+'%' : '';}"
  } else {
    "function(v){var n=Number(v); return isFinite(n) ? n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}) : '';}"
  }
  prefix <- if (is.null(label_prefix)) {
    "p.seriesName||'Effect'"
  } else {
    paste0("'", gsub("'", "\\\\'", label_prefix), " ' + (p.seriesName||'Effect')")
  }
  html <- sprintf(
    "function(params){var rows=[];(params||[]).forEach(function(p){var d=p.data||{};var v=Array.isArray(p.value)?p.value[1]:p.value;var lo=d.confLow,hi=d.confHigh;var text=(%s)+': <b>'+((%s)(v))+'</b>';if(isFinite(Number(lo))&&isFinite(Number(hi)))text+='<br/>95%% CI: ['+(%s)(lo)+', '+(%s)(hi)+']';rows.push(text);});return rows.join('<br/>');}",
    prefix, fmt, fmt, fmt
  )
  list(trigger = trigger, formatter = htmlwidgets::JS(html))
}

#' Echarts coefficient plot across three progressive model fits
#'
#' Interactive coefficient stability plot (guidelines section 7), with 95% CI
#' whiskers, wrapped labels and specification colours. RIF coefficients are
#' filtered to one selected welfare quantile.
#'
#' @param fit1,fit2,fit3 The three progressive model fits (weather only, plus
#'   fixed effects, plus fixed effects and controls) from `fit_model()`.
#' @param weather_terms Character vector of weather term names in the model.
#' @param interaction_terms Character vector of interaction term names.
#' @param outcome_label Display label of the outcome, used in axis text.
#' @param label_fun Function mapping variable names to display labels.
#' @param engine Scalar character engine key (e.g. `"fixest"`, `"rif"`).
#' @param rif_grid Coefficient grid across quantiles for RIF fits, else `NULL`.
#' @param pred_var Scalar character weather variable to plot; `NULL` plots all
#'   `weather_terms`. Required for RIF fits.
#' @param x_label Optional x-axis label; `NULL` uses a default.
#' @param has_controls Logical. Whether the third specification includes
#'   controls (changes its legend label).
#' @param height Widget height; a CSS length or a number of pixels.
#' @param tau Scalar quantile used for RIF coefficient stability plots.
#' @param train_data Optional training data frame, used to centre polynomial
#'   terms of `pred_var` at its mean for RIF fits.
#'
#' @return An `echarts4r` widget, or `NULL`.
#'
#' @export
echart_make_coefplot <- function(fit1, fit2, fit3,
                                 weather_terms,
                                 interaction_terms,
                                 outcome_label = "outcome",
                                 label_fun = identity,
                                 engine = "fixest",
                                 rif_grid = NULL,
                                 pred_var = NULL,
                                 x_label = NULL,
                                 has_controls = TRUE,
                                 height = "600px",
                                 tau = NULL,
                                 train_data = NULL) {
  lab3 <- "FE + covariates"
  if (identical(engine, "rif")) {
    if (is.null(rif_grid) || is.null(pred_var)) {
      return(echart_blank("No RIF coefficients found to plot.", height = height))
    }
    term_has_predictor <- function(term) {
      parts <- strsplit(as.character(term), ":", fixed = TRUE)[[1L]]
      any(vapply(parts, function(part) {
        tokens <- regmatches(part, gregexpr("[[:alnum:]_.]+", part))[[1L]]
        pred_var %in% tokens
      }, logical(1)))
    }
    term_match <- vapply(rif_grid$term, term_has_predictor, logical(1))
    grid <- rif_grid[term_match, , drop = FALSE]
    if (!nrow(grid)) {
      return(echart_blank(paste0("No RIF coefficients found for '", pred_var, "'."), height = height))
    }
    taus <- sort(unique(grid$tau))
    tau <- suppressWarnings(as.numeric(tau)[1L])
    selected_tau <- if (is.null(tau) || !length(tau) || !is.finite(tau)) {
      if (0.5 %in% taus) 0.5 else taus[[which.min(abs(taus - 0.5))]]
    } else {
      taus[[which.min(abs(taus - tau))]]
    }
    grid <- grid[grid$tau == selected_tau, , drop = FALSE]
    grid$model <- dplyr::case_when(
      grid$model == 1L ~ "No FE or covariates",
      grid$model == 2L ~ "No covariates",
      TRUE ~ lab3
    )
    grid$Estimate <- grid$estimate
    grid$.term <- grid$term
    if (!"conf.low" %in% names(grid)) grid$conf.low <- grid$Estimate - 1.96 * grid$std.error
    if (!"conf.high" %in% names(grid)) grid$conf.high <- grid$Estimate + 1.96 * grid$std.error
    combined_poly <- FALSE
    poly_terms <- unique(grid$term[
      vapply(grid$term, term_has_predictor, logical(1)) &
        grepl(paste0("I(", pred_var, "^"), grid$term, fixed = TRUE)
    ])
    if (pred_var %in% grid$term && length(poly_terms)) {
      x_mean <- NA_real_
      if (!is.null(train_data) && pred_var %in% names(train_data)) {
        x_mean <- mean(as.numeric(train_data[[pred_var]]), na.rm = TRUE)
      }
      fit3_model <- tryCatch({
        if (inherits(fit3, "fixest_multi") && length(fit3) >= 5L) fit3[[5L]] else fit3
      }, error = function(e) NULL)
      mm <- if (!is.null(fit3_model)) resolve_model_matrix(fit3_model) else NULL
      if (!is.finite(x_mean) && !is.null(mm) && pred_var %in% names(mm)) {
        x_mean <- mean(as.numeric(mm[[pred_var]]), na.rm = TRUE)
      }
      if (!is.finite(x_mean)) x_mean <- 0
      poly_power <- function(term) {
        power <- regmatches(term, regexpr("[0-9]+", term))
        suppressWarnings(as.integer(power))
      }
      related <- c(pred_var, poly_terms)
      selected <- grid[grid$.term %in% related, , drop = FALSE]
      groups <- split(selected, interaction(selected$model, selected$tau, drop = TRUE))
      model_fits <- list(fit1, fit2, fit3)
      names(model_fits) <- c("No FE or covariates", "No covariates", lab3)
      combined <- lapply(groups, function(d) {
        weights <- vapply(d$.term, function(term) {
          if (identical(term, pred_var)) return(1)
          p <- poly_power(term)
          p * x_mean^(p - 1L)
        }, numeric(1))
        estimate <- sum(weights * d$Estimate, na.rm = TRUE)
        se <- .rif_combined_se(
          .rif_subfit(model_fits[[d$model[1L]]], taus, d$tau[1L]),
          d$.term, weights, d$std.error
        )
        row <- d[1L, , drop = FALSE]
        row$Estimate <- estimate
        row$std.error <- se
        row$conf.low <- estimate - 1.96 * se
        row$conf.high <- estimate + 1.96 * se
        row$term <- pred_var
        row
      })
      grid <- do.call(rbind, combined)
      grid$term <- pred_var
      combined_poly <- TRUE
    }
    coef_map <- make_coef_map(unique(grid$term), label_fun)
    grid$label <- unname(names(coef_map)[match(grid$term, unname(coef_map))])
    grid$label[is.na(grid$label)] <- grid$term[is.na(grid$label)]
    term_order <- unique(grid$term[order(grepl(":", grid$term), grid$term)])
    grid$label_wrap <- factor(
      stringr::str_wrap(grid$label, 25),
      levels = rev(unique(stringr::str_wrap(grid$label[match(term_order, grid$term)], 25)))
    )
    coef_data <- grid
  } else {
    if (!requireNamespace("fixest", quietly = TRUE)) {
      return(echart_blank("Package 'fixest' is required.", height = height))
    }
  model_list <- list("No FE or covariates" = fit1, "No covariates" = fit2)
  model_list[[lab3]] <- fit3

  coef_data <- tryCatch({
    d <- do.call(rbind, lapply(names(model_list), function(model_name) {
      ct <- tryCatch(.fixest_coeftable(model_list[[model_name]]),
        error = function(e) NULL
      )
      if (is.null(ct)) {
        return(NULL)
      }
      ct$term <- rownames(ct)
      ct$model <- model_name
      ct
    }))
    if (is.null(d)) {
      return(NULL)
    }
    filter_terms <- if (!is.null(pred_var)) pred_var else weather_terms
    keep_terms <- weather_coef_names(fit3, filter_terms)
    d <- d[d$term %in% keep_terms, , drop = FALSE]
    if (nrow(d) == 0) {
      return(NULL)
    }
    coef_map <- make_coef_map(keep_terms, label_fun)
    d$label <- names(coef_map)[match(d$term, coef_map)]
    d$label <- ifelse(is.na(d$label), d$term, d$label)
    d$conf.low <- d$Estimate - 1.96 * d$`Std. Error`
    d$conf.high <- d$Estimate + 1.96 * d$`Std. Error`
    d$label_wrap <- stringr::str_wrap(d$label, 25)

    term_esc <- gsub("([\\[\\]\\(\\)\\^\\$\\.\\*\\+\\?])", "\\\\\\1", filter_terms)
    weather_pattern <- paste0("\\b(", paste(term_esc, collapse = "|"), ")\\b")
    protected <- gsub("::", "", d$term, fixed = TRUE)
    parts <- strsplit(protected, ":", fixed = TRUE)
    main_part <- vapply(parts, function(p) {
      hit <- p[grepl(weather_pattern, p)]
      if (length(hit) == 0) p[1] else hit[1]
    }, character(1))
    is_int <- lengths(parts) > 1
    ord <- order(match(main_part, unique(main_part)), is_int)
    label_levels <- unique(d$label_wrap[ord])
    d$label_wrap <- factor(d$label_wrap, levels = rev(label_levels))
    d
  }, error = function(e) NULL)
  }

  if (is.null(coef_data) || !nrow(coef_data)) {
    return(echart_blank("No weather coefficients found to plot.", height = height))
  }

  model_levels <- c("No FE or covariates", "No covariates", lab3)
  model_cols <- c(
    "No FE or covariates" = "#8C8C8C",
    "No covariates" = .wise_charcoal,
    setNames(.wise_blue, lab3)
  )
  dodges <- c(-0.28, 0, 0.28)

  labels <- rev(levels(coef_data$label_wrap))
  y_cats <- labels
  e <- .e_new(height)
  series <- lapply(seq_along(model_levels), function(i) {
    nm <- model_levels[i]
    d <- coef_data[coef_data$model == nm, , drop = FALSE]
    if (!nrow(d)) {
      return(NULL)
    }
    col <- unname(model_cols[[nm]])
    dy <- dodges[i]
      pts <- lapply(seq_len(nrow(d)), function(j) {
        cat_idx <- match(as.character(d$label_wrap[j]), y_cats)
        list(value = list(d$Estimate[j], cat_idx + dy),
          confLow = d$conf.low[j], confHigh = d$conf.high[j])
    })
    whiskers <- lapply(seq_len(nrow(d)), function(j) {
      cat_idx <- match(as.character(d$label_wrap[j]), y_cats)
      list(
        list(coord = list(d$conf.low[j], cat_idx + dy)),
        list(coord = list(d$conf.high[j], cat_idx + dy))
      )
    })
    ml_data <- whiskers
    if (i == 1L) {
      ml_data <- c(
        list(list(
          xAxis = 0,
          lineStyle = list(color = .wise_zero, type = "dashed", width = 1),
          symbol = list("none", "none")
        )),
        whiskers
      )
    }
    list(
      name = nm, type = "scatter",
      data = pts,
       symbol = "circle", symbolSize = 8,
      itemStyle = list(color = col),
         markLine = list(
         symbol = list("none", "none"),
         symbolSize = list(0, 0),
        silent = TRUE, animation = FALSE,
        lineStyle = list(color = col, width = 1.5, type = "solid"),
        label = list(show = FALSE),
        data = ml_data
      )
    )
  })
  series <- purrr::compact(series)
  e$x$opts$series <- series

  x_min_val <- min(c(0, coef_data$conf.low), na.rm = TRUE)
  x_max_val <- max(c(0, coef_data$conf.high), na.rm = TRUE)
  x_pad <- max((x_max_val - x_min_val) * 0.08, 0.02)

  e$x$opts$xAxis <- list(
    type = "value", scale = TRUE,
    min = round(x_min_val - x_pad, 2),
    max = round(x_max_val + x_pad, 2),
    name = x_label %||% stringr::str_wrap(paste0("Effect on ", outcome_label), 50),
    nameLocation = "middle", nameGap = 30,
           nameTextStyle = wise_eaxis_name(align = "center"),
    axisLabel = wise_eaxis_label(showMinLabel = FALSE, showMaxLabel = FALSE),
    splitLine = wise_esplit_line()
  )
  e$x$opts$yAxis <- list(
    type = "value", min = 0, max = length(y_cats) + 1,
    interval = 1, inverse = TRUE,
    axisLabel = wise_eaxis_label(
      fontSize = 11, formatter = .e_index_formatter(y_cats),
      showMinLabel = TRUE, showMaxLabel = TRUE
    ),
    axisLine = list(lineStyle = list(color = .wise_grid)),
    splitLine = wise_esplit_line()
  )
  e$x$opts$legend <- wise_elegend_style(left = "center", top = 0, orient = "horizontal")
  e$x$opts$grid <- list(containLabel = TRUE, left = 8, right = 20, top = 42, bottom = 28)
  if (identical(engine, "rif") && combined_poly) {
    e <- .e_caption(e, paste(
      "Polynomial weather terms combined to total marginal effect at sample mean;",
      "95% CI assumes zero covariance across RIF coefficients."
    ))
    e$x$opts$grid$bottom <- e$x$opts$grid$bottom + 24
  }
  e$x$opts$tooltip <- list(
    trigger = "item",
    formatter = htmlwidgets::JS(
      "function(p){var d=p.data||{};var v=Array.isArray(d.value)?Number(d.value[0]):NaN;if(!isFinite(v))return '';var f=function(x){return Number(x).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});};var ci=isFinite(Number(d.confLow))&&isFinite(Number(d.confHigh))?'<br/>95% CI: ['+f(d.confLow)+', '+f(d.confHigh)+']':'';return (p.seriesName||'Effect')+': <b>'+f(v)+'</b>'+ci;}"
    )
  )
  wise_echart_theme(e)
}


# Shared echarts fragments for the effect / diagnostics builders (guidelines
# section 7). Keep these tiny and generic; branch-specific layout stays in the
# builders below.

# Horizontal dashed y = 0 reference (geom_hline(yintercept = 0) counterpart).
.e_zero_line <- function() {
  list(
    symbol = "none", silent = TRUE, animation = FALSE,
    label = list(show = FALSE),
    lineStyle = list(color = .wise_zero, type = "dashed", width = 1),
    data = list(list(yAxis = 0))
  )
}

# Percent-share axis labels (scales::percent_format counterpart).
.e_percent_formatter <- function() {
  htmlwidgets::JS("function(v){return Math.round(100*v)+'%';}")
}

# Numeric-axis label formatter backed by an R-side lookup table (index ->
# label), the echarts counterpart of scale_x_continuous(breaks, labels).
.e_index_formatter <- function(labels) {
  htmlwidgets::JS(paste0(
    "function(v){var m=",
    jsonlite::toJSON(stats::setNames(as.list(labels), as.character(seq_along(labels)))),
    ";return m[String(Math.round(v))]||'';}"
  ))
}

# Bottom-anchored, left-aligned sub-text carrying the ggplot caption. ECharts
# titles do not reserve layout space, so callers give the grid extra room.
.e_caption <- function(e, caption) {
  if (is.null(caption) || !nzchar(caption)) {
    return(e)
  }
  e$x$opts$title <- c(e$x$opts$title %||% list(), list(
    list(
      text = "", subtext = caption, left = 8, bottom = 0,
      textAlign = "left",
      subtextStyle = list(
        color = .wise_slate, fontSize = 11, fontWeight = "normal"
      )
      )
  ))

  get_axis_types <- function(axes) {
    if (is.null(axes)) return(character(0))
    axis_fields <- c("type", "axisLabel", "axisTick", "data", "gridIndex", "show")
    single_axis <- !is.null(names(axes)) && any(names(axes) %in% axis_fields)
    axis_list <- if (single_axis) list(axes) else axes
    vapply(axis_list, function(axis) {
      if (!is.list(axis)) return("value")
      axis[["type"]] %||% "value"
    }, character(1))
  }
  axis_type <- c(get_axis_types(e$x$opts$xAxis), get_axis_types(e$x$opts$yAxis))
  if (length(axis_type) && all(axis_type %in% c("value", "log", "time"))) {
    grids <- e$x$opts$grid
    if (!is.null(grids)) {
      grid_fields <- c("left", "right", "top", "bottom", "width", "height",
        "containLabel", "show", "backgroundColor", "borderColor", "borderWidth",
        "shadowBlur", "shadowColor", "shadowOffsetX", "shadowOffsetY")
      single_grid <- !is.null(names(grids)) && any(names(grids) %in% grid_fields)
      grid_list <- if (single_grid) list(grids) else grids
      grid_list <- lapply(grid_list, function(grid) {
        left <- suppressWarnings(as.numeric(sub("px$", "", as.character(grid$left))))
        if (length(left) == 1L && is.finite(left)) {
          grid$left <- max(left, 64)
          grid$containLabel <- FALSE
        }
        grid
      })
      e$x$opts$grid <- if (single_grid) grid_list[[1L]] else grid_list
    }
  }
  e
}

# Dashed vertical tau reference marks with small top labels (mark_taus arg).
.e_tau_mark_data <- function(taus) {
  lapply(taus, function(t) {
    list(
      xAxis = t,
      lineStyle = list(color = .wise_zero, type = "dashed", width = 1),
      label = list(
        show = TRUE, position = "end",
        formatter = paste0("\u03c4 = ", formatC(t, format = "f", digits = 1)),
        color = .wise_slate, fontSize = 10
      )
    )
  })
}


#' Echarts weather effect plot (continuous, binned and RIF branches)
#'
#' Interactive weather effect chart with continuous, binned, and RIF branches.
#' Shared data preparation is drawn as an
#' `echarts4r` widget. Branch map:
#'
#' \itemize{
#'   \item RIF, binned predictor without interactions: one beta(tau) curve per
#'     bin, faceted one panel per bin (echarts grids) when there is more than
#'     one bin.
#'   \item RIF, single term: a single beta(tau) curve panel.
#'   \item RIF, main + interactions: combined effect per moderator level
#'     (or the across-moderator average in `mode = "main"`), one panel per
#'     bin when the predictor is binned.
#'   \item Binned without moderator: bin pointrange + connecting line.
#'   \item Binned with moderator: per-moderator overlay with dodged
#'     pointranges.
#'   \item Continuous: marginal-effect line with 95% CI ribbon, observed-
#'     value rug along the bottom edge and a dashed mean reference.
#'   \item Continuous with moderator: per-moderator marginal-effect curves.
#' }
#'
#' Captions render as a small slate sub-text anchored bottom-left (echarts
#' has no plot.caption slot); call-side captions pass through unchanged.
#'
#' @param fit A fitted model (single `fixest` model, or the RIF
#'   multi-quantile fit).
#' @param pred_var Scalar character name of the weather variable plotted.
#' @param interaction_terms Character vector of interaction term names; those
#'   involving `pred_var` define the moderator.
#' @param is_binned Logical. Whether `pred_var` enters the model as bins.
#' @param label_fun Function mapping variable names to display labels.
#' @param engine Scalar character engine key (e.g. `"fixest"`, `"rif"`).
#' @param selected_weather Currently unused; kept so existing callers still
#'   work.
#' @param weather_df Optional data frame holding `pred_var`, used for the
#'   observed-value rug, mean reference and bin ordering.
#' @param rif_grid Coefficient grid across quantiles for RIF fits, else `NULL`.
#' @param mode One of `"auto"`, `"main"` or `"moderated"`. For RIF fits with
#'   interactions, `"main"` shows the across-moderator average and
#'   `"moderated"` requires a moderator.
#' @param is_logistic Logical. Whether the model is a binary-outcome model.
#' @param x_label,y_label Optional axis labels; `NULL` uses defaults.
#' @param caption Optional caption drawn bottom-left.
#' @param show_rug Logical. Draw the observed-value rug (continuous only).
#' @param show_mean_ref Logical. Draw the dashed mean reference
#'   (continuous only).
#' @param mark_taus Optional numeric quantiles at which to draw dashed
#'   vertical reference marks on RIF curves.
#' @param effect_scale One of `"model"`, `"pp"`, `"pp100"` or `"pct"`. `"pp"`
#'   converts logistic effects to percentage points at `profile_eta`;
#'   `"pp100"` multiplies estimates by 100; `"pct"` leaves values unchanged but
#'   formats them as percent; `"model"` leaves model units.
#' @param profile_eta Scalar linear-predictor value at which logistic effects
#'   are converted to percentage points when `effect_scale = "pp"`.
#' @param height Widget height; a CSS length or a number of pixels.
#'
#' @return An `echarts4r` widget.
#'
#' @export
echart_weather_effect_plot <- function(fit, pred_var, interaction_terms, is_binned,
                                       label_fun, engine, selected_weather = NULL,
                                       weather_df = NULL, rif_grid = NULL,
                                       mode = "auto", is_logistic = FALSE,
                                       x_label = NULL, y_label = NULL,
                                       caption = NULL,
                                       show_rug = TRUE, show_mean_ref = TRUE,
                                       mark_taus = NULL,
                                       effect_scale = "model",
                                       profile_eta = NULL,
                                       height = "500px") {
  tryCatch(
    {
      mode <- match.arg(mode, c("auto", "main", "moderated"))
      effect_scale <- match.arg(effect_scale, c("model", "pp", "pp100", "pct"))

      # --- data preparation copied verbatim from make_weather_effect_plot() --
      modx_level_label <- function(lab, v) {
        v_chr <- as.character(v)
        if (length(v_chr) != 1) v_chr <- v_chr[[1]]
        num <- suppressWarnings(as.numeric(v_chr))
        if (!is.na(num) && num %in% c(0, 1)) {
          paste0(lab, ": ", if (num == 1) "yes" else "no")
        } else if (!is.na(num)) {
          paste0(lab, " = ", round(num, 2))
        } else {
          paste0(lab, " = ", v_chr)
        }
      }
      .apply_effect_scale <- function(df, est_col = "Estimate",
                                      lo_col = "conf.low", hi_col = "conf.high") {
        if (identical(effect_scale, "pp")) {
          if (!is.finite(profile_eta)) {
            return(df)
          }
          pp_at <- function(b) {
            100 * (stats::plogis(profile_eta + b) -
              stats::plogis(profile_eta))
          }
          df[[est_col]] <- pp_at(df[[est_col]])
          df[[lo_col]] <- pp_at(df[[lo_col]])
          df[[hi_col]] <- pp_at(df[[hi_col]])
        } else if (identical(effect_scale, "pp100")) {
          df[[est_col]] <- 100 * df[[est_col]]
          df[[lo_col]] <- 100 * df[[lo_col]]
          df[[hi_col]] <- 100 * df[[hi_col]]
        }
        df
      }
      .t2_bin_label <- function(term, pred_var) {
        term <- as.character(term)[[1]]
        pred_esc <- gsub("([\\[\\]\\(\\)\\^\\$\\.\\*\\+\\?])", "\\\\\\1", pred_var)
        s <- sub(paste0("^", pred_esc, "[\\[\\(]"), "", term)
        if (identical(s, term)) {
          return(term)
        }
        s <- sub("[])]$", "", s)
        parts <- trimws(strsplit(s, ",", fixed = TRUE)[[1]])
        if (length(parts) != 2L || any(!nzchar(parts))) {
          return(term)
        }
        parts <- gsub("[\\[\\]()]", "", parts)
        paste0(parts[[1]], "\u2013", parts[[2]])
      }
      mm_of <- function(fit) {
        mm <- resolve_model_matrix(fit)
        if (!is.null(mm)) {
          return(mm)
        }
        tryCatch(stats::model.frame(fit), error = function(e) NULL)
      }

      # --- widget plumbing ----------------------------------------------------
      tau_x_axis <- function(taus) {
        list(
          type = "value", min = min(taus), max = max(taus),
          name = "Welfare quantile",
          nameLocation = "middle", nameGap = 28,
            nameTextStyle = wise_eaxis_name(),
          axisLabel = modifyList(
            wise_eaxis_label(),
            list(formatter = .e_percent_formatter())
          ),
          splitLine = wise_esplit_line()
        )
      }
      value_y_axis <- function(name, min_val = NULL, max_val = NULL,
                               vertical_name = FALSE) {
        list(
          type = "value", scale = is.null(min_val), name = name,
          min = min_val, max = max_val,
          nameLocation = if (vertical_name) "middle" else "end",
          nameRotate = if (vertical_name) 90 else 0,
          nameGap = if (vertical_name) 44 else 8,
          nameTextStyle = if (vertical_name) wise_eaxis_name() else wise_eyaxis_name(),
           axisLabel = wise_eaxis_label(),
          splitLine = wise_esplit_line()
        )
      }
      rif_y_bounds <- function(d) {
        lo <- min(c(0, d$conf.low), na.rm = TRUE)
        hi <- max(c(0, d$conf.high), na.rm = TRUE)
        pad <- max((hi - lo) * 0.08, 0.02)
        c(lo - pad, hi + pad)
      }
      omitted_bin_note <- function(bin_ids) {
        observed <- unique(vapply(bin_ids, function(b) .t2_bin_label(b, pred_var), character(1)))
        observed <- observed[nzchar(observed)]
        all_bins <- character(0)
        if (!is.null(weather_df) && pred_var %in% names(weather_df)) {
          values <- weather_df[[pred_var]]
          raw_levels <- if (is.factor(values)) levels(values) else sort(unique(as.character(values)))
          all_bins <- vapply(raw_levels, .cut_bin_label, character(1))
        }
        omitted <- setdiff(all_bins, observed)
        label <- if (length(omitted)) omitted[[1L]] else "reference bin"
        paste0("Omitted weather bin: ", label, ".")
      }
      # Bin category axis matching ggplot factor bins.
      bin_x_axis <- function(bin_labels, name) {
        list(
          type = "category",
          data = as.character(bin_labels),
          name = name,
          nameLocation = "middle", nameGap = 34,
          nameTextStyle = wise_eaxis_name(align = "center"),
          axisLabel = wise_eaxis_label(rotate = 0),
          axisTick = list(alignWithLabel = TRUE),
          axisLine = list(lineStyle = list(color = .wise_grid)),
          splitLine = wise_esplit_line()
        )
      }
      markline_of <- function(extra_data = list()) {
        ml <- .e_zero_line()
        if (length(extra_data)) ml$data <- c(ml$data, extra_data)
        ml
      }
      grid_pad <- function(legend, cap) {
        8 + 22 * legend + 24 * cap
      }

      # --- RIF branch: weather beta curve across quantiles --------------------
      if (identical(engine, "rif") && !is.null(rif_grid)) {
        pred_esc <- gsub("([\\[\\]\\(\\)\\^\\$\\.\\*\\+\\?])", "\\\\\\1", pred_var)

        grid3 <- rif_grid[rif_grid$model == 3L, ]
        mask <- grepl(paste0("\\b", pred_esc, "\\b"), grid3$term)
        if (!any(mask)) {
          return(echart_blank(paste0("No RIF terms found for '", pred_var, "'."),
            height = height
          ))
        }
        plot_data <- grid3[mask, ]

        taus <- sort(unique(plot_data$tau))
        plot_data$term_label <- vapply(
          plot_data$term, function(t) coef_label(t, label_fun), character(1)
        )

        n_terms <- length(unique(plot_data$term))
        has_int_terms <- any(grepl(":", plot_data$term, fixed = TRUE))
      rif_y_lab <- "Effect size (log points)"

      # Facet panels: shared panel setup (echarts grids).
      panel_ribbon <- function(d, col, panel_idx, point_size, nm = "Effect") {
        d <- d[order(d$tau), ]
        tri <- .e_ribbon_series(
          nm, d$tau, d$estimate, d$conf.low, d$conf.high,
          fill = col, line = col, line_width = 2,
          show_points = TRUE, point_size = point_size
        )
        lapply(tri, function(s) {
          s$xAxisIndex <- panel_idx - 1L
          s$yAxisIndex <- panel_idx - 1L
          s
        })
      }

         is_bin_terms <- all(grepl(
           paste0("^", pred_esc, "[\\[\\(]"),
           unique(plot_data$term)
         ))
         if (n_terms > 1 && !has_int_terms && is_bin_terms) {
          # Binned predictor without interactions: one beta(tau) curve per bin,
          # one facet per bin in numeric bin order (verbatim prep).
          bin_lo <- function(tm) {
            s <- sub(paste0("^", pred_esc, "[\\[\\(]"), "", tm)
            suppressWarnings(as.numeric(sub("^([^,]+),.*", "\\1", s)))
          }
          tu <- unique(plot_data$term)
          tu <- tu[order(suppressWarnings(bin_lo(tu)))]
          lab_map <- stats::setNames(
            vapply(tu, function(t) .t2_bin_label(t, pred_var), character(1)), tu
          )

          e <- .e_new(height)
          e <- .e_multi_grids(
            e, length(tu), titles = paste0("Bin: ", unname(lab_map)), height = height,
            contain_label = FALSE
          )
          series <- unlist(lapply(seq_along(tu), function(i) {
            panel_ribbon(plot_data[plot_data$term == tu[i], ], .wise_blue, i, 7)
          }), recursive = FALSE)
           for (i in seq_along(tu)) {
             idx <- i * 3L
             if (length(series) >= idx) {
               series[[idx]]$markLine <- markline_of(.e_tau_mark_data(mark_taus))
             }
          }
          e$x$opts$series <- series
          e$x$opts$xAxis <- lapply(seq_along(tu), function(i) {
            axis <- tau_x_axis(taus)
            axis$gridIndex <- i - 1L
            axis
          })
           bounds <- rif_y_bounds(plot_data[plot_data$term == tu[[1L]], , drop = FALSE])
           yax <- value_y_axis(rif_y_lab, bounds[[1L]], bounds[[2L]], vertical_name = TRUE)
           e$x$opts$yAxis <- lapply(seq_along(tu), function(i) {
             d_i <- plot_data[plot_data$term == tu[[i]], , drop = FALSE]
             b_i <- rif_y_bounds(d_i)
             axis <- if (i == 1L) {
               yax
             } else {
               y <- value_y_axis("", b_i[[1L]], b_i[[2L]])
               y
             }
              if (i == 1L) axis <- value_y_axis(
                rif_y_lab, b_i[[1L]], b_i[[2L]], vertical_name = TRUE
              )
              axis$gridIndex <- i - 1L
              axis
            })
           e$x$opts$tooltip <- .e_effect_tooltip(
             percent = effect_scale %in% c("pp", "pp100", "pct")
           )
           observed_bins <- unname(lab_map)
           omitted_bins <- character(0)
           if (!is.null(weather_df) && pred_var %in% names(weather_df)) {
             omitted_bins <- setdiff(
               vapply(levels(weather_df[[pred_var]]), .cut_bin_label, character(1)),
               observed_bins
             )
           }
           omitted_label <- if (length(omitted_bins)) omitted_bins[[1L]] else "reference bin"
           e <- .e_caption(e, paste("Ribbon = 95% CI. Omitted weather bin:", omitted_label))
           e$x$opts$grid <- lapply(seq_along(e$x$opts$grid), function(i) {
             modifyList(e$x$opts$grid[[i]], list(bottom = grid_pad(FALSE, TRUE) + 44))
          })
          return(wise_echart_theme(e))
        }

        if (n_terms == 1) {
          # Single term: simple beta curve.
          e <- .e_new(height)
          tri <- panel_ribbon(plot_data, .wise_blue, 1L, 8)
           if (length(tri) >= 3L) {
             tri[[3]]$markLine <- markline_of(.e_tau_mark_data(mark_taus))
           }
          e$x$opts$series <- tri
          e$x$opts$xAxis <- list(tau_x_axis(taus))
           bounds <- rif_y_bounds(plot_data)
           e$x$opts$yAxis <- list(value_y_axis(rif_y_lab, bounds[[1L]], bounds[[2L]]))
          e$x$opts$grid <- list(
            containLabel = TRUE, left = 8, right = 20, top = 14,
            bottom = grid_pad(FALSE, TRUE)
          )
           e$x$opts$tooltip <- .e_effect_tooltip(
             percent = effect_scale %in% c("pp", "pp100", "pct")
           )
          e <- .e_caption(e, "Ribbon = 95% CI")
          return(wise_echart_theme(e))
        }

        if (!is_bin_terms && !has_int_terms) {
          # Polynomial RIF terms describe one continuous weather effect. Plot
          # their mean marginal effect as a single quantile curve rather than
          # treating each polynomial coefficient as a separate bin panel.
          # The RIF fit is a fixest_multi with no model matrix of its own, so
          # centre on the median model's sample (R2-BUG-19).
          median_fit <- if (inherits(fit, "fixest_multi")) fit[[min(5L, length(fit))]] else fit
          mm <- mm_of(median_fit)
          x_mean <- if (!is.null(mm) && pred_var %in% names(mm)) {
            mean(as.numeric(mm[[pred_var]]), na.rm = TRUE)
          } else {
            0
          }
          term_weight <- function(term) {
            if (identical(term, pred_var)) return(1)
            # Polynomial terms appear as I(x^p) or, in RIF grids, I(I(x^p)).
            power <- suppressWarnings(as.numeric(sub(
              paste0("^(I\\()*", pred_esc, "\\^([0-9]+)\\)+$"),
              "\\2", term
            )))
            if (is.finite(power) && power > 1) return(power * x_mean^(power - 1))
            0
          }
          plot_data$weight <- vapply(plot_data$term, term_weight, numeric(1))
          combined <- do.call(rbind, lapply(
            split(plot_data, plot_data$tau),
            function(d) {
              data.frame(
                tau = d$tau[1L],
                estimate = sum(d$estimate * d$weight, na.rm = TRUE),
                std.error = .rif_combined_se(
                  .rif_subfit(fit, taus, d$tau[1L]),
                  d$term, d$weight, d$std.error
                )
              )
            }
          ))
          combined$conf.low <- combined$estimate - 1.96 * combined$std.error
          combined$conf.high <- combined$estimate + 1.96 * combined$std.error
          tri <- panel_ribbon(combined, .wise_blue, 1L, 8)
          if (length(tri) >= 3L) tri[[3L]]$markLine <- markline_of(.e_tau_mark_data(mark_taus))
          bounds <- rif_y_bounds(combined)
          e <- .e_new(height)
          e$x$opts$series <- tri
          e$x$opts$xAxis <- list(tau_x_axis(taus))
          e$x$opts$yAxis <- list(value_y_axis(rif_y_lab, bounds[[1L]], bounds[[2L]]))
          e$x$opts$grid <- list(
            containLabel = TRUE, left = 8, right = 20, top = 14,
            bottom = grid_pad(FALSE, TRUE)
          )
          e$x$opts$grid <- list(
            containLabel = TRUE, left = 8, right = 20, top = 14,
            bottom = grid_pad(FALSE, TRUE)
          )
          e$x$opts$tooltip <- .e_effect_tooltip(
            percent = effect_scale %in% c("pp", "pp100", "pct")
          )
          e <- .e_caption(e, "Ribbon = 95% CI")
          return(wise_echart_theme(e))
        }

        # Multiple terms (main + interactions): combined effect per moderator
        # level (verbatim prep below through the bin factor).
        protected <- gsub("::", "", plot_data$term, fixed = TRUE)
        parts <- strsplit(protected, ":", fixed = TRUE)
        weather_pat <- paste0("\\b", pred_esc, "\\b")
        is_int_row <- lengths(parts) > 1
        main_part <- vapply(parts, function(p) {
          hit <- p[grepl(weather_pat, p)]
          if (length(hit) == 0) p[1] else hit[1]
        }, character(1))

        modx_var <- NULL
        modx_lab <- NULL
        if (length(interaction_terms) > 0) {
          pv_pat <- paste0("\\b", pred_esc, "\\b")
          mt <- interaction_terms[grepl(pv_pat, interaction_terms)]
          if (length(mt) > 0) {
            mp <- strsplit(mt[1], ":", fixed = TRUE)[[1]]
            modx_var <- mp[mp != pred_var][1]
            if (!is.na(modx_var) && nzchar(modx_var)) {
              modx_lab <- label_fun(modx_var)
            }
          }
        }

        modx_vals <- c(0, 1)
        if (!is.null(weather_df) && !is.null(modx_var) &&
          modx_var %in% names(weather_df)) {
          mx <- weather_df[[modx_var]]
          mx <- mx[!is.na(mx)]
          if (length(mx) > 0) {
            if (is.numeric(mx)) {
              u <- sort(unique(mx))
              if (length(u) <= 5) {
                modx_vals <- u
              } else {
                m <- mean(mx)
                s <- stats::sd(mx)
                modx_vals <- c(m - s, m, m + s)
              }
            } else {
              lvls <- if (is.factor(mx)) {
                levels(droplevels(mx))
              } else {
                sort(unique(as.character(mx)))
              }
              num_try <- suppressWarnings(as.numeric(lvls))
              modx_vals <- if (all(!is.na(num_try))) {
                num_try
              } else {
                seq_along(lvls) - 1L
              }
            }
          }
        }

        plot_data$.bin_id <- main_part
        main_rows <- plot_data[!is_int_row, , drop = FALSE]
        int_rows <- plot_data[is_int_row, , drop = FALSE]

        # Effect b + v * g at moderator value v; its SE keeps Cov(b, g) from
        # the tau sub-fit's VCV (independent-terms formula only as fallback).
        effect_rows <- function(v) {
          do.call(rbind, lapply(seq_len(nrow(main_rows)), function(j) {
            mr <- main_rows[j, , drop = FALSE]
            ir <- int_rows[int_rows$.bin_id == mr$.bin_id &
              int_rows$tau == mr$tau, , drop = FALSE]
            ie <- if (nrow(ir) > 0) ir$estimate[1] else 0
            ise <- if (nrow(ir) > 0) ir$std.error[1] else 0
            effect <- mr$estimate + v * ie
            se <- if (nrow(ir) > 0) {
              .rif_combined_se(
                .rif_subfit(fit, taus, mr$tau),
                c(mr$term, ir$term[1]), c(1, v), c(mr$std.error, ise)
              )
            } else {
              mr$std.error
            }
            data.frame(
              tau = mr$tau,
              bin_id = mr$.bin_id,
              bin_label = .t2_bin_label(mr$.bin_id, pred_var),
              modx_val = v,
              estimate = effect,
              std.error = se,
              conf.low = effect - 1.96 * se,
              conf.high = effect + 1.96 * se,
              stringsAsFactors = FALSE
            )
          }))
        }
        combined <- do.call(rbind, lapply(modx_vals, effect_rows))

        modx_lab_print <- modx_lab %||% (modx_var %||% "moderator")
        combined$modx_label <- vapply(
          combined$modx_val,
          function(v) modx_level_label(modx_lab_print, v),
          character(1)
        )
        combined$modx_label <- factor(
          combined$modx_label,
          levels = unique(combined$modx_label[order(combined$modx_val)])
        )

        if (identical(mode, "main")) {
          # The average over moderator levels is itself b + mean(v) * g, so
          # it gets its own delta-method SE rather than averaged bounds.
          combined <- effect_rows(mean(modx_vals))
          combined$modx_label <- "Average across moderator levels"
        }

        bin_ids_raw <- unique(main_rows$.bin_id)
        .bin_lower <- function(b) {
          s <- sub(paste0("^", pred_esc, "[\\[\\(]"), "", b)
          suppressWarnings(as.numeric(sub("^([^,]+),.*", "\\1", s)))
        }
        ord <- order(.bin_lower(bin_ids_raw))
        bin_ids_ordered <- bin_ids_raw[ord]
        bin_levels <- vapply(
          bin_ids_ordered,
          function(b) .t2_bin_label(b, pred_var),
          character(1)
        )
        combined$bin_label <- factor(combined$bin_label, levels = bin_levels)
        n_bins <- length(bin_levels)

        modx_levels <- levels(combined$modx_label) %||%
          unique(as.character(combined$modx_label))
        cols <- stats::setNames(.wise_cat[seq_along(modx_levels)], modx_levels)
        omitted_note <- omitted_bin_note(main_rows$.bin_id)
        rif_cap <- if (identical(mode, "main")) {
          paste(
            "Line and ribbon average the estimated effect across moderator levels;",
            "ribbon = 95% CI (cov(main, interaction) omitted).", omitted_note
          )
        } else {
          paste("Ribbon = 95% CI (cov(main, interaction) omitted).", omitted_note)
        }
        has_legend <- length(modx_levels) > 1L

        e <- .e_new(height)
        if (n_bins > 1) {
          panel_titles <- paste0("Bin: ", bin_levels)
          e <- .e_multi_grids(
            e, n_bins, titles = panel_titles, height = height,
            contain_label = FALSE
          )
          if (has_legend) {
            e$x$opts$title <- lapply(e$x$opts$title, function(title) {
              modifyList(title, list(top = 34))
            })
          }
          panel_trios <- lapply(seq_len(n_bins), function(bi) {
            trios <- lapply(seq_along(modx_levels), function(mi) {
              d <- combined[combined$bin_label == bin_levels[bi] &
                combined$modx_label == modx_levels[mi], , drop = FALSE]
              if (!nrow(d)) {
                return(NULL)
              }
              panel_ribbon(d, unname(cols[mi]), bi, 7, nm = modx_levels[mi])
            })
            trios <- purrr::compact(trios)
            if (length(trios)) trios[[1]][[3]]$markLine <-
              markline_of(.e_tau_mark_data(mark_taus))
            trios
          })
          series <- unlist(unlist(panel_trios, recursive = FALSE),
            recursive = FALSE
          )
           e$x$opts$xAxis <- lapply(seq_len(n_bins), function(i) {
             axis <- tau_x_axis(taus)
             axis$gridIndex <- i - 1L
             axis
           })
            e$x$opts$yAxis <- lapply(seq_len(n_bins), function(i) {
              d_i <- combined[combined$bin_label == bin_levels[[i]], , drop = FALSE]
              b_i <- rif_y_bounds(d_i)
              axis <- if (i == 1L) {
                value_y_axis(
                  rif_y_lab, b_i[[1L]], b_i[[2L]], vertical_name = TRUE
                )
              } else {
                y <- value_y_axis("", b_i[[1L]], b_i[[2L]])
               y
             }
              axis$gridIndex <- i - 1L
              axis
           })
          e$x$opts$grid <- lapply(seq_along(e$x$opts$grid), function(i) {
            modifyList(e$x$opts$grid[[i]], list(
              top = if (has_legend) 58 else e$x$opts$grid[[i]]$top,
              bottom = grid_pad(has_legend, TRUE) + 44
            ))
           })
        } else {
          series <- unlist(lapply(seq_along(modx_levels), function(mi) {
            d <- combined[combined$modx_label == modx_levels[mi], , drop = FALSE]
            if (!nrow(d)) {
              return(NULL)
            }
            panel_ribbon(d, unname(cols[mi]), 1L, 7, nm = modx_levels[mi])
          }), recursive = FALSE)
          if (length(series) >= 3L) {
            series[[3]]$markLine <- markline_of(.e_tau_mark_data(mark_taus))
          }
          e$x$opts$xAxis <- list(tau_x_axis(taus))
           bounds <- rif_y_bounds(combined)
           e$x$opts$yAxis <- list(value_y_axis(rif_y_lab, bounds[[1L]], bounds[[2L]]))
          e$x$opts$grid <- list(
            containLabel = TRUE, left = 8, right = 20, top = 14,
            bottom = grid_pad(has_legend, TRUE)
          )
        }
        if (has_legend) {
          e$x$opts$legend <- wise_elegend_style(
            data = lapply(seq_along(modx_levels), function(i) {
              list(
                name = unname(modx_levels[i]), icon = "roundRect",
                itemStyle = list(color = unname(cols[i]))
              )
            }),
            left = "center", top = 4, orient = "horizontal"
          )
        }
        e$x$opts$series <- series
         e$x$opts$tooltip <- .e_effect_tooltip(
           percent = effect_scale %in% c("pp", "pp100", "pct")
         )
        e <- .e_caption(e, rif_cap)
        return(wise_echart_theme(e))
      }

      pred_lab <- label_fun(pred_var)
      pred_x_lab <- x_label %||% paste0(pred_var, " (", pred_lab, ")")
      y_var_name <- tryCatch(
        as.character(stats::formula(fit)[[2]]),
        error = function(e) "outcome"
      )
      y_lab <- label_fun(y_var_name)
      cap_text <- caption %||% (
        if (isTRUE(is_logistic)) {
          paste(
            "Line = marginal effect (95% CI); curved with polynomial terms,",
            "flat for linear ones. pp at the median-risk household."
          )
        } else {
          paste(
            "Line = marginal effect (95% CI); curved with polynomial terms,",
            "flat for linear ones."
          )
        }
      )

      mf <- mm_of(fit)

      pred_esc <- gsub("([\\[\\]\\(\\)\\^\\$\\.\\*\\+\\?])", "\\\\\\1", pred_var)

      if (!is.null(mf) && pred_var %in% names(mf) && !is_binned) {
        pred_cols <- pred_var
      } else if (!is.null(mf) && is_binned) {
        pred_cols <- grep(paste0("^", pred_esc, "[\\[\\(]"), names(mf), value = TRUE)
      } else {
        pred_cols <- character(0)
      }

      if (!length(pred_cols)) {
        return(echart_blank(paste0("'", pred_var, "' not found in model frame."),
          height = height
        ))
      }

      # ===================================================================== #
      # BINNED PATH                                                           #
      # ===================================================================== #
      if (is_binned) {
        return(tryCatch(
          {
            if (!requireNamespace("fixest", quietly = TRUE)) {
              return(echart_blank("Package 'fixest' is required.", height = height))
            }

            mm <- mm_of(fit)
            if (is.null(mm)) {
              return(echart_blank("Model matrix unavailable.", height = height))
            }
            ct <- .fixest_coeftable(fit)
            ct$term <- rownames(ct)

            bin_cols <- grep(paste0("^", pred_esc, "[\\[\\(]"), names(mm), value = TRUE)
            bin_cols <- bin_cols[!grepl(":", bin_cols)]
            if (length(bin_cols) == 0) {
              return(echart_blank("No binned columns found in model matrix.",
                height = height
              ))
            }

            ct_main <- ct[
              grepl(paste0("^", pred_esc, "[\\[\\(]"), ct$term) & !grepl(":", ct$term),
              c("term", "Estimate", "Std. Error"),
              drop = FALSE
            ]

            .bin_lower <- function(b) {
              s <- sub(paste0("^", pred_esc, "[\\[\\(]"), "", b)
              suppressWarnings(as.numeric(sub("^([^,]+),.*", "\\1", s)))
            }
            bin_cols <- bin_cols[order(.bin_lower(bin_cols))]

            omitted_note <- NULL
            if (!is.null(weather_df)) {
              first_bin <- get_first_bin_label(weather_df, pred_var)
              if (!is.na(first_bin) && nzchar(first_bin)) {
                omitted_note <- paste0("Omitted reference bin: ", .cut_bin_label(first_bin), " at y = 0.")
              }
            }

            bins_df <- data.frame(term = bin_cols, stringsAsFactors = FALSE)
            bins_df <- dplyr::left_join(bins_df, ct_main, by = "term")
            bins_df$Estimate[is.na(bins_df$Estimate)] <- 0
            bins_df$`Std. Error`[is.na(bins_df$`Std. Error`)] <- 0
            bins_df$bin_index <- seq_len(nrow(bins_df))
            bins_df$bin_label <- vapply(
              bins_df$term, .t2_bin_label, character(1),
              pred_var = pred_var
            )

            modx_var <- NULL
            modx_lab <- NULL
            if (length(interaction_terms) > 0) {
              pv_pat <- paste0("\\b", pred_esc, "\\b")
              mt <- interaction_terms[grepl(pv_pat, interaction_terms)]
              if (length(mt) > 0) {
                parts <- strsplit(mt[1], ":")[[1]]
                modx_var <- parts[parts != pred_var][1]
                if (!is.na(modx_var) && nzchar(modx_var)) modx_lab <- label_fun(modx_var)
              }
            }

            if (identical(mode, "main")) {
              modx_var <- NULL
              modx_lab <- NULL
            } else if (identical(mode, "moderated") && is.null(modx_var)) {
              return(echart_blank(paste0("No moderator specified for '", pred_var, "'."),
                height = height
              ))
            }

            cap_binned <- paste(c(omitted_note, caption), collapse = " ")
            cap_binned <- if (is.null(cap_binned) || !nzchar(cap_binned)) {
              NULL
            } else {
              cap_binned
            }

            e <- .e_new(height)

            if (is.null(modx_var)) {
              bins_df$conf.low <- bins_df$Estimate - 1.96 * bins_df$`Std. Error`
              bins_df$conf.high <- bins_df$Estimate + 1.96 * bins_df$`Std. Error`
              bins_df <- .apply_effect_scale(bins_df)

              band <- .e_ribbon_series(
                "Effect", seq_len(nrow(bins_df)) - 1L,
                bins_df$Estimate, bins_df$conf.low, bins_df$conf.high,
                fill = .wise_blue, line = .wise_blue,
                line_width = 1.5, show_points = TRUE, point_size = 8
              )
              band[[3]]$markLine <- list(
                symbol = list("none", "none"), silent = TRUE,
                data = list(list(
                  yAxis = 0,
                  lineStyle = list(color = .wise_zero, type = "dashed", width = 1)
                ))
              )
              band[[3]]$tooltip <- .e_effect_tooltip(
                percent = effect_scale %in% c("pp", "pp100", "pct")
              )
              y_min_val <- min(c(0, bins_df$conf.low), na.rm = TRUE)
              y_max_val <- max(c(0, bins_df$conf.high), na.rm = TRUE)
              y_pad <- max((y_max_val - y_min_val) * 0.12, 0.02)

              e$x$opts$series <- band
              e$x$opts$xAxis <- list(bin_x_axis(bins_df$bin_label, pred_x_lab))
              e$x$opts$yAxis <- list(value_y_axis(
                y_label %||% paste("Effect on", y_lab),
                min_val = round(y_min_val - y_pad, 3),
                max_val = round(y_max_val + y_pad, 3)
              ))
              e$x$opts$grid <- list(
                containLabel = TRUE, left = 8, right = 20, top = 36,
                bottom = grid_pad(FALSE, !is.null(cap_binned))
              )
              e$x$opts$tooltip <- .e_effect_tooltip(
                percent = effect_scale %in% c("pp", "pp100", "pct")
              )
              e <- .e_caption(e, cap_binned)
              return(wise_echart_theme(e))
            }

            # Moderator present: overlay lines (verbatim prep).
            ct_int <- ct[
              grepl(paste0(pred_esc, "[\\[\\(]"), ct$term) &
                grepl(":", ct$term) &
                grepl(modx_var, ct$term, fixed = TRUE),
              c("term", "Estimate", "Std. Error"),
              drop = FALSE
            ]
            int_est <- stats::setNames(ct_int$Estimate, ct_int$term)
            int_se <- stats::setNames(ct_int$`Std. Error`, ct_int$term)

            if (modx_var %in% names(mm)) {
              modx_vals <- sort(unique(mm[[modx_var]]))
              if (length(modx_vals) > 5 && is.numeric(modx_vals)) {
                mu <- mean(mm[[modx_var]], na.rm = TRUE)
                sd <- stats::sd(mm[[modx_var]], na.rm = TRUE)
                modx_vals <- c(mu - sd, mu, mu + sd)
              }
            } else {
              modx_vals <- c(0, 1)
            }

            plot_df <- do.call(
              rbind,
              lapply(seq_len(nrow(bins_df)), function(i) {
                bin_term <- bins_df$term[i]
                b0 <- bins_df$Estimate[i]
                v0 <- bins_df$`Std. Error`[i]^2

                t1 <- paste0(bin_term, ":", modx_var)
                t2 <- paste0(modx_var, ":", bin_term)
                iterm <- if (t1 %in% names(int_est)) t1 else if (t2 %in% names(int_est)) t2 else NA_character_
                has_int <- !is.na(iterm)

                do.call(rbind, lapply(modx_vals, function(mv) {
                  b <- b0 + if (has_int) int_est[[iterm]] * mv else 0
                  # SE of b + mv * g with Cov(b, g) from the fit's VCV, as in
                  # the headline "who is affected" contrasts.
                  s <- if (has_int) {
                    .rif_combined_se(
                      fit, c(bin_term, iterm), c(1, mv),
                      c(sqrt(v0), int_se[[iterm]])
                    )
                  } else {
                    sqrt(v0)
                  }
                  data.frame(
                    bin_index = bins_df$bin_index[i],
                    bin_label = bins_df$bin_label[i],
                    est = b,
                    conf.low = b - 1.96 * s,
                    conf.high = b + 1.96 * s,
                    modx = as.character(mv),
                    stringsAsFactors = FALSE
                  )
                }))
              })
            )

            plot_df <- plot_df[order(plot_df$modx, plot_df$bin_index), , drop = FALSE]
            plot_df <- .apply_effect_scale(plot_df, est_col = "est")
            modx_u <- sort(unique(plot_df$modx))
            modx_labels <- vapply(
              modx_u, function(v) modx_level_label(modx_lab, v),
              character(1)
            )
            plot_df$modx <- factor(plot_df$modx, levels = modx_u, labels = modx_labels)

            # Dodge in data units so lines, points and whiskers share offsets.
            dodge <- 0.16
            offs <- stats::setNames(
              (seq_along(modx_u) - (length(modx_u) + 1) / 2) * dodge,
              modx_labels
            )
            cols <- stats::setNames(
              .wise_cat[seq_along(modx_labels)], modx_labels
            )

            series <- unlist(lapply(seq_along(modx_labels), function(mi) {
              lab <- unname(modx_labels[mi])
              d <- plot_df[plot_df$modx == lab, , drop = FALSE]
              d <- d[order(d$bin_index), , drop = FALSE]
              if (!nrow(d)) {
                return(NULL)
              }
              dx <- unname(offs[[lab]])
              col <- unname(cols[mi])
              tri <- .e_ribbon_series(
                lab, seq_len(nrow(d)) - 1L + dx, d$est,
                d$conf.low, d$conf.high, fill = col, line = col,
                line_width = 1.5, show_points = TRUE, point_size = 7
              )
              if (length(tri) >= 3L && mi == 1L) {
                tri[[3]]$markLine <- list(
                  symbol = list("none", "none"), silent = TRUE,
                  data = list(list(yAxis = 0, lineStyle = list(
                    color = .wise_zero, type = "dashed", width = 1
                  )))
                )
              }
              if (length(tri) >= 3L) {
                tri[[3]]$tooltip <- .e_effect_tooltip(
                  percent = effect_scale %in% c("pp", "pp100", "pct")
                )
              }
              tri
            }), recursive = FALSE)
            series <- Filter(Negate(is.null), series)

            y_min_val <- min(c(0, plot_df$conf.low), na.rm = TRUE)
            y_max_val <- max(c(0, plot_df$conf.high), na.rm = TRUE)
            y_pad <- max((y_max_val - y_min_val) * 0.12, 0.02)

            e$x$opts$series <- series
            e$x$opts$xAxis <- list(bin_x_axis(bins_df$bin_label, pred_x_lab))
            e$x$opts$yAxis <- list(value_y_axis(
              y_label %||% paste("Effect on", y_lab),
              min_val = round(y_min_val - y_pad, 3),
              max_val = round(y_max_val + y_pad, 3)
            ))
            e$x$opts$legend <- wise_elegend_style(
              data = lapply(seq_along(modx_labels), function(i) {
                list(
                  name = unname(modx_labels[i]),
                  icon = "roundRect",
                  itemStyle = list(color = unname(cols[i]))
                )
              }),
              left = "center", top = 4, width = "92%", height = "32%",
              orient = "horizontal"
            )
            e$x$opts$grid <- list(
               containLabel = TRUE, left = 8, right = 20, top = 82,
              bottom = grid_pad(TRUE, !is.null(cap_binned))
            )
            e$x$opts$tooltip <- .e_effect_tooltip(
              percent = effect_scale %in% c("pp", "pp100", "pct")
            )
            e <- .e_caption(e, cap_binned)
            return(wise_echart_theme(e))
          },
          error = function(e) {
            echart_blank(paste0("Binned effect plot error: ", conditionMessage(e)),
              height = height
            )
          }
        ))
      }

      # ===================================================================== #
      # CONTINUOUS PATH: marginal effect of weather vs weather level          #
      # ===================================================================== #
      pred_vals <- mf[[pred_var]]

      if (!any(is.finite(pred_vals))) {
        return(echart_blank(paste0(
          "No finite values for '", pred_var, "' - cannot build effect plot."
        ), height = height))
      }

      if (!requireNamespace("fixest", quietly = TRUE)) {
        return(echart_blank("Package 'fixest' is required.", height = height))
      }

      modx_var <- NULL
      modx_lab <- NULL
      if (length(interaction_terms) > 0) {
        match_term <- grep(paste0("^", pred_var, ":"), interaction_terms, value = TRUE)
        if (length(match_term) > 0) {
          modx_var <- strsplit(match_term[1], ":")[[1]][2]
          modx_lab <- label_fun(modx_var)
        }
      }

      if (identical(mode, "main")) {
        modx_var <- NULL
        modx_lab <- NULL
      } else if (identical(mode, "moderated") &&
        (is.null(modx_var) || !modx_var %in% names(mf))) {
        return(echart_blank(paste0("No moderator specified for '", pred_var, "'."),
          height = height
        ))
      }

      tryCatch(
        {
          mm <- mm_of(fit)
          if (is.null(mm)) {
            return(echart_blank("Model matrix unavailable.", height = height))
          }
          betas <- stats::coef(fit)
          vcov_m <- .fixest_vcov(fit)
          n_grid <- 100L

          # Marginal effect gradient (verbatim from the ggplot builder).
          grad_w <- function(nm, x, mv) {
            if (identical(nm, pred_var)) {
              return(1)
            }
            if (.s1_is_poly_term(nm, pred_var, 2)) {
              return(2 * x)
            }
            if (.s1_is_poly_term(nm, pred_var, 3)) {
              return(3 * x^2)
            }
            if (grepl(":", nm, fixed = TRUE)) {
              parts <- strsplit(nm, ":", fixed = TRUE)[[1]]
              w <- 1
              has_x <- FALSE
              for (pp in parts) {
                if (identical(pp, pred_var)) {
                  has_x <- TRUE
                } else if (.s1_is_poly_term(pp, pred_var, 2)) {
                  w <- w * (2 * x)
                  has_x <- TRUE
                } else if (.s1_is_poly_term(pp, pred_var, 3)) {
                  w <- w * (3 * x^2)
                  has_x <- TRUE
                } else {
                  w <- w * mv
                }
              }
              return(if (has_x) w else 0)
            }
            0
          }

          slope_grid <- function(mv) {
            W <- matrix(0,
              nrow = length(x_seq), ncol = length(betas),
              dimnames = list(NULL, names(betas))
            )
            for (nm in colnames(mm)) {
              if (!nm %in% colnames(W)) next
              W[, nm] <- vapply(x_seq, function(xx) grad_w(nm, xx, mv), numeric(1))
            }
            ok <- !is.na(betas)
            est <- as.numeric(W[, ok, drop = FALSE] %*% betas[ok])
            se <- sqrt(pmax(0, rowSums((W[, ok, drop = FALSE] %*%
              vcov_m[ok, ok, drop = FALSE]) * W[, ok, drop = FALSE])))
            data.frame(x = x_seq, est = est, se = se)
          }

          .slope_scale <- function(d) {
            if (identical(effect_scale, "pct")) {
              f <- function(v) 100 * (exp(v) - 1)
              data.frame(
                x = d$x, fit = f(d$est),
                lo = f(d$est - 1.96 * d$se), hi = f(d$est + 1.96 * d$se)
              )
            } else if (identical(effect_scale, "pp")) {
              if (is.finite(profile_eta)) {
                f <- 100 * stats::plogis(profile_eta) * (1 - stats::plogis(profile_eta))
              } else {
                f <- 1
              }
              data.frame(
                x = d$x, fit = f * d$est,
                lo = f * (d$est - 1.96 * d$se), hi = f * (d$est + 1.96 * d$se)
              )
            } else if (identical(effect_scale, "pp100")) {
              data.frame(
                x = d$x, fit = 100 * d$est,
                lo = 100 * (d$est - 1.96 * d$se), hi = 100 * (d$est + 1.96 * d$se)
              )
            } else {
              data.frame(
                x = d$x, fit = d$est,
                lo = d$est - 1.96 * d$se, hi = d$est + 1.96 * d$se
              )
            }
          }

          mean_x <- mean(mm[[pred_var]], na.rm = TRUE)
          rug_x <- if (isTRUE(show_rug)) {
            rx <- mm[[pred_var]]
            rx <- rx[is.finite(rx)]
            rx
          } else {
            numeric(0)
          }

          x_seq <- seq(min(mm[[pred_var]], na.rm = TRUE),
            max(mm[[pred_var]], na.rm = TRUE),
            length.out = n_grid
          )

          curves <- if (!is.null(modx_var) && modx_var %in% names(mm)) {
            modx_col <- mm[[modx_var]]
            modx_uniq <- sort(unique(modx_col))
            is_cat_modx <- is.factor(modx_col) || is.character(modx_col) ||
              length(modx_uniq) <= 5

            modx_vals <- if (is_cat_modx) {
              modx_uniq
            } else {
              modx_mean <- mean(modx_col, na.rm = TRUE)
              modx_sd <- stats::sd(modx_col, na.rm = TRUE)
              c(modx_mean - modx_sd, modx_mean, modx_mean + modx_sd)
            }

            stats::setNames(
              lapply(modx_vals, function(mv) .slope_scale(slope_grid(mv))),
              vapply(
                modx_vals, function(v) modx_level_label(modx_lab, v),
                character(1)
              )
            )
          } else {
            list("Marginal effect" = .slope_scale(slope_grid(0)))
          }

          y_r <- range(unlist(lapply(curves, function(d) c(d$lo, d$hi))),
            na.rm = TRUE
          )
          pad <- 0.06 * (diff(y_r) %||% 1)
          zero_pad <- max(diff(y_r) * 0.05, 0.02)
          rug_y <- y_r[1] - pad
          y_min <- min(0, rug_y, y_r[1] - pad)
          y_max <- max(y_r[2] + pad, zero_pad)
          zero_is_boundary <- y_r[1] >= 0 || y_r[2] <= 0
          rug_series <- if (length(rug_x)) {
            list(list(
              name = "Observed", type = "scatter",
              data = lapply(rug_x, function(v) list(v, rug_y)),
              symbol = "rect", symbolSize = list(1.5, 9),
              itemStyle = list(color = .wise_slate, opacity = 0.15),
              silent = TRUE, z = 1, tooltip = list(show = FALSE),
              xAxisIndex = 0, yAxisIndex = 0
            ))
          } else {
            list()
          }

          mean_mark <- if (isTRUE(show_mean_ref) && is.finite(mean_x)) {
            list(list(
              xAxis = mean_x,
              lineStyle = list(color = .wise_slate, type = "dashed", width = 1),
              label = list(
                show = TRUE, position = "insideEndTop", formatter = "mean",
                color = .wise_slate, fontSize = 10
              )
            ))
          } else {
            list()
          }

          has_legend <- length(curves) > 1L
          cols <- stats::setNames(
            if (has_legend) .wise_cat[seq_along(curves)] else .wise_blue,
            names(curves)
          )

          ribbon_trios <- lapply(seq_along(curves), function(i) {
            d <- curves[[i]]
            col <- unname(cols[i])
            .e_ribbon_series(names(curves)[i], d$x, d$fit, d$lo, d$hi,
              fill = col, line = col, line_width = 2
            )
          })
          series <- unlist(ribbon_trios, recursive = FALSE)
          if (length(rug_series)) series <- c(series, rug_series)
          last_curve <- max(which(vapply(series, function(s) {
            identical(s$type, "line") && !isTRUE(s$silent)
          }, logical(1))), 0L)
          if (last_curve > 0L) {
            series[[last_curve]]$markLine <- markline_of(mean_mark)
            if (zero_is_boundary) {
              series[[last_curve]]$markLine$data[[1L]]$label <- list(
                show = TRUE, position = "start", formatter = "0",
                color = .wise_slate, fontSize = 11
              )
            }
          }

          e <- .e_new(height)
          e$x$opts$series <- series
          e$x$opts$xAxis <- list(list(
            type = "value", name = pred_x_lab,
            nameLocation = "middle", nameGap = 30,
            nameTextStyle = wise_eyaxis_name(),
           axisLabel = wise_eaxis_label(showMinLabel = FALSE, showMaxLabel = FALSE),
            splitLine = wise_esplit_line()
          ))
          e$x$opts$yAxis <- list(value_y_axis(
            y_label %||% paste("Change in", y_lab, "per +1 unit")
          ))
            e$x$opts$yAxis[[1]]$min <- y_min
            e$x$opts$yAxis[[1]]$max <- y_max
           x_sample <- mm[[pred_var]]
           x_sample <- x_sample[is.finite(x_sample)]
           if (length(x_sample)) {
             e$x$opts$xAxis[[1]]$min <- min(x_sample)
             e$x$opts$xAxis[[1]]$max <- max(x_sample)
           }
          if (has_legend) {
            e$x$opts$legend <- wise_elegend_style(
              data = lapply(seq_along(curves), function(i) {
                list(
                  name = names(curves)[i],
                  icon = "roundRect",
                  itemStyle = list(color = unname(cols[i]))
                )
              }),
              left = "center", top = 0, orient = "horizontal"
            )
          }
          e$x$opts$grid <- list(
            containLabel = TRUE, left = 8, right = 20,
            top = if (has_legend) 54 else 36,
            bottom = grid_pad(FALSE, TRUE)
          )
          e$x$opts$tooltip <- .e_effect_tooltip(
            percent = effect_scale %in% c("pp", "pp100", "pct")
          )
          e <- .e_caption(e, cap_text)
          wise_echart_theme(e)
        },
        error = function(e) {
          echart_blank(paste0("fixest effect plot error: ", conditionMessage(e)),
            height = height
          )
        }
      )
    },
    error = function(e) {
      echart_blank(paste0("Effect plot error: ", conditionMessage(e)),
        height = height
      )
    }
  )
}



# Echarts counterparts of the Model fit figures (guidelines section 7) ---------------

# Shared-bin histogram shares: counts of `x` in `breaks` as % of the pooled
# two-sample total, with bin midpoints as category labels. Mirrors the
# ggplot histogram prep (bins = 30, y = 100 * count / sum(count)).
.e_hist_shares <- function(x, breaks) {
  h <- graphics::hist(x, breaks = breaks, plot = FALSE)
  counts <- h$counts
  total <- sum(counts)
  data.frame(
    mid = (head(breaks, -1) + tail(breaks, -1)) / 2,
    share = if (is.finite(total) && total > 0) 100 * counts / total else rep(0, length(counts)),
    stringsAsFactors = FALSE
  )
}


#' Share of explained variation by term
#'
#' The data behind the importance plot: each term's share (%) of the sum of
#' squared standardized coefficients, `(|beta| x sd(x))^2`. Fixed effects are
#' excluded and collinearity is ignored.
#'
#' @param model A fitted model object (a single `fixest` model, or the median
#'   quantile model for RIF fits).
#' @return A data frame (`term`, `share`), or a message (character) when the
#'   shares cannot be computed.
#' @noRd
importance_shares <- function(model) {
  mm <- resolve_model_matrix(model)
  if (is.null(mm)) {
    return("Model matrix unavailable.")
  }

  coefs <- stats::coef(model)
  keep <- names(coefs) != "(Intercept)" & names(coefs) %in% names(mm)
  beta <- coefs[keep]
  if (!length(beta)) {
    return("No estimable terms.")
  }

  X <- mm[, names(beta), drop = FALSE]
  sd_x <- apply(X, 2, stats::sd, na.rm = TRUE)
  sd_x[is.na(sd_x)] <- 0

  imp <- abs(as.numeric(beta)) * as.numeric(sd_x)
  tot <- sum(imp^2)
  if (!is.finite(tot) || tot <= 0) {
    return("No variation to decompose.")
  }

  data.frame(
    term = names(beta),
    share = 100 * imp^2 / tot,
    stringsAsFactors = FALSE
  )
}

#' Echarts importance plot (squared standardized coefficient shares)
#'
#' Horizontal bars of each term's share of the sum of squared standardized
#' coefficients, largest share at the top. The chart subtitle is
#' carried by the section heading, so it is not repeated in the widget.
#'
#' @param model A fitted model object (a single `fixest` model, or the median
#'   quantile model for RIF fits).
#' @param label_fun Function mapping variable names to display labels.
#' @param height Widget height; a CSS length or a number of pixels.
#'
#' @return An `echarts4r` widget.
#'
#' @export
echart_importance <- function(model, label_fun = identity, height = "400px") {
  df <- importance_shares(model)
  if (is.character(df)) {
    return(echart_blank(df, height = height))
  }
  coef_map <- make_coef_map(df$term, label_fun)
  df$label <- unname(names(coef_map)[match(df$term, unname(coef_map))])
  df$label[is.na(df$label) | !nzchar(df$label)] <-
    df$term[is.na(df$label) | !nzchar(df$label)]
  df <- df[order(-df$share), , drop = FALSE]
  df <- utils::head(df, 15)

  # Category axes draw the first item at the bottom: feed ascending order so
  # the largest share lands on top, like the ggplot reorder().
  df <- df[order(df$share), , drop = FALSE]

  e <- .e_new(height)
  e$x$opts$series <- list(list(
    name = "Share", type = "bar",
    data = lapply(seq_len(nrow(df)), function(i) {
      list(
        value = df$share[i],
        label = list(
          show = TRUE, position = "right",
          formatter = sprintf("%.0f%%", df$share[i]),
          color = .wise_charcoal, fontSize = 11
        )
      )
    }),
    itemStyle = list(color = .wise_blue),
    barMaxWidth = 16
  ))
  e$x$opts$xAxis <- list(list(
    type = "value", name = "Share of explained variation (%)",
    nameLocation = "middle", nameGap = 30,
    nameTextStyle = wise_eaxis_name(align = "center"),
    axisLabel = wise_eaxis_label(
      formatter = htmlwidgets::JS("function(v){ return v + '%'; }")
    ),
    splitLine = wise_esplit_line()
  ))
  e$x$opts$yAxis <- list(list(
    type = "category", data = df$label,
    axisLabel = wise_eaxis_label(fontSize = 11),
    axisLine = list(lineStyle = list(color = .wise_grid)),
    splitLine = list(show = FALSE)
  ))
  e$x$opts$grid <- list(
    containLabel = TRUE, left = 8, right = 56, top = 20, bottom = 44,
    width = "auto", height = "auto"
  )
  e$x$opts$tooltip <- list(trigger = "item")
  wise_echart_theme(e)
}


#' Echarts residual diagnostic panels
#'
#' Linear / LPM / RIF models: residuals-vs-fitted (with a loess smooth)
#' beside a normal Q-Q plot in one widget with two echarts grids; the QQ
#' quantiles are precomputed in R with the same methods as `stat_qq`
#' (`ppoints` / `qnorm`) and the reference line through the quartiles.
#' Binary outcomes: binned residual means by decile of predicted risk with a
#' +/- 2-SE band, as in the ggplot builder.
#'
#' @param model A fitted model object (single `fixest` model, or the median
#'   quantile model for RIF fits).
#' @param is_logistic Logical. `TRUE` draws binned residual means for binary
#'   outcomes instead of the residual and Q-Q panels.
#' @param height Widget height; a CSS length or a number of pixels.
#'
#' @return An `echarts4r` widget.
#'
#' @export
echart_residual_panels <- function(model, is_logistic = FALSE, height = "400px") {
  if (is_logistic) {
    # Binned residual means by decile of predicted risk (Gelman & Hill);
    # data preparation copied verbatim from plot_residual_panels().
    return(tryCatch(
      {
        p <- as.numeric(stats::fitted(model))
        res <- tryCatch(as.numeric(stats::residuals(model, type = "response")),
          error = function(e) as.numeric(stats::residuals(model))
        )
        n <- min(length(p), length(res))
        p <- p[seq_len(n)]
        res <- res[seq_len(n)]

        k <- max(3L, min(10L, floor(n / 20)))
        ord <- order(p)
        brks <- unique(floor(seq(0, n, length.out = k + 1)))
        if (length(brks) < 3) {
          return(echart_blank("Too few observations for binned residuals.",
            height = height
          ))
        }
        grp <- cut(seq_len(n), breaks = brks, include.lowest = TRUE)

        bdf <- data.frame(p = p[ord], res = res[ord], grp = grp)
        agg <- stats::aggregate(cbind(pred = p, mean_res = res) ~ grp,
          data = bdf, FUN = mean
        )
        cnt <- as.data.frame(table(bdf$grp))
        agg$n <- cnt$Freq[match(as.character(agg$grp), as.character(cnt$Var1))]
        agg$se <- vapply(split(bdf$res, bdf$grp), function(r) {
          if (length(r) > 1) stats::sd(r) / sqrt(length(r)) else NA_real_
        }, numeric(1))

        e <- .e_new(height)
        tri <- .e_ribbon_series(
          "Binned residuals", agg$pred, agg$mean_res,
          agg$mean_res - 2 * agg$se, agg$mean_res + 2 * agg$se,
          fill = .wise_blue, line = .wise_blue, line_width = 1.5,
          show_points = TRUE, point_size = 7
        )
        tri[[3]]$markLine <- .e_zero_line()
        tri[[3]]$tooltip <- .e_effect_tooltip()
        e$x$opts$series <- tri
        e$x$opts$xAxis <- list(list(
          type = "value", name = "Predicted risk (bin mean)",
          nameLocation = "middle", nameGap = 30,
          nameTextStyle = wise_eaxis_name(align = "center"),
          axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
        ))
        e$x$opts$yAxis <- list(list(
          type = "value", scale = TRUE, name = "Mean residual in bin",
          nameLocation = "end",
          nameTextStyle = wise_eyaxis_name(),
          axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
        ))
        e$x$opts$grid <- list(
          containLabel = TRUE, left = 8, right = 20, top = 36, bottom = 44
        )
        e$x$opts$tooltip <- .e_effect_tooltip()
        wise_echart_theme(e)
      },
      error = function(e) {
        echart_blank(paste0(
          "Diagnostic plot error: ", conditionMessage(e)
        ), height = height)
      }
    ))
  }

  # Linear / LPM / RIF: residuals vs fitted next to a normal QQ plot.
  tryCatch(
    {
      res <- as.numeric(stats::residuals(model))
      fitted <- as.numeric(stats::fitted(model))
      n <- min(length(fitted), length(res))
      df <- data.frame(fitted = fitted[seq_len(n)], residuals = res[seq_len(n)])

      e <- .e_new(height)
      e <- .e_multi_grids(e, 2, titles = c("Residuals vs fitted", "Normal Q-Q"))

      # Panel 1: scatter + loess smooth (ggplot geom_smooth(method = "loess")
      # defaults: span 0.75, degree 2, formula y ~ x).
      # CR-PERF-08: points as an [x, y] matrix (a JSON array of pairs) instead
      # of one R list per point, which cost seconds of serialisation at N = 13k.
      pts1 <- .e_xy_matrix(df$fitted, df$residuals)
      smooth <- tryCatch({
        keep <- is.finite(df$fitted) & is.finite(df$residuals)
        xs <- sort(unique(df$fitted[keep]))
        if (length(xs) >= 5) {
          lo <- stats::loess(residuals ~ fitted, data = df[keep, ],
            span = 0.75, degree = 2
          )
          # predict() returns a named vector; unname it so each point
          # serialises as [x, y] rather than [x, {"<name>": y}].
          # The smooth is drawn on at most 300 evenly spaced fitted values;
          # a line through 13k points is visually identical but much larger.
          if (length(xs) > 300L) {
            xs <- xs[unique(round(seq(1, length(xs), length.out = 300L)))]
          }
          pr <- unname(stats::predict(lo, newdata = data.frame(fitted = xs)))
          ok <- is.finite(pr)
          .e_xy_matrix(xs[ok], pr[ok])
        } else {
          NULL
        }
      }, error = function(e) NULL)
      series1 <- list(list(
        name = "Residuals", type = "scatter", data = pts1,
        symbolSize = 4, z = 1,
        itemStyle = list(color = .wise_charcoal, opacity = 0.15),
        markLine = .e_zero_line()
      ))
      if (length(smooth) >= 2) {
        series1 <- c(series1, list(list(
          name = "Trend", type = "line", data = smooth,
          symbol = "none", z = 2,
          lineStyle = list(color = .wise_blue, width = 1.5),
          itemStyle = list(color = .wise_blue)
        )))
      }

      # Panel 2: normal QQ precomputed with stat_qq's methods (ppoints/qnorm)
      # and the stat_qq_line quartile reference.
      qq <- stats::qqnorm(df$residuals, plot.it = FALSE)
      pts2 <- .e_xy_matrix(qq$x, qq$y)
      qs <- stats::quantile(df$residuals, c(0.25, 0.75), names = FALSE, na.rm = TRUE)
      xs <- stats::qnorm(c(0.25, 0.75))
      series2 <- list(list(
        name = "Sample quantiles", type = "scatter", data = pts2,
        symbolSize = 4, z = 1,
        itemStyle = list(color = .wise_charcoal, opacity = 0.3),
        markLine = list(
          symbol = "none", silent = TRUE, animation = FALSE,
          label = list(show = FALSE),
          lineStyle = list(color = .wise_blue, width = 1),
          data = list(list(
            list(coord = list(xs[1], qs[1])),
            list(coord = list(xs[2], qs[2]))
          ))
        )
      ))

      e$x$opts$series <- c(series1, series2)
      for (i in seq_along(series1)) {
        e$x$opts$series[[i]]$xAxisIndex <- 0L
        e$x$opts$series[[i]]$yAxisIndex <- 0L
      }
      s2_start <- length(series1) + 1L
      for (i in s2_start:length(e$x$opts$series)) {
        e$x$opts$series[[i]]$xAxisIndex <- 1L
        e$x$opts$series[[i]]$yAxisIndex <- 1L
      }
      e$x$opts$xAxis <- list(
        list(
          gridIndex = 0L,
          type = "value", scale = TRUE, name = "Fitted values",
          nameLocation = "middle", nameGap = 28,
          nameTextStyle = wise_eaxis_name(align = "center"),
          axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
        ),
        list(
          gridIndex = 1L,
          type = "value", scale = TRUE, name = "Theoretical quantiles",
          nameLocation = "middle", nameGap = 28,
          nameTextStyle = wise_eaxis_name(align = "center"),
          axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
        )
      )
      e$x$opts$grid <- lapply(seq_len(2L), function(i) {
        list(
          left = if (i == 1L) "8%" else "54%",
          right = if (i == 1L) "54%" else "8%",
          top = 44, bottom = 58,
          width = "38%",
          height = "auto", containLabel = TRUE
        )
      })
      e$x$opts$title <- list(
        list(text = "Residuals vs fitted", left = "8%", top = 4,
          textStyle = list(color = .wise_charcoal, fontSize = 13, fontWeight = "normal")),
        list(text = "Normal Q-Q", left = "54%", top = 8,
          textStyle = list(color = .wise_charcoal, fontSize = 13, fontWeight = "normal"))
      )
      e$x$opts$yAxis <- list(
        list(
          gridIndex = 0L,
          type = "value", scale = TRUE, name = "Residuals",
          nameLocation = "end",
          nameTextStyle = wise_eyaxis_name(),
          axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
        ),
        list(
          gridIndex = 1L,
          type = "value", scale = TRUE, name = "Sample quantiles",
          nameLocation = "end",
          nameTextStyle = wise_eyaxis_name(),
          axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
        )
      )
      e$x$opts$tooltip <- list(show = FALSE)
      wise_echart_theme(e)
    },
    error = function(e) {
      echart_blank(paste0(
        "Diagnostic plot error: ", conditionMessage(e)
      ), height = height)
    }
  )
}


#' Echarts predicted vs actual distribution
#'
#' Linear models: dodged histogram of actual vs predicted values over 30
#' shared bins, y = share of households. Logistic models: calibration curve
#' (observed vs predicted rate by decile of predicted risk) with the diagonal
#' reference and +/- 2-SE binomial band.
#'
#' @param model A fitted model object (single `fixest` model, or the median
#'   quantile model for RIF fits).
#' @param is_logistic Logical. `TRUE` draws the calibration curve for binary
#'   outcomes, `FALSE` the actual-vs-predicted histogram.
#' @param outcome_label Display label of the outcome, used in axis text.
#' @param height Widget height; a CSS length or a number of pixels.
#'
#' @return An `echarts4r` widget.
#'
#' @export
echart_pred_vs_actual <- function(model, is_logistic, outcome_label = "outcome",
                                  height = "400px") {
  # Actual recovery copied verbatim from plot_pred_vs_actual().
  actual <- tryCatch(
    stats::model.frame(model)[[1]],
    error = function(e) {
      f <- tryCatch(stats::fitted(model), error = function(e) NULL)
      r <- tryCatch(stats::residuals(model), error = function(e) NULL)
      if (!is.null(f) && !is.null(r)) f + r else NULL
    }
  )

  if (is.null(actual)) {
    return(echart_blank("Could not recover outcome values from model.",
      height = height
    ))
  }

  if (!is_logistic) {
    predicted <- tryCatch(stats::fitted(model), error = function(e) stats::predict(model))
    n <- min(length(actual), length(predicted))
    actual <- actual[seq_len(n)]
    predicted <- predicted[seq_len(n)]

    all_vals <- c(actual, predicted)
    all_vals <- all_vals[is.finite(all_vals)]
    if (length(all_vals) < 2L || diff(range(all_vals)) <= 0) {
      return(echart_blank("Outcome distribution unavailable.", height = height))
    }
    brks <- seq(min(all_vals, na.rm = TRUE), max(all_vals, na.rm = TRUE),
      length.out = 31
    )
    ha <- .e_hist_shares(actual, brks)
    hp <- .e_hist_shares(predicted, brks)
    labels <- formatC(ha$mid, format = "f", digits = 2)
    observed_max <- max(c(ha$share, hp$share), na.rm = TRUE)
    y_max <- max(1, ceiling(observed_max * 1.12))
    y_interval <- y_max / 5

    e <- .e_new(height)
    bar <- function(d, nm, col) {
      list(
        name = nm, type = "bar",
        data = as.list(round(d$share, 4)),
        itemStyle = list(color = col, opacity = 0.7),
        barMaxWidth = 12
      )
    }
    e$x$opts$series <- list(
      bar(ha, "Actual", .wise_slate),
      bar(hp, "Predicted", .wise_blue)
    )
    e$x$opts$xAxis <- list(list(
      type = "category", data = as.list(labels),
      name = stringr::str_wrap(outcome_label, 40),
      nameLocation = "middle", nameGap = 30,
      nameTextStyle = wise_eaxis_name(align = "center"),
      axisLabel = wise_eaxis_label(fontSize = 10),
      axisTick = list(show = FALSE),
      splitLine = wise_esplit_line()
    ))
    e$x$opts$yAxis <- list(list(
      type = "value", min = 0, max = y_max, interval = y_interval,
      name = "Share of households (%)",
      nameLocation = "end",
      nameTextStyle = wise_eyaxis_name(),
      axisLabel = wise_eaxis_label(
        formatter = htmlwidgets::JS("function(v){ return v + '%'; }")
      ),
      splitLine = wise_esplit_line()
    ))
    e$x$opts$legend <- wise_elegend_style(
      data = list("Actual", "Predicted"),
      right = 36, top = 0, orient = "horizontal"
    )
    e$x$opts$grid <- list(
      containLabel = TRUE, left = 8, right = 20, top = 36, bottom = 46,
      width = "auto", height = "auto"
    )
    e$x$opts$tooltip <- list(
      trigger = "axis", axisPointer = list(type = "shadow"),
      valueFormatter = htmlwidgets::JS("function(v){ return Number(v).toFixed(1) + '%'; }")
    )
    return(wise_echart_theme(e))
  }

  # Logistic: calibration curve; data preparation copied from
  # plot_calibration().
  tryCatch(
    {
      predicted <- tryCatch(
        stats::fitted(model),
        error = function(e) {
          tryCatch(stats::predict(model, type = "response"),
            error = function(e2) NULL
          )
        }
      )
      n_bins <- 10L
      n <- min(length(actual), length(predicted))
      k <- max(3L, min(as.integer(n_bins), floor(n / 20)))
      ord <- order(as.numeric(predicted[seq_len(n)]))
      brks <- unique(floor(seq(0, n, length.out = k + 1)))
      if (length(brks) < 3) {
        return(echart_blank("Too few observations for calibration bins.",
          height = height
        ))
      }
      grp <- cut(seq_len(n), breaks = brks, include.lowest = TRUE)

      bdf <- data.frame(
        pred = as.numeric(predicted[seq_len(n)])[ord],
        obs = as.numeric(actual)[ord],
        grp = grp,
        stringsAsFactors = FALSE
      )
      cal <- stats::aggregate(cbind(pred, obs) ~ grp, data = bdf, FUN = mean)
      names(cal) <- c("grp", "pred", "obs")
      cnt <- as.data.frame(table(bdf$grp))
      cal$n <- cnt$Freq[match(as.character(cal$grp), as.character(cnt$Var1))]
      cal$se <- sqrt(pmax(cal$obs * (1 - cal$obs), 0) / pmax(cal$n, 1))

      e <- .e_new(height)
      tri <- .e_ribbon_series(
        "Calibration", cal$pred, cal$obs,
        pmax(0, cal$obs - 2 * cal$se), pmin(1, cal$obs + 2 * cal$se),
        fill = .wise_blue, line = .wise_blue, line_width = 1.5,
        show_points = TRUE, point_size = 7
      )
      tri[[3]]$markLine <- list(
        symbol = "none", silent = TRUE, animation = FALSE,
        label = list(show = FALSE),
        lineStyle = list(color = .wise_zero, type = "dashed", width = 1),
        data = list(list(
          list(coord = list(0, 0)), list(coord = list(1, 1))
        ))
      )
      e$x$opts$series <- tri
      e$x$opts$xAxis <- list(list(
        type = "value", min = 0, max = 1,
        name = "Predicted risk (bin mean)",
        nameLocation = "middle", nameGap = 30,
            nameTextStyle = wise_eyaxis_name(),
        axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
      ))
      e$x$opts$yAxis <- list(list(
        type = "value", min = 0, max = 1,
        name = "Observed rate in bin",
        nameLocation = "end", nameTextStyle = wise_eyaxis_name(),
        axisLabel = wise_eaxis_label(), splitLine = wise_esplit_line()
      ))
      e$x$opts$grid <- list(
        containLabel = TRUE, left = 8, right = 20, top = 34, bottom = 46,
        width = "auto", height = "auto"
      )
      e$x$opts$tooltip <- .e_effect_tooltip(percent = TRUE)
      wise_echart_theme(e)
    },
    error = function(e) {
      echart_blank(paste0(
        "Diagnostic plot error: ", conditionMessage(e)
      ), height = height)
    }
  )
}


#' Echarts welfare histogram with RIF quantile markers
#'
#' The RIF branch of the "Predicted vs actual" figure: a histogram of the
#' original welfare outcome (30 bins, share of households) with dashed
#' markers at the estimated quantiles, matching the ggplot version drawn
#' inline in mod_1_08.
#'
#' @param y       Numeric vector of outcome values.
#' @param taus    Numeric vector of quantile probabilities to mark.
#' @param x_label X-axis label for the outcome variable.
#' @param height  Widget height; a CSS length or a number of pixels.
#'
#' @return An `echarts4r` widget.
#'
#' @export
echart_welfare_quantile_hist <- function(y, taus, x_label, height = "400px") {
  y <- y[is.finite(y)]
  if (length(y) < 2) {
    return(echart_blank("Outcome distribution unavailable.", height = height))
  }
  brks <- seq(min(y), max(y), length.out = 31)
  if (diff(range(brks)) == 0) {
    return(echart_blank("Outcome distribution unavailable.", height = height))
  }
  h <- .e_hist_shares(y, brks)
  labels <- formatC(h$mid, format = "f", digits = 2)
  y_max <- max(1, ceiling(max(h$share, na.rm = TRUE) * 1.12))

  q_vals <- stats::quantile(y, probs = taus, names = FALSE)
  tau_marks <- lapply(seq_along(taus), function(i) {
    idx <- which(h$mid >= q_vals[i])
    if (!length(idx)) idx <- length(h$mid)
    list(
      xAxis = idx[1],
      lineStyle = list(color = .wise_marker_alt, type = "dashed", width = 1),
      label = list(
        show = TRUE, position = "insideEndTop",
        formatter = paste0("\u03c4=", taus[i]),
        color = .wise_marker_alt, fontSize = 10
      )
    )
  })

  e <- .e_new(height)
  e$x$opts$series <- list(list(
    name = "Share", type = "bar",
    data = as.list(round(h$share, 4)),
    itemStyle = list(color = .wise_blue, opacity = 0.7),
    barMaxWidth = 12,
    markLine = list(
      symbol = "none", silent = TRUE, animation = FALSE,
      lineStyle = list(color = .wise_marker_alt, type = "dashed", width = 0.5),
      data = tau_marks
    )
  ))
  e$x$opts$xAxis <- list(list(
    type = "category", data = as.list(labels),
    name = stringr::str_wrap(x_label, 40),
    nameLocation = "middle", nameGap = 30,
    nameTextStyle = wise_eaxis_name(),
    axisLabel = wise_eaxis_label(fontSize = 10),
    axisTick = list(show = FALSE),
    splitLine = wise_esplit_line()
  ))
    e$x$opts$yAxis <- list(list(
      type = "value", min = 0, max = y_max, interval = y_max / 5,
      name = "Share of households (%)",
      nameLocation = "end",
      nameTextStyle = wise_eyaxis_name(),
    axisLabel = wise_eaxis_label(
      formatter = htmlwidgets::JS("function(v){ return v + '%'; }")
    ),
    splitLine = wise_esplit_line()
  ))
  e$x$opts$grid <- list(
    containLabel = TRUE, left = 8, right = 20, top = 14, bottom = 14
  )
    e$x$opts$tooltip <- list(
      trigger = "axis", axisPointer = list(type = "shadow"),
      valueFormatter = htmlwidgets::JS("function(v){ return Number(v).toLocaleString('en-US',{minimumFractionDigits:1,maximumFractionDigits:1}) + '%'; }")
    )
  wise_echart_theme(e)
}

# Effect-plot y-axis label: continuous shapes draw predicted levels or slopes,
# binned shapes draw bin-vs-reference contrasts - these need different labels.
.effect_y_lab <- function(binned, un, outcome_snap, is_logit, is_lpm, is_log_out,
                          profile_eta0) {
  if (is.na(un) || !nzchar(un)) un <- "unit"
  if (identical(as.character(outcome_snap$name[1]), "poor")) {
    line <- suppressWarnings(as.numeric(outcome_snap$povline[1]))
    if (is.finite(line)) {
      if (binned) {
        return("Effect size (percentage points vs reference bin)")
      }
      return(paste0("Effect size (percentage points per +1 ", un, ")"))
    }
  }
  if (binned) {
    if (is_logit) {
      if (is.finite(profile_eta0)) {
        paste0(
          "Effect size (percentage points vs reference bin)"
        )
      } else {
        "Effect size (log-odds vs reference bin)"
      }
    } else if (is_lpm) {
      "Effect size (probability vs reference bin)"
    } else if (is_log_out) {
      "Effect size (log points vs reference bin)"
    } else {
      "Effect size (outcome units vs reference bin)"
    }
  } else {
    # Continuous shapes draw the marginal effect (slope vs weather).
    if (is_logit) {
      if (is.finite(profile_eta0)) {
        paste0("Effect size (percentage points per +1 ", un, ")")
      } else {
        paste0("Effect size (log-odds per +1 ", un, ")")
      }
    } else if (is_lpm) {
      paste0("Effect size (probability per +1 ", un, ")")
    } else if (is_log_out) {
      paste0("Effect size (% change per +1 ", un, ")")
    } else {
      paste0("Effect size (outcome units per +1 ", un, ")")
    }
  }
}
