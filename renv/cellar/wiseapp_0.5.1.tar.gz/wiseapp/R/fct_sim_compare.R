# Simulation comparison and visualisation ----
# fct_sim_compare.R
#
# Pure comparison and visualisation functions for Module 2.
# Called by mod_2_02_results.R
#
# Functions:
#   label_agg_method(key)     -- human-readable label for aggregation method
#   label_deviation(key)      -- human-readable label for deviation choice
#   .resolve_year_styles()    -- internal; dynamic linetype map by sorted year
#   build_threshold_table_df()  -- return-period threshold data frame for DT
#
# NOTE: plot_bar_climate() had no active call sites and was removed.

# Label helpers ----

#' Human-Readable Label for Aggregation Method
#'
#' Converts the internal `agg_method` key used in `selectInput` to a short
#' display string for table headers and the results banner.
#'
#' @param key Character. One of `"mean"`, `"median"`, `"headcount_ratio"`,
#'   `"gap"`, `"fgt2"`, `"gini"`.
#' @return A character string.
#' @export
label_agg_method <- function(key) {
  switch(key,
    mean            = "Mean",
    median          = "Median",
    total           = "Total",
    headcount_ratio = "Poverty rate",
    gap             = "Poverty gap",
    fgt2            = "Poverty severity",
    gini            = "Gini coefficient",
    prosperity_gap  = "Prosperity gap",
    avg_poverty     = "Average poverty",
    key # fallback: return key unchanged
  )
}

#' Human-Readable Label for Deviation Choice
#'
#' Converts the internal `deviation` key to a short display string.
#'
#' @param key Character. One of `"none"`, `"mean"`, `"median"`.
#' @return A character string.
#' @export
label_deviation <- function(key) {
  switch(key,
    none   = "raw value",
    mean   = "deviation from mean year",
    median = "deviation from median year",
    key
  )
}

# Band quantile resolver ----

#' Resolve Uncertainty Band Key to Quantile Pair
#'
#' Converts the UI uncertainty band selector key to a named numeric vector
#' used by the pointrange renderer and summarise_vals().
#'
#' Single authoritative definition (DUP-01): the former duplicate in
#' fct_aggregation.R - whose "minmax" winsorised to 0.001/0.999 instead of the
#' full 0/1 range used here - has been deleted. This variant matches the
#' behaviour every caller has seen at runtime (fct_sim_compare.R is sourced
#' after fct_aggregation.R and previously overwrote it).
#'
#' @param band_key Character. One of "p25_p75", "p20_p80", "p10_p90",
#'   "p05_p95", "p025_p975", "p005_p995", "minmax". Unknown keys fall back to
#'   the p10_p90 pair.
#' @return Named numeric vector c(lo = ..., hi = ...).
#' @export
resolve_band_q <- function(band_key) {
  switch(band_key,
    p25_p75 = c(lo = 0.25, hi = 0.75),
    p20_p80 = c(lo = 0.20, hi = 0.80),
    p10_p90 = c(lo = 0.10, hi = 0.90),
    p05_p95 = c(lo = 0.05, hi = 0.95),
    p025_p975 = c(lo = 0.025, hi = 0.975),
    p005_p995 = c(lo = 0.005, hi = 0.995),
    minmax = c(lo = 0.00, hi = 1.00),
    c(lo = 0.10, hi = 0.90) # default fallback
  )
}

# Internal helpers: parse scenario key components ----
# .normalise_ssp() and .parse_year() live in fct_simulations.R (single robust
# implementation - do not re-define them here).

# Internal: dynamic year linetype helper ----
.resolve_year_styles <- function(year_labels) {
  linetypes <- c("solid", "dashed", "dotted", "longdash", "twodash")
  years <- sort(unique(year_labels))
  n <- length(years)
  lty <- linetypes[seq_len(min(n, length(linetypes)))]
  list(
    linetype_map = setNames(lty, years),
    alpha_map    = setNames(rep(1.0, n), years)
  )
}

# Grouped point-range chart ----

# Shared preparation behind the pointrange renderer and its echarts
# counterpart echart_pointrange_climate(): scenario keys, the SSP x period
# colour palette, and the category order with spacer gutters. Pure data prep
# - no rendering - so both surfaces stay in lockstep (guidelines sec. 7).
# @noRd
.pointrange_prep <- function(bands_tbl, group_order = "scenario_x_year") {
  df <- bands_tbl
  has_source <- "source" %in% names(df)
  if (has_source) {
    df$source <- factor(df$source, levels = c("Baseline", "Policy"))
    # Historical from the policy source is identical to baseline historical -
    # drop it so the chart shows one historical dot (under Baseline).
    df <- df[!(df$is_historical & df$source == "Policy"), , drop = FALSE]
  }
  df$ssp_key <- ifelse(df$is_historical, "Historical",
    vapply(df$scenario, .normalise_ssp, character(1L))
  )
  df$yr_lbl <- ifelse(df$is_historical, "Historical",
    vapply(df$scenario, .parse_year, character(1L))
  )
  df$ssp_short <- ifelse(df$is_historical, "Historical",
    SSP_SHORT_LABELS[df$ssp_key] %||% df$ssp_key
  )
  df$pt_key <- ifelse(df$is_historical, "Historical",
    paste0(df$ssp_short, "\n", df$yr_lbl)
  )
  df$colour_key <- ifelse(df$is_historical, "Historical",
    paste(df$ssp_key, df$yr_lbl, sep = "__")
  )

  fut_df <- df[!df$is_historical, , drop = FALSE]

  # colour palette: Historical = grey; one colour per SSP x year ----
  colour_palette <- c("Historical" = "#808080")
  if (nrow(fut_df) > 0L) {
    yrs_present <- sort(unique(fut_df$yr_lbl))
    n_yrs <- length(yrs_present)
    yr_lighten <- if (n_yrs > 1L) seq(0.30, 0.0, length.out = n_yrs) else 0.0
    for (ssp in intersect(names(.ssp_colours), unique(fut_df$ssp_key))) {
      base_col <- .ssp_colours[ssp]
      for (i in seq_along(yrs_present)) {
        ck <- paste(ssp, yrs_present[i], sep = "__")
        colour_palette[ck] <- colorspace::lighten(base_col, yr_lighten[i])
      }
    }
  }

  # x-axis factor levels with spacers ----
  ordered_levels <- "Historical"
  spacer_ids <- character(0)
  if (nrow(fut_df) > 0L) {
    ssps_present <- intersect(c("SSP2", "SSP3", "SSP5"), unique(fut_df$ssp_short))
    spacer_n <- 0L
    if (isTRUE(group_order == "year_x_scenario")) {
      yrs_present <- sort(unique(fut_df$yr_lbl))
      for (yr_i in yrs_present) {
        spacer_n <- spacer_n + 1L
        sid <- strrep(" ", spacer_n)
        spacer_ids <- c(spacer_ids, sid)
        ordered_levels <- c(ordered_levels, sid)
        for (ssp in ssps_present) {
          ordered_levels <- c(ordered_levels, paste0(ssp, "\n", yr_i))
        }
      }
    } else {
      for (ssp in ssps_present) {
        spacer_n <- spacer_n + 1L
        sid <- strrep(" ", spacer_n)
        spacer_ids <- c(spacer_ids, sid)
        ordered_levels <- c(ordered_levels, sid)
        ssp_yrs <- sort(unique(fut_df$yr_lbl[fut_df$ssp_short == ssp]))
        for (yr_i in ssp_yrs) {
          ordered_levels <- c(ordered_levels, paste0(ssp, "\n", yr_i))
        }
      }
    }
  }
  x_label_map <- setNames(
    vapply(ordered_levels, function(lv) {
      if (lv %in% spacer_ids) "" else lv
    }, character(1L)),
    ordered_levels
  )
  data_levels <- setdiff(ordered_levels, spacer_ids)
  df$pt_key <- factor(df$pt_key, levels = ordered_levels)
  df <- df[df$pt_key %in% data_levels, , drop = FALSE]

  list(
    df = df,
    palette = colour_palette,
    ordered_levels = ordered_levels,
    spacer_ids = spacer_ids,
    x_label_map = x_label_map,
    data_levels = data_levels,
    has_source = has_source
  )
}


# Decision-first annual and paired summaries ----

# Build paired model-year effects from the two arms' canonical aggregate
# tables. F_agg is used whenever available so the coefficient interval retains
# baseline-policy covariance instead of treating the arms as independent.
paired_model_year_effects <- function(baseline_tbl, policy_tbl) {
  if (is.null(baseline_tbl) || is.null(policy_tbl) ||
    !nrow(baseline_tbl) || !nrow(policy_tbl)) {
    return(tibble::tibble())
  }

  rows <- lapply(intersect(baseline_tbl$sim_year, policy_tbl$sim_year), function(yr) {
    b <- baseline_tbl[baseline_tbl$sim_year == yr, , drop = FALSE][1L, ]
    p <- policy_tbl[policy_tbl$sim_year == yr, , drop = FALSE][1L, ]
    b_ids <- as.character(b$model_id[[1L]])
    p_ids <- as.character(p$model_id[[1L]])
    ids <- intersect(b_ids, p_ids)
    if (!length(ids)) {
      return(NULL)
    }
    b_vals <- stats::setNames(as.numeric(b$value_all[[1L]]), b_ids)
    p_vals <- stats::setNames(as.numeric(p$value_all[[1L]]), p_ids)
    b_sd <- stats::setNames(as.numeric(b$value_all_sd[[1L]]), b_ids)
    p_sd <- stats::setNames(as.numeric(p$value_all_sd[[1L]]), p_ids)
    b_f <- b$F_agg_all[[1L]]
    p_f <- p$F_agg_all[[1L]]
    out <- lapply(ids, function(id) {
      i_b <- match(id, b_ids)
      i_p <- match(id, p_ids)
      f_b <- if (is.matrix(b_f) && nrow(b_f) >= i_b) b_f[i_b, ] else NULL
      f_p <- if (is.matrix(p_f) && nrow(p_f) >= i_p) p_f[i_p, ] else NULL
      # The policy arm can carry extra coefficient columns (the policy
      # variables' own coefficients, DOC-12); the baseline does not depend on
      # them
      if (!is.null(f_b) && !is.null(f_p) && length(f_p) > length(f_b)) {
        f_b <- c(f_b, numeric(length(f_p) - length(f_b)))
      }
      sd_effect <- if (!is.null(f_b) && !is.null(f_p) &&
        length(f_b) == length(f_p)) {
        sqrt(sum((f_p - f_b)^2, na.rm = TRUE))
      } else {
        sqrt((b_sd[[id]] %||% 0)^2 + (p_sd[[id]] %||% 0)^2)
      }
      tibble::tibble(
        sim_year = yr, model_id = id,
        baseline = b_vals[[id]], policy = p_vals[[id]],
        effect = p_vals[[id]] - b_vals[[id]],
        effect_sd = sd_effect,
        effect_gradient = list(if (!is.null(f_b) && !is.null(f_p) &&
          length(f_b) == length(f_p)) {
          f_p - f_b
        } else {
          NULL
        })
      )
    })
    dplyr::bind_rows(out)
  })
  dplyr::bind_rows(Filter(Negate(is.null), rows))
}

# The mean option also reports matched endpoint levels. The median default
# preserves secondary callers; medians of levels/components need not reconcile.
paired_effect_summary <- function(effect_tbl,
                                  band_q = c(lo = 0.10, hi = 0.90),
                                  scenario = "",
                                  center = c("median", "equal_model_mean")) {
  center <- match.arg(center)
  if (is.null(effect_tbl) || !nrow(effect_tbl)) {
    return(NULL)
  }
  models <- split(effect_tbl, effect_tbl$model_id)
  model_rows <- lapply(models, function(x) {
    valid <- is.finite(x$effect)
    if (identical(center, "equal_model_mean")) {
      valid <- valid & is.finite(x$baseline) & is.finite(x$policy)
    }
    x <- x[valid, , drop = FALSE]
    if (!nrow(x)) {
      return(NULL)
    }
    q <- stats::quantile(x$effect, probs = band_q, na.rm = TRUE, names = FALSE)
    gradients <- if ("effect_gradient" %in% names(x)) {
      x$effect_gradient[
        vapply(
          x$effect_gradient,
          function(g) is.numeric(g) && length(g) > 0L, logical(1L)
        )
      ]
    } else {
      list()
    }
    coef_g <- if (length(gradients) == nrow(x)) Reduce(`+`, gradients) / nrow(x) else NULL
    coef_sd <- if (!is.null(coef_g)) {
      sqrt(sum(coef_g * coef_g, na.rm = TRUE))
    } else {
      # Coefficient error is shared by every year of a model, so it does not
      # shrink with the number of years.
      sqrt(mean(x$effect_sd^2, na.rm = TRUE))
    }
    tibble::tibble(
      model_id = x$model_id[[1L]],
      mean_effect = mean(x$effect),
      baseline = if ("baseline" %in% names(x)) mean(x$baseline) else NA_real_,
      policy = if ("policy" %in% names(x)) mean(x$policy) else NA_real_,
      annual_lo = q[[1L]], annual_hi = q[[2L]],
      coef_sd = coef_sd,
      coef_gradient = list(coef_g),
      n_years = nrow(x)
    )
  })
  model_rows <- dplyr::bind_rows(Filter(Negate(is.null), model_rows))
  if (!nrow(model_rows)) {
    return(NULL)
  }
  center_fn <- if (identical(center, "equal_model_mean")) mean else stats::median
  center_value <- center_fn(model_rows$mean_effect, na.rm = TRUE)
  intermod <- stats::quantile(model_rows$mean_effect,
    probs = band_q,
    na.rm = TRUE, names = FALSE
  )
  interann <- c(
    lo = mean(model_rows$annual_lo, na.rm = TRUE),
    hi = mean(model_rows$annual_hi, na.rm = TRUE)
  )
  z <- stats::qnorm(band_q)
  # The coefficients are shared by every ensemble member, so their error does
  # not average out across members: the exact figure is the norm of the mean
  # gradient. Members without gradients fall back to their own SDs.
  grads <- model_rows$coef_gradient
  coef_sd <- if (all(!vapply(grads, is.null, logical(1L))) &&
    length(unique(lengths(grads))) == 1L) {
    g <- Reduce(`+`, grads) / length(grads)
    sqrt(sum(g * g, na.rm = TRUE))
  } else {
    mean(model_rows$coef_sd, na.rm = TRUE)
  }
  model_rows$coef_gradient <- NULL
  tibble::tibble(
    scenario = scenario, value = center_value,
    baseline = center_fn(model_rows$baseline, na.rm = TRUE),
    policy = center_fn(model_rows$policy, na.rm = TRUE),
    center_method = if (identical(center, "median")) "median_model_mean" else center,
    coef_sd = coef_sd,
    coef_lo = center_value + z[[1L]] * coef_sd,
    coef_hi = center_value + z[[2L]] * coef_sd,
    interann_lo = interann[[1L]], interann_hi = interann[[2L]],
    intermod_lo = intermod[[1L]], intermod_hi = intermod[[2L]],
    n_models = nrow(model_rows), n_years = min(model_rows$n_years),
    n_model_years = sum(model_rows$n_years),
    n_dropped_model_years = nrow(effect_tbl) - sum(model_rows$n_years)
  )
}




#' Data behind the Step 2 return-period dot plot (Figure S2-4)
#' @noRd
step2_adverse_dot_data <- function(threshold_tbl, method = "mean", so = NULL) {
  if (is.null(threshold_tbl) || !nrow(threshold_tbl)) {
    return(tibble::tibble())
  }
  rp_map <- metric_decision_return_periods(method, so)
  keep_rps <- unname(rp_map)
  tbl <- threshold_tbl[threshold_tbl$rp_name %in% keep_rps, , drop = FALSE]
  if (!nrow(tbl)) {
    return(tibble::tibble())
  }

  central <- tbl[tbl$Estimate %in% c("Equal-model mean", "Single historical estimate", "Central (P50)"), , drop = FALSE]
  if (!nrow(central)) {
    return(tibble::tibble())
  }
  central$rp_label <- names(rp_map)[match(central$rp_name, unname(rp_map))]
  central <- filter_historically_supported_return_periods(central, rp_map)
  if (!nrow(central)) return(tibble::tibble())

  ens_rows <- tbl[grepl("^Ensemble ", tbl$Estimate), , drop = FALSE]
  if (nrow(ens_rows)) {
    # The displayed labels vary between min/max and Pxx. Within each
    # scenario, threshold_table_rv creates the complete lower vector before
    # the complete upper vector, so split by scenario before pairing RPs.
    parts <- lapply(split(ens_rows, ens_rows$scenario), function(x) {
      n_each <- nrow(x) %/% 2L
      if (n_each < 1L || nrow(x) != 2L * n_each) {
        return(NULL)
      }
      list(
        lo = x[seq_len(n_each), , drop = FALSE],
        hi = x[seq.int(n_each + 1L, nrow(x)), , drop = FALSE]
      )
    })
    parts <- Filter(Negate(is.null), parts)
    ens_lo <- dplyr::bind_rows(lapply(parts, `[[`, "lo"))
    ens_hi <- dplyr::bind_rows(lapply(parts, `[[`, "hi"))
  } else {
    ens_lo <- ens_hi <- tbl[FALSE, , drop = FALSE]
  }

  central$intermod_lo <- NA_real_
  central$intermod_hi <- NA_real_
  for (i in seq_len(nrow(central))) {
    sc <- central$scenario[[i]]
    rp <- central$rp_name[[i]]
    lo_val <- ens_lo$value[ens_lo$scenario == sc & ens_lo$rp_name == rp]
    hi_val <- ens_hi$value[ens_hi$scenario == sc & ens_hi$rp_name == rp]
    if (length(lo_val)) central$intermod_lo[[i]] <- lo_val[[1L]]
    if (length(hi_val)) central$intermod_hi[[i]] <- hi_val[[1L]]
  }

  central$ssp_key <- ifelse(central$is_historical, "Historical",
    vapply(central$scenario, .normalise_ssp, character(1L))
  )
  central$yr_lbl <- ifelse(central$is_historical, "Historical",
    vapply(central$scenario, .parse_year, character(1L))
  )
  central <- central[is.finite(central$value), , drop = FALSE]
  if (!nrow(central)) return(tibble::tibble())
  present <- c("Expected", "Adverse 1-in-5", "Adverse 1-in-10",
    "Adverse 1-in-20", "Adverse 1-in-50")
  central$rp_label <- factor(central$rp_label,
    levels = rev(present[present %in% as.character(central$rp_label)]))
  central
}


#' Compare the simulated historical baseline with the observed survey
#'
#' Aggregates the observed survey outcome with the same metric function,
#' weights and poverty line as the simulation, and returns the gap to the
#' simulated historical average. The simulated value averages many weather
#' years, so this is a level-calibration check, not an exact reproduction.
#' Returns NULL when the comparison is not available (no observed outcome,
#' binary "poor" outcome, or LCU outcomes without the PPP factor).
#' @param svy Baseline survey frame with the observed outcome column.
#' @param so Selected outcome metadata (name, units, transform).
#' @param method Aggregation method key.
#' @param pov_line Poverty line in outcome units.
#' @param use_weights Logical: apply survey weights, as the simulated series does.
#' @param simulated Simulated historical value (mean across weather years).
#' @param metadata Metric metadata (format, direction).
#' @param rel_tol,pp_tol Flag when the gap exceeds this share of the observed
#'   value (levels) or this absolute amount (rates, on the fraction scale).
#' @return NULL or list(observed, simulated, gap, flag, tolerance_text).
#' @noRd
step2_baseline_check <- function(svy, so, method, pov_line, use_weights,
                                 simulated, metadata = NULL,
                                 rel_tol = 0.10, pp_tol = 0.02) {
  tryCatch(
    {
      if (!is.data.frame(svy) || !is.finite(simulated)) {
        return(NULL)
      }
      name <- as.character(so$name[1L])
      if (!nzchar(name) || !name %in% names(svy) || identical(name, "poor")) {
        return(NULL)
      }
      is_log <- identical(as.character(so$transform[1L]), "log")
      if (isTRUE(as.character(so$units[1L]) == "LCU") && is_log &&
        !"ppp2021" %in% names(svy)) {
        return(NULL)
      }
      df <- prepare_outcome_df(as.data.frame(svy), so)
      y <- suppressWarnings(as.numeric(df[[name]]))
      if (is_log) y <- exp(y)
      w_col <- baseline_weight_column(df)
      w <- if (isTRUE(use_weights) && !is.null(w_col)) {
        suppressWarnings(as.numeric(df[[w_col]]))
      } else {
        NULL
      }
      ok <- if (is.null(w)) is.finite(y) else is.finite(y) & is.finite(w)
      if (!any(ok)) {
        return(NULL)
      }
      observed <- as.numeric(resolve_agg_fn(method)(
        y[ok], if (is.null(w)) NULL else w[ok], pov_line
      ))
      if (length(observed) != 1L || !is.finite(observed)) {
        return(NULL)
      }
      gap <- simulated - observed
      is_rate <- identical((metadata %||% list())$format, "percent")
      limit <- if (is_rate) pp_tol else rel_tol * abs(observed)
      list(
        observed = observed, simulated = simulated, gap = gap,
        flag = is.finite(limit) && limit > 0 && abs(gap) > limit,
        tolerance_text = if (is_rate) {
          paste0(format(100 * pp_tol, trim = TRUE), " pp")
        } else {
          paste0(format(100 * rel_tol, trim = TRUE), "%")
        }
      )
    },
    error = function(e) NULL
  )
}

# Step 2 headline cards ----

#' Coefficient (estimation) standard deviation of the climate shift
#'
#' The standard deviation of (equal-model mean of the scenario) minus
#' (historical mean) caused by uncertainty in the estimated weather
#' coefficients. Uses the per-year aggregate gradients (`F_agg_all`) carried by
#' the aggregation tables: the same coefficient draws move the scenario and
#' historical aggregates together, so the contrast is the norm of the
#' difference of the mean gradients (the construction behind the deviation
#' modes' contrast SDs). Returns NULL when gradients are unavailable, for
#' example when coefficient uncertainty was skipped.
#' @param hist_tbl,scen_tbl Aggregation tables with an `F_agg_all` list-column
#'   (one model x coefficient-factor matrix per year).
#' @return NULL or `list(sd = <numeric>)`.
#' @noRd
step2_delta_ci <- function(hist_tbl, scen_tbl) {
  mean_gradient <- function(tbl) {
    if (is.null(tbl) || !is.data.frame(tbl) || !"F_agg_all" %in% names(tbl)) {
      return(NULL)
    }
    rows <- lapply(tbl$F_agg_all, function(m) {
      if (is.matrix(m) && nrow(m) > 0L) colMeans(m, na.rm = TRUE) else NULL
    })
    rows <- Filter(Negate(is.null), rows)
    if (!length(rows) || length(unique(lengths(rows))) != 1L) {
      return(NULL)
    }
    Reduce(`+`, rows) / length(rows)
  }
  g_hist <- mean_gradient(hist_tbl)
  g_scen <- mean_gradient(scen_tbl)
  if (is.null(g_hist) || is.null(g_scen) || length(g_hist) != length(g_scen)) {
    return(NULL)
  }
  d <- g_scen - g_hist
  sd <- sqrt(sum(d * d, na.rm = TRUE))
  if (!is.finite(sd) || sd <= 0) NULL else list(sd = sd)
}

#' Return period of the historical adverse level under another scenario
#'
#' Share of simulated model-years at or beyond `threshold` on the adverse side
#' gives the exceedance probability; its inverse is the new return period.
#' Returns `Inf` when no simulated year reaches the threshold and `NA` when
#' there is nothing to evaluate.
#' @param values Numeric vector of annual aggregates (all models pooled).
#' @param threshold Numeric scalar, the historical adverse level.
#' @param adverse_tail `"high"` or `"low"`.
#' @noRd
step2_adverse_return_period <- function(values, threshold, adverse_tail = "high") {
  values <- values[is.finite(values)]
  if (!length(values) || !is.finite(threshold)) {
    return(NA_real_)
  }
  hit <- if (identical(adverse_tail, "high")) values >= threshold else values <= threshold
  p <- mean(hit)
  if (p <= 0) Inf else 1 / p
}

#' Build Step 2 Results Headline Cards
#'
#' Pure function returning a list of 5 card specifications for
#' \code{headline_cards_ui()}, matching the \code{mod_1} design language:
#' \enumerate{
#'   \item Typical weather year outcome (Scenario expected, historical baseline, change)
#'   \item Adverse weather year outcomes (1-in-10 and 1-in-20 thresholds)
#'   \item Weather-year range (range across years: inter-annual weather variability)
#'   \item Climate-model spread (range across models & coefficient uncertainty)
#'   \item Simulation years (tally of simulation years: scenarios * models * years)
#' }
#'
#' @param bands Data frame from \code{pointrange_bands_rv()}.
#' @param threshold_tbl Data frame from \code{threshold_table_rv()}.
#' @param hist_sim List from \code{hist_sim()}.
#' @param saved_scenarios List of saved future scenarios.
#' @param method Character aggregation method (default "mean").
#' @param timeseries_curves Data frame from \code{timeseries_curves_rv()}.
#'
#' @return A list of 5 card lists ready for \code{headline_cards_ui()}.
#' @noRd
step2_headline_cards <- function(bands,
                                 threshold_tbl = NULL,
                                 hist_sim = NULL,
                                 saved_scenarios = list(),
                                 method = "mean",
                                 timeseries_curves = NULL,
                                 deviation = "none",
                                 metadata = NULL,
                                 baseline_check = NULL,
                                 delta_ci = NULL,
                                 weather_support = NULL) {
  if (is.null(bands) || !nrow(bands) ||
    !all(c("is_historical", "scenario") %in% names(bands))) {
    return(NULL)
  }

  hist_rows <- bands[bands$is_historical, , drop = FALSE]
  fut_rows <- bands[!bands$is_historical, , drop = FALSE]
  if (!nrow(hist_rows) && !nrow(fut_rows)) {
    return(NULL)
  }

  hist <- if (nrow(hist_rows)) hist_rows[1L, ] else fut_rows[1L, ]
  focus <- if (nrow(fut_rows)) fut_rows[1L, ] else hist
  has_future <- nrow(fut_rows) > 0L

  so <- if (!is.null(hist_sim)) hist_sim$so else NULL
  metadata <- metadata %||% metric_metadata(method, so)
  is_change <- !identical(deviation, "none")
  deviation_label <- switch(deviation,
    none = "",
    mean = "Difference from historical mean",
    median = "Difference from historical median",
    ""
  )
  display_digits <- if (identical(method, "total")) {
    0L
  } else if (identical(metadata$format, "percent")) {
    1L
  } else {
    2L
  }
  display_value <- function(x, change = is_change) {
    if (length(x) != 1L || !is.finite(suppressWarnings(as.numeric(x)))) {
      return("Unavailable")
    }
    if (isTRUE(change)) {
      return(format_metric_value(as.numeric(x), metadata, change = TRUE,
        digits = display_digits))
    }
    value <- format_metric_value(as.numeric(x), metadata, change = FALSE,
      digits = display_digits)
    if (identical(metadata$format, "percent")) return(value)
    unit <- metadata$level_unit %||% "outcome units"
    suffix <- paste0(" ", unit)
    if (endsWith(value, suffix)) substr(value, 1L, nchar(value) - nchar(suffix)) else value
  }
  direction <- metadata$direction %||% "higher_is_better"
  arrow <- " \u2192 "

  has_curves <- !is.null(timeseries_curves) && nrow(timeseries_curves) &&
    all(c("scenario", "value") %in% names(timeseries_curves))
  curve_values <- function(scenario) {
    if (!has_curves) return(numeric(0L))
    v <- timeseries_curves$value[timeseries_curves$scenario == scenario]
    v[is.finite(v)]
  }

  scen_lab <- if (has_future) as.character(focus$scenario) else NULL
  # Weighted population (people) for translating a rate change into the
  # number of poor; only for headcount metrics with survey weights.
  w_pop <- if (!is.null(hist_sim$svy) && "weight" %in% names(hist_sim$svy) &&
    identical(metadata$weighted, TRUE)) {
    w <- suppressWarnings(as.numeric(hist_sim$svy$weight))
    sum(w[is.finite(w)])
  } else {
    NA_real_
  }
  poor_line <- function(change) {
    if (!identical(method, "headcount_ratio") || is_change) return(NULL)
    poor_change_text(change, w_pop)
  }

  # 1. Expected change (focus scenario vs historical, average year)
  change_1 <- if (has_future) focus$value - hist$value else NA_real_
  val_1 <- if (has_future) display_value(change_1, change = TRUE) else display_value(hist$value)
  line1_1 <- if (has_future && is_change) {
    deviation_label
  } else if (has_future) {
    paste0(display_value(hist$value), arrow, display_value(focus$value))
  } else {
    "Historical baseline"
  }
  line2_1 <- if (has_future) {
    paste0("Historical", arrow, scen_lab, " \u00b7 average year")
  } else {
    "Average year"
  }
  poor_1 <- if (has_future) poor_line(change_1) else NULL
  # 95% interval from estimation (coefficient) uncertainty only.
  ci_1 <- NULL
  if (has_future && !is.null(delta_ci) && is.finite(change_1)) {
    half <- stats::qnorm(0.975) * delta_ci$sd
    drop_unit <- function(txt) {
      unit <- metadata$change_unit %||% ""
      if (nzchar(unit) && endsWith(txt, paste0(" ", unit))) {
        substr(txt, 1L, nchar(txt) - nchar(unit) - 1L)
      } else {
        txt
      }
    }
    ci_1 <- list(
      lo = change_1 - half, hi = change_1 + half,
      text = paste0(
        "(95% CI: ", drop_unit(display_value(change_1 - half, change = TRUE)), " to ",
        display_value(change_1 + half, change = TRUE), ")"
      )
    )
  }

  card1 <- list(
    label = if (has_future) "Expected change" else "Expected outcome",
    value = val_1,
    note = paste(c(line1_1, ci_1$text, line2_1, poor_1), collapse = " \u00b7 "),
    note_html = shiny::tagList(
      shiny::tags$div(line1_1),
      if (!is.null(ci_1)) shiny::tags$div(ci_1$text),
      shiny::tags$div(style = "font-weight: 600;", line2_1),
      if (!is.null(poor_1)) shiny::tags$div(poor_1)
    ),
    info = paste(
      "Expected annual aggregate outcome under the focus climate scenario compared with the",
      "historical baseline (mean across weather years and climate models).",
      "Differences reflect simulated climate conditions for the fixed survey population.",
      "Short-run weather responses estimated in Step 1 are applied to future weather;",
      "adaptation is not included.",
      if (!is.null(ci_1)) paste(
        "The 95% interval reflects uncertainty in the estimated weather coefficients only;",
        "climate-model disagreement and year-to-year weather variability are shown on the",
        "Signal vs noise and Year-to-year range cards."
      ),
      "Weather values outside the historical range need",
      "extrapolation: the Diagnostics tab flags them under weather support.",
      if (has_future) paste0("Historical: ", display_value(hist$value),
        ". Scenario: ", display_value(focus$value), "."),
      metric_context_note(metadata)
    ),
    basis_text = "Short-run weather response; adaptation not included"
  )
  # Level calibration of the simulated historical baseline against the survey.
  if (!is.null(baseline_check)) {
    check_txt <- paste0(
      "Baseline check: simulated ", display_value(baseline_check$simulated, change = FALSE),
      " vs survey ", display_value(baseline_check$observed, change = FALSE),
      " (", display_value(baseline_check$gap, change = TRUE), ")"
    )
    card1$info <- paste(
      card1$info, paste0(check_txt, "."),
      "The simulated value averages many weather years; the survey is one observed",
      "period, so small gaps are expected. A gap above ", baseline_check$tolerance_text,
      " is flagged because every level reported in Steps 2\u20133 inherits it."
    )
    if (isTRUE(baseline_check$flag)) {
      card1$basis_text <- paste(
        card1$basis_text, paste0(check_txt, " \u2014 exceeds ", baseline_check$tolerance_text),
        sep = " \u00b7 "
      )
    }
    card1$baseline_check <- baseline_check
  }
  # Weather support: how much of the simulated weather lies outside the
  # fitted-sample reference interval (extrapolation). Always in the popover; a
  # warning in the basis strip when any variable exceeds the 5% rule.
  if (is.data.frame(weather_support) && nrow(weather_support) &&
    all(c("weather_variable", "outside_share", "warning") %in% names(weather_support))) {
    ws_name <- if ("weather_label" %in% names(weather_support)) {
      ifelse(is.na(weather_support$weather_label), weather_support$weather_variable,
        weather_support$weather_label)
    } else {
      weather_support$weather_variable
    }
    ws_pct <- paste0(formatC(100 * weather_support$outside_share, format = "f", digits = 1), "%")
    ws_txt <- paste0(ws_name, " ", ws_pct, collapse = "; ")
    card1$info <- paste(
      card1$info,
      paste0("Weather support (share of simulated weather outside the range of the fitted sample): ",
        ws_txt, "."),
      "Values outside that range are extrapolated by the fitted model; more than 5% is flagged.",
      "Details are on the Diagnostics tab."
    )
    if (any(weather_support$warning, na.rm = TRUE)) {
      bad <- weather_support$warning & !is.na(weather_support$warning)
      card1$basis_text <- paste(
        card1$basis_text,
        paste0("Weather outside fitted-sample range: ",
          paste0(ws_name[bad], " ", ws_pct[bad], collapse = ", "), " (see Diagnostics)"),
        sep = " \u00b7 "
      )
    }
    card1$weather_support <- weather_support
  }
  card1$value_native <- as.numeric(c(hist$value, if (has_future) focus$value else NA_real_))
  card1$change_native <- change_1
  card1$change_ci_native <- if (!is.null(ci_1)) c(ci_1$lo, ci_1$hi) else c(NA_real_, NA_real_)
  card1$change_display <- if (has_future) display_value(change_1, change = TRUE) else ""
  if (has_future) card1$status <- headline_status(change_1, direction, display = card1$change_display)
  if (nzchar(card1$change_display)) {
    card1$note <- paste(card1$note, paste("Difference:", card1$change_display), sep = " \u00b7 ")
  }

  # 2. Adverse weather years (1-in-20 year), plus how often the historical
  # 1-in-20 level is reached under the focus scenario.
  v20_hist <- NA_real_
  v20_ssp <- NA_real_
  if (!is.null(threshold_tbl) && nrow(threshold_tbl) &&
    all(c("scenario", "rp_name", "Estimate") %in% names(threshold_tbl))) {
    rp_map <- metric_decision_return_periods(method %||% "mean", so)
    rp_20 <- unname(rp_map[["Adverse 1-in-20"]])
    r20_hist <- threshold_tbl[threshold_tbl$scenario == "Historical" &
      threshold_tbl$rp_name == rp_20 &
      threshold_tbl$Estimate %in% c("Equal-model mean", "Single historical estimate", "Central (P50)"), , drop = FALSE]
    r20_ssp <- threshold_tbl[threshold_tbl$scenario == focus$scenario &
      threshold_tbl$rp_name == rp_20 &
      threshold_tbl$Estimate %in% c("Equal-model mean", "Single historical estimate", "Central (P50)"), , drop = FALSE]
    if (nrow(r20_hist) && is.finite(r20_hist$value[[1L]])) v20_hist <- r20_hist$value[[1L]]
    if (nrow(r20_ssp) && is.finite(r20_ssp$value[[1L]])) v20_ssp <- r20_ssp$value[[1L]]
  }

  both_20 <- has_future && is.finite(v20_hist) && is.finite(v20_ssp)
  change_2 <- if (both_20) v20_ssp - v20_hist else NA_real_
  focus_vals <- if (both_20) curve_values(focus$scenario) else numeric(0L)
  rp_focus <- if (both_20 && length(focus_vals) >= 20L) {
    step2_adverse_return_period(focus_vals, v20_hist, metadata$adverse_tail %||% "high")
  } else {
    NA_real_
  }
  rp_text <- if (is.na(rp_focus)) {
    NULL
  } else if (is.infinite(rp_focus)) {
    paste0("rarer than 1-in-", format(length(focus_vals), big.mark = ","))
  } else {
    paste0("about 1-in-", format(max(1, round(rp_focus)), big.mark = ","))
  }
  poor_2 <- if (both_20) poor_line(change_2) else NULL
  if (both_20) {
    val_2 <- display_value(change_2, change = TRUE)
    line1_2 <- if (is_change) {
      deviation_label
    } else {
      paste0(display_value(v20_hist, change = FALSE), arrow, display_value(v20_ssp, change = FALSE))
    }
    line2_2 <- if (is.null(rp_text)) {
      paste0("1-in-20 year \u00b7 ", scen_lab)
    } else {
      paste0("Historical 1-in-20 year", arrow, rp_text, " in ", scen_lab)
    }
  } else if (!has_future && is.finite(v20_hist)) {
    val_2 <- display_value(v20_hist, change = FALSE)
    line1_2 <- if (is_change) paste(deviation_label, "\u00b7 Historical baseline") else "Historical baseline"
    line2_2 <- "1-in-20 year"
  } else if (has_future && is.finite(v20_ssp)) {
    val_2 <- display_value(v20_ssp, change = FALSE)
    line1_2 <- as.character(focus$scenario)
    line2_2 <- "1-in-20 year"
  } else {
    val_2 <- "Unavailable"
    line1_2 <- "Requires \u226520 weather years"
    line2_2 <- "1-in-20 year"
  }

  card2 <- list(
    label = "Adverse weather years",
    value = val_2,
    note = paste(c(line1_2, line2_2, poor_2), collapse = " \u00b7 "),
    note_html = shiny::tagList(
      shiny::tags$div(line1_2),
      shiny::tags$div(style = "font-weight: 600;", line2_2),
      if (!is.null(poor_2)) shiny::tags$div(poor_2)
    ),
    info = paste(
      "Simulated aggregate outcome in adverse 1-in-20 weather years under the historical",
      "baseline compared with the focus climate regime. A 1-in-20 year event occurs in",
      "approximately 5% of simulated weather years. The adverse tail is determined",
      "automatically by the selected metric. Thresholds are the equal-weight mean across",
      "climate models of each model's rank-interpolated adverse year.",
      if (!is.null(rp_text)) paste0(
        "Return-period shift: the share of simulated model-years under the focus scenario",
        " at or beyond the historical 1-in-20 level gives the new frequency (",
        rp_text, ")."
      ),
      if (both_20) paste0("Historical: ", display_value(v20_hist, change = FALSE),
        ". Scenario: ", display_value(v20_ssp, change = FALSE), "."),
      metric_context_note(metadata)
    )
  )
  card2$value_native <- as.numeric(c(v20_hist, v20_ssp))
  card2$change_native <- change_2
  card2$change_display <- if (both_20) display_value(change_2, change = TRUE) else ""
  card2$return_period_native <- rp_focus
  if (both_20) card2$status <- headline_status(change_2, direction, display = card2$change_display)
  if (nzchar(card2$change_display)) {
    card2$note <- paste(card2$note, paste("Difference:", card2$change_display), sep = " \u00b7 ")
  }

  # 3. Signal vs noise: do the climate models agree on the direction of the
  # change, and how large is the shift relative to year-to-year variability?
  n_mods <- suppressWarnings(as.integer(focus$n_models %||% 1L))[1L]
  if (!is.finite(n_mods) || n_mods < 1L) n_mods <- 1L

  focus_model_means <- if (has_curves) {
    x <- timeseries_curves[timeseries_curves$scenario == focus$scenario, , drop = FALSE]
    if (nrow(x) && "model_id" %in% names(x)) {
      tapply(x$value, x$model_id, mean, na.rm = TRUE)
    } else {
      numeric(0L)
    }
  } else {
    numeric(0L)
  }
  focus_model_means <- as.numeric(focus_model_means[is.finite(focus_model_means)])
  hist_curve <- curve_values("Historical")
  hist_mean <- if (length(hist_curve)) mean(hist_curve) else hist$value
  hist_sd <- if (length(hist_curve) >= 3L) stats::sd(hist_curve) else NA_real_
  model_change <- focus_model_means - hist_mean
  n_agree <- if (is.finite(change_1) && length(model_change) > 1L && change_1 != 0) {
    sum(sign(model_change) == sign(change_1))
  } else {
    NA_integer_
  }
  agree_share <- if (is.finite(n_agree)) n_agree / length(model_change) else NA_real_
  snr <- if (has_future && is.finite(hist_sd) && hist_sd > 0 && is.finite(change_1)) {
    abs(change_1) / hist_sd
  } else {
    NA_real_
  }

  val_3 <- if (!has_future) {
    "Not applicable"
  } else if (is.finite(n_agree)) {
    paste0(n_agree, " of ", length(model_change), " models")
  } else if (n_mods <= 1L) {
    "Single climate model"
  } else {
    "Unavailable"
  }
  line1_3 <- if (is.finite(n_agree)) {
    "agree on direction of change"
  } else if (has_future) {
    "no model comparison"
  } else {
    "Historical baseline"
  }
  line2_3 <- if (is.finite(snr)) {
    paste0("Shift is ", format(round(snr, 1), nsmall = 1), "\u00d7 the usual year-to-year swing")
  } else {
    NULL
  }
  line3_3 <- if (has_future) scen_lab else NULL

  card3 <- list(
    label = "Signal vs noise",
    value = val_3,
    note = paste(c(line1_3, line2_3, line3_3), collapse = " \u00b7 "),
    note_html = shiny::tagList(
      shiny::tags$div(line1_3),
      if (!is.null(line2_3)) shiny::tags$div(line2_3),
      if (!is.null(line3_3)) shiny::tags$div(style = "font-weight: 600;", line3_3)
    ),
    info = paste(
      "Share of CMIP6 climate models whose average change for the focus scenario has the",
      "same sign as the ensemble change; 80% or more is flagged as robust. The second line",
      "compares the size of the climate shift with the standard deviation of historical",
      "year-to-year outcomes, that is the usual swing between one weather year and the next",
      "(a shift well below 1\u00d7 is hard to distinguish from ordinary weather variability).",
      if (length(focus_model_means) > 1L) paste0(
        "Range of model averages: ", display_value(min(focus_model_means)), " to ",
        display_value(max(focus_model_means)), "."
      ),
      if (all(c("coef_lo", "coef_hi") %in% names(focus)) &&
        is.finite(focus$coef_lo) && is.finite(focus$coef_hi)) paste0(
        "Estimation (coefficient) uncertainty on the expected outcome: ",
        display_value(focus$coef_lo), " to ", display_value(focus$coef_hi), "."
      ),
      "Model spread is evaluated at the central coefficient estimates."
    )
  )
  card3$value_range_native <- if (has_future && length(focus_model_means) > 1L) {
    c(min(focus_model_means), max(focus_model_means))
  } else {
    c(NA_real_, NA_real_)
  }
  card3$snr_native <- snr
  if (is.finite(agree_share)) {
    card3$status <- if (agree_share >= 0.8) {
      dir <- headline_status(change_1, direction)
      list(
        kind = dir$kind %||% "neutral",
        text = if (is.null(dir)) {
          "Robust direction"
        } else if (dir$kind == "favourable") {
          "Robust: improves"
        } else if (dir$kind == "adverse") {
          "Robust: worsens"
        } else {
          "Robust direction"
        }
      )
    } else {
      list(kind = "uncertain", text = "Models disagree")
    }
  }

  # 4. Year-to-year range of the annual aggregate (internal weather variability).
  # Range across years (inter-annual weather variability). For future
  # scenarios, first calculate each model's observed year range, then average
  # the lower and upper endpoints across models. This is different from taking
  # quantiles of the pooled model-year values, which can overweight extremes.
  finite_range <- function(x) {
    x <- x[is.finite(x)]
    if (!length(x)) {
      return(c(lo = NA_real_, hi = NA_real_))
    }
    c(lo = min(x), hi = max(x))
  }
  scenario_year_range <- function(scenario) {
    if (is.null(timeseries_curves) || !nrow(timeseries_curves) ||
      !all(c("scenario", "value") %in% names(timeseries_curves))) {
      return(c(lo = NA_real_, hi = NA_real_))
    }
    x <- timeseries_curves[timeseries_curves$scenario == scenario, , drop = FALSE]
    if (!nrow(x)) {
      return(c(lo = NA_real_, hi = NA_real_))
    }
    if ("model_id" %in% names(x)) {
      by_model <- split(x$value, x$model_id)
      ranges <- lapply(by_model, finite_range)
      ranges <- ranges[vapply(ranges, function(r) all(is.finite(r)), logical(1L))]
      if (!length(ranges)) {
        return(c(lo = NA_real_, hi = NA_real_))
      }
      c(
        lo = mean(vapply(ranges, `[[`, numeric(1L), "lo"), na.rm = TRUE),
        hi = mean(vapply(ranges, `[[`, numeric(1L), "hi"), na.rm = TRUE)
      )
    } else {
      finite_range(x$value)
    }
  }
  hist_range <- scenario_year_range("Historical")
  focus_range <- scenario_year_range(focus$scenario)
  if (!is.finite(focus_range[["lo"]])) {
    focus_range <- c(lo = focus$interann_lo, hi = focus$interann_hi)
  }
  if (!is.finite(hist_range[["lo"]])) {
    hist_range <- c(lo = hist$interann_lo, hi = hist$interann_hi)
  }

  val_r <- if (has_future && all(is.finite(focus_range))) {
    paste(display_value(focus_range[["lo"]]), "to", display_value(focus_range[["hi"]]))
  } else if (all(is.finite(hist_range))) {
    paste(display_value(hist_range[["lo"]]), "to", display_value(hist_range[["hi"]]))
  } else {
    "Unavailable"
  }

  line1_r <- if (has_future && all(is.finite(hist_range))) {
    paste0("Hist: ", display_value(hist_range[["lo"]]), " to ", display_value(hist_range[["hi"]]))
  } else {
    "Historical baseline"
  }
  line2_r <- if (has_future) scen_lab else "Inter-annual weather variability"

  card_range <- list(
    label = "Year-to-year range",
    value = val_r,
    note = paste(line1_r, line2_r, sep = " \u00b7 "),
    note_html = shiny::tagList(
      shiny::tags$div(line1_r),
      shiny::tags$div(style = "font-weight: 600;", line2_r)
    ),
    info = paste(
      "Range of annual population aggregate outcomes across simulated weather-year",
      "realizations within the selected climate regime. This characterises",
      "year-to-year weather fluctuations, not household inequality or continuous",
      "time forecasting."
    )
  )
  card_range$value_range_native <- if (has_future && all(is.finite(focus_range))) {
    as.numeric(focus_range)
  } else if (all(is.finite(hist_range))) {
    as.numeric(hist_range)
  } else {
    c(NA_real_, NA_real_)
  }

  card4 <- card_range

  # 5. Tally of simulation years (e.g. scenarios * models * years...)
  run_info <- if (!is.null(hist_sim)) hist_sim$sim_summary %||% list() else list()

  # Number of simulation years per model (evaluated on focus scenario)
  hist_years <- run_info$historical_years %||% integer(0)
  focus_curves <- if (!is.null(timeseries_curves) && nrow(timeseries_curves)) {
    timeseries_curves[timeseries_curves$scenario == focus$scenario, , drop = FALSE]
  } else {
    NULL
  }

  n_years <- if (!is.null(focus_curves) && nrow(focus_curves)) {
    length(unique(focus_curves$sim_year))
  } else if (!is.null(timeseries_curves) && nrow(timeseries_curves)) {
    length(unique(timeseries_curves$sim_year))
  } else if (length(hist_years) >= 2L && is.finite(hist_years[1]) && is.finite(hist_years[2])) {
    as.integer(hist_years[2] - hist_years[1] + 1L)
  } else {
    30L
  }

  n_scenarios <- length(saved_scenarios %||% list())
  if (!n_scenarios && nrow(fut_rows)) {
    n_scenarios <- length(unique(as.character(fut_rows$scenario)))
  }

  # Total simulated model-years across all scenarios, models, and weather years
  total_runs <- if (!is.null(timeseries_curves) && nrow(timeseries_curves)) {
    nrow(timeseries_curves)
  } else if (is.finite(run_info$total_runs %||% NA_integer_) && run_info$total_runs > 0L && n_mods <= 1L) {
    run_info$total_runs
  } else {
    (max(n_scenarios, 1L) * n_mods + (if (has_future) 1L else 0L)) * n_years
  }

  val_5 <- format(total_runs, big.mark = ",")
  sample_rows <- if (!is.null(hist_sim$svy)) nrow(hist_sim$svy) else NA_integer_
  prediction_count <- if (is.finite(sample_rows) && sample_rows > 0L) {
    as.numeric(total_runs) * sample_rows
  } else {
    NA_real_
  }
  prediction_note <- format_prediction_count(prediction_count, metadata$analysis_unit)

  # Counts come from the simulated table itself (scenarios selected for
  # Results, models and years actually present per scenario), not from the
  # saved-scenario list or the focus scenario's model count.
  sim_struct <- NULL
  if (has_curves && all(c("model_id", "sim_year") %in% names(timeseries_curves))) {
    is_h <- if ("is_historical" %in% names(timeseries_curves)) {
      as.logical(timeseries_curves$is_historical)
    } else {
      timeseries_curves$scenario == "Historical"
    }
    fut_tbl <- timeseries_curves[!is_h, , drop = FALSE]
    if (nrow(fut_tbl)) {
      per <- split(fut_tbl, fut_tbl$scenario)
      sim_struct <- list(
        k = length(per),
        m = vapply(per, function(d) length(unique(d$model_id)), integer(1L)),
        y = vapply(per, function(d) length(unique(d$sim_year)), integer(1L)),
        hy = length(unique(timeseries_curves$sim_year[is_h]))
      )
    }
  }
  scen_word <- function(k) if (k == 1L) "scenario" else "scenarios"
  line1_5 <- if (!is.null(sim_struct) && length(unique(sim_struct$m)) == 1L &&
    length(unique(sim_struct$y)) == 1L &&
    (sim_struct$hy == 0L || sim_struct$hy == sim_struct$y[[1L]])) {
    paste0(
      "(", sim_struct$k, " ", scen_word(sim_struct$k), " \u00d7 ", sim_struct$m[[1L]], " models",
      if (sim_struct$hy > 0L) " + 1 historical" else "", ") \u00d7 ",
      sim_struct$y[[1L]], " yrs"
    )
  } else if (!is.null(sim_struct)) {
    rng <- function(x) if (min(x) == max(x)) as.character(min(x)) else paste0(min(x), "\u2013", max(x))
    paste0(
      sim_struct$k, " ", scen_word(sim_struct$k), ", ", rng(sim_struct$m),
      " models and ", rng(sim_struct$y), " yrs each"
    )
  } else if (n_scenarios > 0L) {
    paste0(
      "(", n_scenarios, " ", scen_word(n_scenarios), " \u00d7 ",
      n_mods, " models + 1 historical) \u00d7 ", n_years, " yrs"
    )
  } else {
    paste0("1 historical \u00d7 ", n_years, " yrs")
  }

  card5 <- list(
    label = "Simulation years",
    value = val_5,
    note = paste(line1_5, prediction_note, sep = " \u00b7 "),
    note_html = shiny::tagList(
      shiny::tags$div(line1_5),
      shiny::tags$div(style = "font-weight: 600;", prediction_note)
    ),
    class = "neutral",
    # Provenance, not a result: drawn as a basis strip, not a card.
    basis_only = TRUE,
    basis_text = paste0(
      val_5, " simulation years: ", line1_5, " \u00b7 ", prediction_note
    ),
    info = paste(
      "Total number of simulated population aggregates across all configured",
      "climate scenarios, ensemble climate models, and annual weather draws",
      "(scenarios \u00d7 models \u00d7 weather years). The prediction count multiplies",
      "simulation years by the number of sampled survey rows."
    )
  )
  card5$value_native <- as.numeric(total_runs)
  card5$prediction_count_native <- prediction_count
    card5$prediction_count_note <- prediction_note
  card5$prediction_sample_rows <- sample_rows

  cards <- list(card1, card2, card3, card4, card5)
  for (i in seq_along(cards)) {
    cards[[i]]$metadata <- metadata
    cards[[i]]$deviation <- deviation
    cards[[i]]$summary_method <- if (i %in% c(1L, 3L, 4L)) {
      "equal_model_mean"
    } else if (i == 2L) {
      "median_across_climate_models"
    } else {
      "simulation_count"
    }
  }
  cards
}

#' Convert Step 2 Headline Cards to a Tidy Data Frame
#'
#' @param cards List returned by \code{step2_headline_cards()}.
#' @param metadata Optional metric metadata from \code{metric_metadata()}.
#' @param summary Optional summary context to append to every row.
#' @return A tidy data frame with display values, native numeric values, and context.
#' @noRd
step2_headline_df <- function(cards, metadata = NULL, summary = NULL) {
  if (is.null(cards) || !length(cards)) {
    return(data.frame(
      Metric = character(0), Value = character(0), Note = character(0),
      Historical_native = numeric(0), Focus_native = numeric(0),
      Difference_native = numeric(0), Difference_display = character(0),
      Range_lower_native = numeric(0), Range_upper_native = numeric(0),
      Native_unit = character(0), Display_unit = character(0),
      Threshold_kind = character(0), Threshold_value = numeric(0),
      Threshold_unit = character(0), Analysis_unit = character(0),
      Weight_interpretation = character(0), Deviation = character(0),
      Summary_method = character(0), Summary_scope = character(0), Context = character(0),
      stringsAsFactors = FALSE
    ))
  }
  metadata <- metadata %||% cards[[1L]]$metadata %||% metric_metadata()
  number_or_na <- function(x, i = NULL) {
    if (is.null(x)) return(NA_real_)
    if (!is.null(i)) {
      if (length(x) < i) return(NA_real_)
      x <- x[[i]]
    }
    x <- suppressWarnings(as.numeric(x))[1L]
    if (length(x) && is.finite(x)) x else NA_real_
  }
  summary_method <- vapply(cards, function(card) {
    as.character(card$summary_method %||% "")
  }, character(1L))
  context <- summary %||% metric_context_note(metadata)
  data.frame(
    Metric = vapply(cards, function(c) as.character(c$label %||% ""), character(1L)),
    Value = vapply(cards, function(c) as.character(c$value %||% ""), character(1L)),
    Note = vapply(cards, function(c) as.character(c$note %||% ""), character(1L)),
    Prediction_count_native = vapply(cards, function(c) number_or_na(c$prediction_count_native), numeric(1L)),
    Prediction_sample_rows = vapply(cards, function(c) number_or_na(c$prediction_sample_rows), numeric(1L)),
    Prediction_count_display = vapply(cards, function(c) as.character(c$prediction_count_note %||% ""), character(1L)),
    Historical_native = vapply(cards, function(c) number_or_na(c$value_native, 1L), numeric(1L)),
    Focus_native = vapply(cards, function(c) number_or_na(c$value_native, 2L), numeric(1L)),
    Difference_native = vapply(cards, function(c) number_or_na(c$change_native), numeric(1L)),
    Difference_display = vapply(cards, function(c) as.character(c$change_display %||% ""), character(1L)),
    Range_lower_native = vapply(cards, function(c) number_or_na(c$value_range_native, 1L), numeric(1L)),
    Range_upper_native = vapply(cards, function(c) number_or_na(c$value_range_native, 2L), numeric(1L)),
    Native_unit = rep(metadata$native_unit %||% "outcome units", length(cards)),
    Display_unit = vapply(cards, function(card) {
      if (!identical(card$deviation %||% "none", "none")) {
        metadata$change_unit %||% "outcome units"
      } else {
        metadata$level_unit %||% "outcome units"
      }
    }, character(1L)),
    Threshold_kind = rep(metadata$threshold_kind %||% "none", length(cards)),
    Threshold_value = rep(number_or_na(metadata$threshold_value), length(cards)),
    Threshold_unit = rep(metadata$threshold_unit %||% "", length(cards)),
    Analysis_unit = rep(metadata$analysis_unit %||% "", length(cards)),
    Weight_interpretation = rep(metadata$weight_interpretation %||% "", length(cards)),
    Deviation = vapply(cards, function(c) as.character(c$deviation %||% "none"), character(1L)),
    Summary_method = summary_method,
    Summary_scope = rep(paste(
      if (identical(metadata$weighted, TRUE)) {
        "survey-weighted annual aggregate"
      } else if (identical(metadata$weighted, FALSE)) {
        "unweighted annual aggregate"
      } else {
        "annual aggregate; weight status unknown"
      },
      "for fixed survey population; focus climate scenario"
    ), length(cards)),
    Context = rep(as.character(context)[1L], length(cards)),
    stringsAsFactors = FALSE
  )
}

# Threshold table data frame ----

#' Build Return-Period Threshold Table Data Frame
#'
#' Pure function that converts a named list of aggregated series (output of
#' \code{aggregate_sim_preds()}) into a sorted data frame suitable for
#' \code{DT::datatable()}. Replaces the inline wrangling that previously
#' lived inside \code{renderDT} in mod_2_06_sim_compare_server().
#'
#' @param threshold_tbl Data frame. Band-assembled threshold frame with
#'   columns `scenario`, `source`, `rp_label`, `Estimate`, and `value`.
#' @param group_order Character. \code{"scenario_x_year"} (default) or
#'   \code{"year_x_scenario"}.
#' @param show_coef Logical. When `FALSE`, coefficient-band rows (labels
#'   starting with `"Coef "`) are dropped.
#' @param adverse_only Logical. When `TRUE`, keep only the decision return
#'   periods for `method` and `so`, and drop the 1-in-50 row when the
#'   historical record is shorter than 50 years.
#' @param method Scalar character aggregation method (for example `"mean"`),
#'   used to pick the decision return periods when `adverse_only = TRUE`.
#' @param so Selected outcome metadata (list with `$name`, `$transform`), used
#'   with `method` to pick the decision return periods.
#' @param n_hist_years Optional integer length of the historical record in
#'   years; `NULL` uses the largest observation count in the table.
#'
#' @return A data frame with columns: Scenario, Obs, one column per
#'   return-period threshold label, sorted by \code{group_order}. Returns
#'   NULL when every series has insufficient data.
#'
#' @importFrom stats quantile median
#' @export
build_threshold_table_df <- function(threshold_tbl,
                                     group_order = "scenario_x_year",
                                     show_coef = TRUE,
                                     adverse_only = FALSE,
                                     method = "mean",
                                     so = NULL,
                                     n_hist_years = NULL) {
  if (is.null(threshold_tbl) || nrow(threshold_tbl) == 0L) {
    return(NULL)
  }
  df <- threshold_tbl
  has_source <- "source" %in% names(df)
  if (has_source) {
    # Historical row from the Policy source is identical to Baseline by
    # construction (policy doesn't apply to historical) - drop it.
    df <- df[!(grepl("^Historical", df$scenario) & df$source == "Policy"), ,
      drop = FALSE
    ]
  }

  # Optionally hide the coefficient-band rows (any "Coef Pxx" label).
  if (!isTRUE(show_coef)) {
    df <- df[!grepl("^Coef ", df$Estimate), , drop = FALSE]
  }
  if (nrow(df) == 0L) {
    return(NULL)
  }

  if (isTRUE(adverse_only)) {
    rp_map <- metric_decision_return_periods(method, so)
    max_yrs <- if (!is.null(n_hist_years) && is.finite(n_hist_years)) {
      as.integer(n_hist_years)
    } else {
      max(df$n_obs, na.rm = TRUE)
    }
    if (max_yrs < 50L) {
      rp_map <- rp_map[!names(rp_map) %in% c("Adverse 1-in-50", "Adverse 1 in 50")]
    }
    df <- df[df$rp_name %in% unname(rp_map), , drop = FALSE]
    if (nrow(df) == 0L) {
      return(NULL)
    }

    label_lookup <- names(rp_map)
    names(label_lookup) <- unname(rp_map)
    df$rp_label <- label_lookup[df$rp_name]
    df$rp_label <- gsub("-", " ", df$rp_label)
  }

  # Pivot: one column per RP threshold. Values stay unrounded so rates and
  # indices keep their resolution in the CSV; rounding is display-only
  # (.threshold_col_defs()).
  pivot_cols <- if (has_source) {
    c("scenario", "source", "Estimate", "rp_label", "value")
  } else {
    c("scenario", "Estimate", "rp_label", "value")
  }
  if (!isTRUE(adverse_only)) pivot_cols <- c(pivot_cols, "n_obs")

  wide <- tidyr::pivot_wider(
    df[, pivot_cols],
    names_from  = "rp_label",
    values_from = "value",
    values_fn   = function(x) mean(x, na.rm = TRUE)
  )
  wide <- as.data.frame(wide)

  if (isTRUE(adverse_only)) {
    wide <- dplyr::rename(wide, `Scenario / Period` = scenario)
    if (has_source) wide <- dplyr::rename(wide, Source = source)
    rp_canonical <- c("Expected", "Adverse 1 in 5", "Adverse 1 in 10", "Adverse 1 in 20", "Adverse 1 in 50")
    rp_present <- intersect(rp_canonical, names(wide))
    lead_cols <- if (has_source) {
      c("Scenario / Period", "Source", "Estimate")
    } else {
      c("Scenario / Period", "Estimate")
    }
    wide <- wide[, c(lead_cols, rp_present), drop = FALSE]
    scenario_col <- "Scenario / Period"
  } else {
    wide <- dplyr::rename(wide, Scenario = scenario, Obs = n_obs)
    if (has_source) wide <- dplyr::rename(wide, Source = source)
    canonical <- c(names(RP_LOW), "1:1", names(RP_HIGH))
    rp_present <- intersect(canonical, names(wide))
    lead_cols <- if (has_source) {
      c("Scenario", "Source", "Estimate", "Obs")
    } else {
      c("Scenario", "Estimate", "Obs")
    }
    wide <- wide[, c(lead_cols, rp_present), drop = FALSE]
    scenario_col <- "Scenario"
  }

  # Sort rows: Historical first, then SSPs. Within each scenario the
  # Estimate rows are arranged concentrically around the Central P50:
  #   Pooled low -> Coef low -> Ensemble low -> Central -> Ensemble high
  #   -> Coef high -> Pooled high
  # Lower vs upper side is read from the percentile (< 50 or > 50, or the
  # special "min"/"max" tokens). Family distance from the central row is
  # Pooled = 3 (outermost), Coef = 2, Ensemble = 1.
  .est_rank <- function(est) {
    fam_dist <- ifelse(grepl("^Pooled ", est), 3L,
      ifelse(grepl("^Coef ", est), 2L,
        ifelse(grepl("^Ensemble ", est), 1L, 0L)
      )
    )
    pct <- suppressWarnings(as.integer(sub(".*P", "", est)))
    pct <- ifelse(grepl(" min$", est), 0L,
      ifelse(grepl(" max$", est), 100L, pct)
    )
    pct[is.na(pct)] <- 50L
    side <- ifelse(pct < 50, -1L, ifelse(pct > 50, 1L, 0L))
    side * fam_dist
  }
  wide$.est_order <- .est_rank(wide$Estimate)

  hist_rows <- wide[wide[[scenario_col]] == "Historical", , drop = FALSE]
  ssp_rows <- wide[wide[[scenario_col]] != "Historical", , drop = FALSE]

  if (nrow(hist_rows) > 0) {
    hist_rows <- hist_rows[order(hist_rows$.est_order), , drop = FALSE]
  }

  if (nrow(ssp_rows) > 0) {
    ssp_rows$.ssp_sort <- sub(" /.*", "", ssp_rows[[scenario_col]])
    yr_m <- regexpr("[0-9]{4}-[0-9]{4}", ssp_rows[[scenario_col]])
    ssp_rows$.yr_sort <- ifelse(
      yr_m > 0,
      regmatches(ssp_rows[[scenario_col]], yr_m),
      regmatches(ssp_rows[[scenario_col]], regexpr("[0-9]{4}", ssp_rows[[scenario_col]]))
    )
    src_sort <- if (has_source) {
      match(ssp_rows$Source, c("Baseline", "Policy"))
    } else {
      1L
    }
    ssp_rows$.src_sort <- src_sort
    ssp_rows <- if (isTRUE(group_order == "year_x_scenario")) {
      ssp_rows[order(
        ssp_rows$.yr_sort, ssp_rows$.ssp_sort,
        ssp_rows$.src_sort, ssp_rows$.est_order
      ), , drop = FALSE]
    } else {
      ssp_rows[order(
        ssp_rows$.ssp_sort, ssp_rows$.yr_sort,
        ssp_rows$.src_sort, ssp_rows$.est_order
      ), , drop = FALSE]
    }
    ssp_rows$.ssp_sort <- NULL
    ssp_rows$.yr_sort <- NULL
    ssp_rows$.src_sort <- NULL
  }

  hist_rows$.est_order <- NULL
  ssp_rows$.est_order <- NULL
  rbind(hist_rows, ssp_rows)
}


# Variance-contribution stacked bar ----

model_robustness_data <- function(ts_tbl, band_q = c(lo = 0.10, hi = 0.90)) {
  if (is.null(ts_tbl) || !nrow(ts_tbl) ||
    !all(c("scenario", "model_id", "sim_year", "value") %in% names(ts_tbl))) {
    return(tibble::tibble())
  }
  x <- dplyr::group_by(ts_tbl, .data$scenario, .data$model_id) |>
    dplyr::summarise(
      model_mean = mean(.data$value, na.rm = TRUE),
      n_weather_years = sum(is.finite(.data$value)), .groups = "drop"
    )
  centers <- dplyr::group_by(x, .data$scenario) |>
    dplyr::summarise(
      center = mean(.data$model_mean, na.rm = TRUE),
      ensemble_lo = stats::quantile(.data$model_mean, band_q[[1L]], na.rm = TRUE),
      ensemble_hi = stats::quantile(.data$model_mean, band_q[[2L]], na.rm = TRUE),
      n_models = dplyr::n_distinct(.data$model_id), .groups = "drop"
    )
  dplyr::left_join(x, centers, by = "scenario")
}

# ============================================================================
# Interactive (echarts4r) renderers for simulation comparison summaries.
# Guidelines sec. 7: same statistics computed in R with the same parameters,
# echarts only draws precomputed values; theme tokens come from
# utils_plot_theme.R (wise_eaxis_label / wise_echart_theme, etc.).
# ============================================================================

# Empty widget shell. echarts4r 0.5.x rejects single-column and <2-row frames
# in e_charts(); a two-column two-row dummy is never drawn on. Builders then
# inject their own axes/series into $x$opts (e_axis_*() re-enters e_charts()
# and would hit the same single-column defect).
.e_step2_base <- function(height) {
  e <- echarts4r::e_charts(data.frame(x = 0:1, y = 0:1), x, height = height)
  e$x$opts$xAxis <- NULL
  e$x$opts$yAxis <- NULL
  e$x$opts$series <- NULL
  e$x$opts$legend <- NULL
  e$x$opts$tooltip <- NULL
  e$x$opts$grid <- NULL
  e
}

# Floating band between lo and hi drawn as a stacked pair of bars: a fully
# transparent base bar up to `lo`, then the coloured (hi - lo) segment.
# `cats` are the category-axis labels; `horizontal = TRUE` places the
# category axis on y (ECharts data pairs are always [x, y]). Returns the two
# series; tooltip entries are suppressed because the pair encodes one visual
# band.
.e_band_pair <- function(cats, lo, hi, colour, stack, bar_width,
                         opacity = 1, z = 1, horizontal = FALSE) {
  n <- length(cats)
  pair_data <- function(get_val, style) {
    lapply(seq_len(n), function(i) {
      v <- get_val(i)
      list(
        value = if (horizontal) {
          list(v, cats[[i]])
        } else {
          list(cats[[i]], v)
        },
        itemStyle = style
      )
    })
  }
  transparent <- list(color = "rgba(0,0,0,0)")
  list(
    list(
      name = paste0(stack, "__base"), type = "bar", stack = stack,
      barWidth = bar_width, silent = TRUE, z = z,
      tooltip = list(show = FALSE),
      itemStyle = transparent,
      data = pair_data(
        function(i) if (is.finite(lo[i])) lo[i] else 0,
        transparent
      )
    ),
    list(
      name = paste0(stack, "__band"), type = "bar", stack = stack,
      barWidth = bar_width, silent = TRUE, z = z,
      tooltip = list(show = FALSE),
      data = pair_data(
        function(i) {
          if (is.finite(lo[i]) && is.finite(hi[i])) {
            max(hi[i] - lo[i], 0)
          } else {
            NA_real_
          }
        },
        list(color = colour, opacity = opacity)
      )
    )
  )
}

# Scatter marker series (type "scatter") with per-point value pairs.
# Returns a one-element list so callers can append with c().
.e_dot_series <- function(name, x, y, colour, fill = "white", size = 9,
                          border_width = 1.2, labels = NULL) {
  n <- length(x)
  data <- lapply(seq_len(n), function(i) {
    pt <- list(value = list(x[[i]], y[[i]]))
    if (!is.null(labels) && !is.na(labels[[i]]) && nzchar(labels[[i]])) {
      pt$label <- list(
        show = TRUE,
        position = "right",
        distance = 6,
        fontWeight = "bold",
        color = colour,
        fontSize = 13,
        formatter = labels[[i]]
      )
    }
    pt
  })
  st <- list(
    name = name,
    type = "scatter",
    symbolSize = size,
    z = 3,
    itemStyle = list(
      color = fill,
      borderColor = colour,
      borderWidth = border_width
    ),
    data = data
  )
  list(st)
}

# Line series over numeric (x, y) pairs with optional point labels on the
# last finite point (the endpoint scenario labels the static builders drew
# with geom_text).
.e_line_series <- function(name, x, y, colour, width = 2, type = "solid",
                           opacity = 1, endpoint_label = FALSE,
                           label_x = NULL, area = NULL, stack = NULL,
                           z = 2) {
  n <- length(x)
  last <- which(is.finite(y))
  last <- if (length(last)) max(last) else 0L
  data <- lapply(seq_len(n), function(i) {
    pt <- list(value = list(x[[i]], y[[i]]))
    if (endpoint_label && i == last && is.finite(y[[i]])) {
      pt$label <- list(
        show = TRUE,
        position = "right",
        distance = 6,
        fontWeight = "bold",
        color = colour,
        fontSize = 13,
        formatter = name
      )
    }
    pt
  })
  st <- list(
    name = name,
    type = "line",
    lineStyle = list(color = colour, width = width, type = type,
                     opacity = opacity),
    itemStyle = list(color = colour),
    symbol = "none",
    z = z,
    data = data
  )
  if (!is.null(area)) st$areaStyle <- area
  if (!is.null(stack)) st$stack <- stack
  list(st)
}

# A filled uncertainty ribbon represented by one closed line polygon. ECharts'
# stacked lower/upper area series can render the upper segment from zero when
# the lower series has a transparent area, so an explicit polygon is safer for
# browser and export renderers.
.e_line_band <- function(name, x, lower, upper, colour, opacity = 0.2,
                         lower_type = "solid", z = 1) {
  ok <- is.finite(x) & is.finite(lower) & is.finite(upper)
  if (!any(ok)) return(list())
  x <- x[ok]
  lower <- lower[ok]
  upper <- pmax(upper[ok], lower)
  polygon <- rbind(
    cbind(x, lower),
    cbind(rev(x), rev(upper))
  )

  list(
    list(
      name = name,
      type = "line",
      symbol = "none",
      silent = TRUE,
      legendHoverLink = FALSE,
      tooltip = list(show = FALSE),
      lineStyle = list(
        color = "rgba(0,0,0,0)",
        width = 0,
        type = lower_type,
        opacity = 0
      ),
      areaStyle = list(color = colour, opacity = opacity),
      z = z,
      data = unname(polygon)
    )
  )
}

# Deterministic even-stride downsample for raw series above `cap` points
# (guidelines sec. 7). Aggregated series are never downsampled.
.e_downsample_idx <- function(n, cap = 10000L) {
  if (n <= cap) {
    return(seq_len(n))
  }
  # Even stride keeps the first and last point and spreads the rest evenly,
  # so the shape of the series is preserved without randomisation.
  sort(unique(as.integer(floor(seq(1L, n, length.out = cap)))))
}

# ---- echart_pointrange_climate ----------------------------------------------

#' Interactive pointrange (Step 2 Results point-range chart)
#'
#' echarts renderer for the Step 2 Results surface. Reuses the data
#' preparation in [.pointrange_prep()].
#' Nested bands are drawn as floating bar pairs (transparent base + coloured
#' segment) and the central estimate as an open scatter marker, matching the
#' Static linerange widths: ensemble 6pt -> barWidth 14, annual 3.5pt -> 8,
#' coefficient 1.2pt -> 3.
#'
#' This builder draws the single-source Step 2 chart and co-locates categories
#' when a `source` column is present.
#'
#' @return An `echarts4r` widget (never NULL; empty states return
#'   [echart_blank()] with the corresponding empty-state message).
#' @noRd
echart_pointrange_climate <- function(bands_tbl,
                                      x_label = "",
                                      group_order = "scenario_x_year",
                                      show_coef = TRUE,
                                      show_annual = FALSE,
                                      height = "600px") {
  if (is.null(bands_tbl) || nrow(bands_tbl) == 0L) {
    return(echart_blank("Run a simulation to see results.", height = height))
  }
  prep <- .pointrange_prep(bands_tbl, group_order)
  df <- prep$df
  if (nrow(df) == 0L) {
    return(echart_blank(
      "Run a future simulation to see scenario comparisons.",
      height = height
    ))
  }
  palette <- prep$palette
  ordered_levels <- prep$ordered_levels

  e <- .e_step2_base(height)
  series <- list()
  for (i in seq_len(nrow(df))) {
    r <- df[i, , drop = FALSE]
    col <- unname(palette[[r$colour_key]] %||% "#808080")
    # Unique stack per row: ECharts offsets different stacks within one
    # category, so co-located rows (source-dodged data) read side by side.
    st <- paste0("b", i)
    if (is.finite(r$intermod_lo) && is.finite(r$intermod_hi)) {
      series <- c(series, .e_band_pair(
        ordered_levels, r$intermod_lo, r$intermod_hi, col,
        stack = paste0("im_", st), bar_width = 14, opacity = 0.6, z = 1
      ))
    }
    if (isTRUE(show_annual) && is.finite(r$interann_lo) &&
      is.finite(r$interann_hi)) {
      series <- c(series, .e_band_pair(
        ordered_levels, r$interann_lo, r$interann_hi, col,
        stack = paste0("ia_", st), bar_width = 8, opacity = 1, z = 1
      ))
    }
    if (isTRUE(show_coef) && is.finite(r$coef_lo) && is.finite(r$coef_hi)) {
      series <- c(series, .e_band_pair(
        ordered_levels, r$coef_lo, r$coef_hi, .wise_support,
        stack = paste0("cf_", st), bar_width = 3, opacity = 1, z = 2
      ))
    }
    series <- c(series, .e_dot_series(
      as.character(r$colour_key),
      as.character(r$pt_key), r$value,
      colour = .wise_support, fill = "white", size = 11,
      border_width = 1.2
    ))
  }

  e$x$opts$xAxis <- list(
    type = "category",
    data = as.list(ordered_levels),
    axisLabel = wise_eaxis_label(interval = 0L, formatter = htmlwidgets::JS(
      "function(v){ return v === undefined ? '' : v; }"
    )),
    axisLine = list(lineStyle = list(color = .wise_grid)),
    axisTick = list(alignWithLabel = TRUE),
    splitLine = wise_esplit_line(show = FALSE)
  )
  e$x$opts$yAxis <- list(
    type = "value",
    name = x_label,
    nameLocation = "middle",
    nameGap = 48,
    nameRotate = 90,
    nameTextStyle = wise_eaxis_name(),
    axisLabel = wise_eaxis_label(),
    splitLine = wise_esplit_line()
  )
  e$x$opts$series <- series
  e$x$opts$tooltip <- list(
    trigger = "axis",
    axisPointer = list(type = "shadow")
  )
  e$x$opts$grid <- list(containLabel = TRUE, left = 8, right = 14, top = 16, bottom = 8)
  wise_echart_theme(e)
}

# ---- echart_variance_contribution -------------------------------------------

#' Interactive uncertainty-source bars
#'
#' echarts version of the variance contribution chart: one horizontal bar
#' per (scenario, source) on the same sqrt-of-variance statistics, Okabe-Ito
#' source colours, legend bottom (the static chart showed one).
#' @noRd
echart_variance_contribution <- function(var_tbl, height = "300px", percent = FALSE, reference = "none") {
  if (is.null(var_tbl) || nrow(var_tbl) == 0L) {
    return(echart_blank("Run a simulation to see SD contributions.", height = height))
  }
  df <- var_tbl
  df$sd_coef <- sqrt(pmax(df$var_coef, 0))
  df$sd_within <- sqrt(pmax(df$var_within, 0))
  df$sd_across <- sqrt(pmax(df$var_across, 0))

  # The coefficient bar follows the Results reference: a level, or a contrast
  # with the historical mean or median. Residual draws get their own bar when
  # the run has any (the "resample" rule); the year spread contains their
  # year-to-year noise as well.
  coef_label <- switch(reference %||% "none",
    mean = "Coefficient uncertainty (difference from historical mean)",
    median = "Coefficient uncertainty (difference from historical median)",
    "Coefficient uncertainty (level)"
  )
  has_resid <- "var_resid" %in% names(df) && any(df$var_resid > 0, na.rm = TRUE)
  df$sd_resid <- if ("var_resid" %in% names(df)) sqrt(pmax(df$var_resid, 0)) else 0
  src_levels <- c(
    "Inter-model spread", "Inter-annual variability", coef_label,
    if (has_resid) "Residual draws"
  )
  src_cols <- c(.wise_cat[[3]], .wise_cat[[2]], .wise_cat[[1]], if (has_resid) .wise_cat[[4]])
  # Horizontal rows: scenarios top-down in first-appearance order (static plot
  # coord_flip with levels rev(unique(df$scenario)) puts Historical on top).
  cats <- rev(unique(as.character(df$scenario)))
  cat_idx <- setNames(seq_along(cats) - 1L, cats)

  e <- .e_step2_base(height)
  sd_cols <- c("sd_across", "sd_within", "sd_coef", if (has_resid) "sd_resid")
  series <- lapply(seq_along(src_levels), function(i) {
    vals <- vapply(cats, function(sc) {
      v <- df[[sd_cols[[i]]]][df$scenario == sc]
      if (length(v)) v[[1L]] else NA_real_
    }, numeric(1))
    list(
      name = src_levels[[i]],
      type = "bar",
      barGap = "15%",
      barMaxWidth = 22,
      data = lapply(seq_along(cats), function(j) {
        list(value = list(vals[[j]], cat_idx[[j]]))
      }),
      itemStyle = list(color = unname(src_cols[[i]]))
    )
  })

  e$x$opts$xAxis <- list(
    type = "value",
    name = if (percent) "Standard deviation (percentage points)" else "Standard deviation (outcome units)",
    nameLocation = "middle",
    nameGap = 30,
    nameMoveOverlap = FALSE,
    nameTextStyle = wise_eaxis_name(),
    axisLabel = .wise_result_axis_label(if (percent) "(percent)" else ""),
    splitLine = wise_esplit_line(),
    axisLine = list(lineStyle = list(color = .wise_grid))
  )
  e$x$opts$yAxis <- list(
    type = "category",
    # as.list(): a single category must stay a JSON array (auto_unbox would
    # emit a string, which ECharts splits into one category per character).
    data = as.list(cats),
    axisLabel = wise_eaxis_label(),
    axisLine = list(lineStyle = list(color = .wise_grid)),
    axisTick = list(show = FALSE),
    splitLine = wise_esplit_line(show = FALSE)
  )
  e$x$opts$series <- series
  e$x$opts$legend <- modifyList(
    list(bottom = 0, left = 0, orient = "horizontal"),
    wise_elegend_style()
  )
  e$x$opts$tooltip <- list(
    trigger = "axis", confine = TRUE, axisPointer = list(type = "shadow"),
    formatter = htmlwidgets::JS(sprintf("function(ps) {
      function esc(s) { return String(s).replace(/[&<>\"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[c]; }); }
      if (!ps.length) return '';
      var percent = %s;
      return esc(ps[0].axisValueLabel) + '<br>' + ps.map(function(p) {
        var v = Array.isArray(p.value) ? p.value[0] : p.value;
        return p.marker + esc(p.seriesName) + ': <b>' +
          (Number.isFinite(v) ? (percent ? v*100 : v).toLocaleString('en-US', {maximumFractionDigits: 3}) + (percent ? ' pp' : '') : 'Not available') + '</b>';
      }).join('<br>');
    }", tolower(as.character(percent))))
  )
  e$x$opts$grid <- list(containLabel = TRUE, left = 8, right = 24, top = 24, bottom = 88)
  e$x$opts$color <- unname(src_cols)
  wise_echart_theme(e)
}

# ---- echart_step2_adverse_dot -----------------------------------------------

#' Interactive adverse return-period dot plot
#'
#' echarts renderer for Step 2 adverse return periods: per scenario, the
#' ensemble spread as a floating bar pair and the central estimate as an open
#' marker, scenario labels anchored right of the top-row (Expected) markers
#' exactly like the archived static direct labels. No legend.
#'
#' `pending` lists scenario labels still computing (progressive Step 2
#' results). Their dodge slots are reserved, so landed points keep their
#' position as more scenarios arrive, and each gets a muted "(computing)"
#' label on the top row. Empty (default) leaves the output unchanged.
#' @noRd
echart_step2_adverse_dot <- function(tbl, x_label = "Outcome level",
                                     height = "380px",
                                     pending = character(0)) {
  if (is.null(tbl) || !nrow(tbl)) {
    return(echart_blank("Return-period outcomes are unavailable.", height = height))
  }
  present <- sort(unique(as.character(tbl$scenario[!tbl$is_historical])))
  pending <- setdiff(as.character(pending), c(present, "Historical"))
  scenario_levels <- c("Historical", sort(unique(c(present, pending))))
  scenario_colours <- stats::setNames(vapply(scenario_levels, function(s) {
    if (identical(s, "Historical")) {
      return(.wise_support)
    }
    ssp <- .normalise_ssp(s)
    if (ssp %in% names(.ssp_colours)) unname(.ssp_colours[[ssp]]) else .wise_slate
  }, character(1L)), scenario_levels)
  tbl$scenario_key <- ifelse(tbl$is_historical, "Historical", as.character(tbl$scenario))
  tbl$rp_y <- as.integer(tbl$rp_label)
  # Vertical dodge as in the static builder: scenarios sharing a return-period
  # row get distinct slots so their dumbbells stay readable.
  dodge_width <- 0.6
  tbl$dodge_offset <- stats::ave(
    seq_len(nrow(tbl)),
    tbl$rp_y,
    FUN = function(idx) {
      if (length(pending)) {
        # Fixed slots over the full scenario list (landed + pending).
        k_all <- length(scenario_levels)
        slot <- match(tbl$scenario_key[idx], scenario_levels)
        return((slot - 1L - (k_all - 1L) / 2) * (dodge_width / max(k_all - 1L, 1)))
      }
      k <- length(idx)
      if (k <= 1L) {
        return(0)
      }
      seq(-(k - 1L) / 2, (k - 1L) / 2, length.out = k)[
        order(match(tbl$scenario_key[idx], scenario_levels))
      ] * (dodge_width / max(k - 1L, 1))
    }
  )

  y_breaks <- sort(unique(tbl$rp_y))
  y_labels <- levels(tbl$rp_label)[y_breaks]

  top_y <- max(tbl$rp_y)
  top_keys <- unique(tbl$scenario_key[tbl$rp_y == top_y])

  e <- .e_step2_base(height)
  series <- list()
  for (scn in scenario_levels) {
    rows <- tbl[tbl$scenario_key == scn, , drop = FALSE]
    if (!nrow(rows)) next
    col <- unname(scenario_colours[[scn]])
    y_pos <- rows$rp_y + rows$dodge_offset
    # Match each spread interval to its scenario's vertically-dodged marker.
    for (j in seq_len(nrow(rows))) {
      if (is.finite(rows$intermod_lo[[j]]) && is.finite(rows$intermod_hi[[j]])) {
        series <- c(series, list(list(
          name = paste0("rp_", scn, "_", j, "__spread"),
          type = "line",
          data = unname(rbind(
            c(rows$intermod_lo[[j]], y_pos[[j]]),
            c(rows$intermod_hi[[j]], y_pos[[j]])
          )),
          symbol = "none",
          silent = TRUE,
          tooltip = list(show = FALSE),
          lineStyle = list(color = col, width = 3, opacity = 0.4, cap = "round"),
          z = 1
        )))
      }
    }
    labs <- rep(NA_character_, nrow(rows))
    lab_rows <- rows$rp_y == top_y & rows$scenario_key %in% top_keys
    # One label per scenario, on its first Expected-row marker.
    if (any(lab_rows)) {
      labs[[which(lab_rows)[[1L]]]] <- scn
    }
    dots <- .e_dot_series(
      scn, rows$value, y_pos,
      colour = col, fill = col, size = 8, border_width = 1.1,
      labels = labs
    )[[1L]]
    dots$data <- lapply(seq_len(nrow(rows)), function(i) {
      modifyList(dots$data[[i]], list(
        scenario = scn, rp_label = as.character(rows$rp_label[[i]]),
        outcome = rows$value[[i]], lo = rows$intermod_lo[[i]], hi = rows$intermod_hi[[i]]
      ))
    })
    series <- c(series, list(dots))
  }

  x_vals <- c(tbl$value, tbl$intermod_lo, tbl$intermod_hi)
  x_vals <- x_vals[is.finite(x_vals)]
  if (!length(x_vals)) {
    return(echart_blank("No finite adverse-year outcomes available.", height = height))
  }
  # Pending scenarios: label-only points on the top row, in their own slot.
  k_all <- length(scenario_levels)
  for (scn in pending) {
    slot <- match(scn, scenario_levels)
    off <- (slot - 1L - (k_all - 1L) / 2) * (dodge_width / max(k_all - 1L, 1))
    series <- c(series, list(list(
      name = paste0(scn, " (computing)"),
      type = "scatter",
      data = list(list(
        value = c(stats::median(x_vals), top_y + off),
        label = list(
          show = TRUE, formatter = paste0(scn, " (computing)"),
          position = "right", color = "#9aa9b5", fontStyle = "italic"
        )
      )),
      symbolSize = 0,
      silent = TRUE,
      tooltip = list(show = FALSE),
      z = 1
    )))
  }
  x_span <- diff(range(x_vals))
  if (!is.finite(x_span) || x_span <= 0) x_span <- max(abs(x_vals), 1) * 0.1
  e$x$opts$xAxis <- list(
    type = "value",
    min = min(x_vals) - 0.02 * x_span,
    max = max(x_vals) + 0.12 * x_span,
    name = x_label,
    nameLocation = "middle",
    nameGap = 30,
    nameTextStyle = wise_eaxis_name(),
    axisLabel = .wise_result_axis_label(x_label),
    splitLine = wise_esplit_line(),
    axisLine = list(lineStyle = list(color = .wise_grid))
  )
  y_label_map <- stats::setNames(as.list(y_labels), as.character(y_breaks))
  names(y_label_map) <- as.character(y_breaks)
  e$x$opts$yAxis <- list(
    type = "value",
    min = 0,
    max = max(y_breaks) + 1,
    interval = 1,
    axisLabel = wise_eaxis_label(
      showMinLabel = FALSE,
      showMaxLabel = FALSE,
      formatter = htmlwidgets::JS(sprintf(
        "function(v){ var m = %s; return m[String(Math.round(v))] || ''; }",
        jsonlite::toJSON(y_label_map, auto_unbox = TRUE)
      ))
    ),
    axisLine = list(lineStyle = list(color = .wise_grid)),
    axisTick = list(show = FALSE),
    splitLine = wise_esplit_line(show = FALSE)
  )
  e$x$opts$series <- series
  e$x$opts$tooltip <- list(trigger = "item", confine = TRUE, formatter = .wise_result_tooltip(x_label))
  e$x$opts$grid <- list(containLabel = TRUE, left = 8, right = 90, top = 12, bottom = 58)
  wise_echart_theme(e)
}

# ---- echart_annual_distribution ---------------------------------------------

#' Interactive annual outcome distribution
#'
#' Step 2 renderer. Delegates to the shared Step 3 ECharts builder so both
#' steps use the same annual distribution
#' geometry, labels, and interaction.
#' @noRd
echart_annual_distribution <- function(tbl, x_label = "Outcome (outcome units)",
                                       plot_type = "violin",
                                       height = "470px",
                                       pending = character(0)) {
  if (is.null(tbl) || !nrow(tbl)) {
    return(echart_blank("No annual simulation results available.", height = height))
  }
  echart_step3_annual_distribution(
    tbl, x_label = x_label, plot_type = plot_type, height = height,
    pending = pending
  )
}

# ---- echart_timeseries_spaghetti --------------------------------------------

#' Interactive per-model trajectories with ensemble envelope
#'
#' Envelope statistics are the per (scenario, sim_year) equal-weight mean and quantiles
#' at `ensemble_band_q`. Draws one thin translucent line per model, one bold mean
#' line per scenario/source, and a custom polygon for the inter-model ribbon.
#' @noRd
echart_timeseries_spaghetti <- function(ts_tbl, x_label = "",
                                        ensemble_band_q = c(lo = 0, hi = 1),
                                        height = "380px") {
  if (is.null(ts_tbl) || nrow(ts_tbl) == 0L) {
    return(echart_blank("Run a simulation to see model trajectories.", height = height))
  }
  df <- ts_tbl
  has_source <- "source" %in% names(df)
  required <- c("scenario", "model_id", "sim_year", "value", "is_historical")
  if (!all(required %in% names(df))) {
    return(echart_blank("No model trajectories available.", height = height))
  }
  if (has_source) {
    df <- df[!(df$is_historical %in% TRUE & df$source == "Policy"), , drop = FALSE]
  }
  df$scenario <- as.character(df$scenario)
  df$model_id <- as.character(df$model_id)
  df$is_historical <- df$is_historical %in% TRUE
  df$sim_year <- suppressWarnings(as.numeric(as.character(df$sim_year)))
  df$value <- suppressWarnings(as.numeric(as.character(df$value)))
  keep <- !is.na(df$scenario) & nzchar(df$scenario) &
    !is.na(df$model_id) & nzchar(df$model_id) &
    is.finite(df$sim_year) & is.finite(df$value)
  if (has_source) {
    df$source <- as.character(df$source)
    keep <- keep & !is.na(df$source) & nzchar(df$source)
  }
  df <- df[keep, , drop = FALSE]
  if (!nrow(df)) {
    return(echart_blank("No finite model trajectories available.", height = height))
  }

  scen_levels <- c("Historical", sort(unique(df$scenario[!df$is_historical])))
  scen_levels <- scen_levels[scen_levels %in% df$scenario]
  scen_colour_map <- vapply(scen_levels, function(s) {
    if (s == "Historical") {
      return(.wise_support)
    }
    ssp <- .normalise_ssp(s)
    if (ssp %in% names(.ssp_colours)) unname(.ssp_colours[[ssp]]) else "grey50"
  }, character(1L))

  env_grp <- c("scenario", if (has_source) "source", "sim_year")
  env_df <- df |>
    dplyr::group_by(dplyr::across(dplyr::all_of(env_grp))) |>
    dplyr::summarise(
      central = mean(.data$value, na.rm = TRUE),
      lo = unname(stats::quantile(.data$value, ensemble_band_q[["lo"]], na.rm = TRUE)),
      hi = unname(stats::quantile(.data$value, ensemble_band_q[["hi"]], na.rm = TRUE)),
      n_models = dplyr::n(),
      is_historical = any(.data$is_historical),
      .groups = "drop"
    )
  fut_env <- env_df[!env_df$is_historical & env_df$n_models > 1L, , drop = FALSE]

  e <- .e_step2_base(height)
  series <- list()
  legend_names <- character(0)

  # Inter-model envelope (futures only, when >1 model): explicit data-space
  # polygon, so neither the lower edge nor the fill is anchored at zero.
  env_groups <- unique(fut_env[intersect(c("scenario", "source"), names(fut_env))])
  for (i in seq_len(nrow(env_groups))) {
    group <- env_groups[i, , drop = FALSE]
    scn <- as.character(group$scenario[[1L]])
    env <- fut_env[as.character(fut_env$scenario) == scn, , drop = FALSE]
    if (has_source) env <- env[as.character(env$source) == as.character(group$source[[1L]]), , drop = FALSE]
    env <- env[order(env$sim_year), , drop = FALSE]
    col <- unname(scen_colour_map[[scn]] %||% "grey50")
    band_name <- paste(c(scn, if (has_source) as.character(group$source[[1L]]), "envelope"), collapse = " / ")
    points <- unname(rbind(cbind(env$sim_year, env$lo),
      cbind(rev(env$sim_year), rev(env$hi))))
    series <- c(series, list(list(
      name = band_name,
      type = "custom",
      renderItem = htmlwidgets::JS(sprintf(
        "function(params, api) { var pts = %s; return {type: 'polygon', shape: {points: pts.map(function(p){return api.coord(p);})}, style: {fill: '%s', opacity: 0.16, stroke: 'none'}}; }",
        jsonlite::toJSON(points, digits = NA), col
      )),
      data = list(list(min(env$sim_year), min(env$lo), max(env$sim_year), max(env$hi))),
      encode = list(x = c(0, 2), y = c(1, 3)),
      itemStyle = list(color = col),
      silent = TRUE,
      tooltip = list(show = FALSE),
      legendHoverLink = FALSE,
      z = 1
    )))
  }

  # Spaghetti: one thin translucent line per (scenario, model).
  spaghetti_grp <- c("scenario", if (has_source) "source", "model_id")
  model_groups <- unique(df[spaghetti_grp])
  for (i in seq_len(nrow(model_groups))) {
    group <- model_groups[i, , drop = FALSE]
    scn <- as.character(group$scenario[[1L]])
    rows <- df[as.character(df$scenario) == scn & df$model_id == as.character(group$model_id[[1L]]), , drop = FALSE]
    if (has_source) rows <- rows[as.character(rows$source) == as.character(group$source[[1L]]), , drop = FALSE]
    rows <- rows[order(rows$sim_year), , drop = FALSE]
    # Guard: raw model lines above 10k points are deterministically
    # downsampled (even stride); aggregated envelopes stay exact.
    idx <- .e_downsample_idx(nrow(rows))
    xs <- as.numeric(rows$sim_year)[idx]
    ys <- as.numeric(rows$value)[idx]
    col <- unname(scen_colour_map[[scn]] %||% "grey50")
    member_col <- intersect(c("member_id", "member"), names(rows))
    model_name <- as.character(group$model_id[[1L]])
    source_name <- if (has_source) as.character(group$source[[1L]]) else NULL
    raw_name <- paste(c(scn, source_name, model_name), collapse = " / ")
    raw <- list(
      name = raw_name, type = "line", symbol = "none", showSymbol = FALSE, z = 2,
      lineStyle = list(color = col, width = 1, opacity = 0.35),
      itemStyle = list(color = col),
      data = lapply(seq_along(xs), function(j) {
        row_idx <- idx[[j]]
        point <- list(
          value = list(xs[[j]], ys[[j]]),
          scenario = scn,
          source = source_name,
          model = model_name,
          kind = "model"
        )
        if (length(member_col) && !is.na(rows[[member_col[[1L]]]][[row_idx]])) {
          point$member <- as.character(rows[[member_col[[1L]]]][[row_idx]])
        }
        point
      })
    )
    series <- c(series, list(raw))
  }

  # Bold across-model mean per scenario/source (legend entry).
  median_groups <- unique(env_df[intersect(c("scenario", "source"), names(env_df))])
  for (i in seq_len(nrow(median_groups))) {
    group <- median_groups[i, , drop = FALSE]
    scn <- as.character(group$scenario[[1L]])
    env <- env_df[as.character(env_df$scenario) == scn, , drop = FALSE]
    if (has_source) env <- env[as.character(env$source) == as.character(group$source[[1L]]), , drop = FALSE]
    if (!nrow(env)) next
    env <- env[order(env$sim_year), , drop = FALSE]
    label <- paste(c(scn, if (has_source) as.character(group$source[[1L]])), collapse = " / ")
    line <- .e_line_series(
      label, as.numeric(env$sim_year), env$central,
      colour = unname(scen_colour_map[[scn]] %||% "grey50"),
      width = 3, opacity = 1
    )[[1L]]
    line$data <- lapply(seq_len(nrow(env)), function(j) {
      list(
        value = list(as.numeric(env$sim_year[[j]]), as.numeric(env$central[[j]])),
        scenario = scn,
        source = if (has_source) as.character(group$source[[1L]]) else NULL,
        model = "Across-model mean",
        kind = "median"
      )
    })
    line$z <- 4
    series <- c(series, list(line))
    legend_names <- c(legend_names, label)
  }

  y_vals <- c(df$value, env_df$lo, env_df$hi, env_df$central)
  y_vals <- y_vals[is.finite(y_vals)]
  if (!length(y_vals)) {
    return(echart_blank("No finite model trajectories available.", height = height))
  }
  x_vals <- df$sim_year[is.finite(df$sim_year)]
  x_span <- diff(range(x_vals))
  x_pad <- if (x_span > 0) x_span * 0.005 else max(abs(x_vals[[1L]]) * 0.005, 0.01)
  y_span <- diff(range(y_vals))
  y_pad <- if (y_span > 0) y_span * 0.04 else max(abs(y_vals[[1L]]) * 0.04, 0.01)
  percent <- nzchar(.wise_result_rate_unit(x_label))
  e$x$opts$xAxis <- list(
    type = "value",
    min = min(x_vals) - x_pad,
    max = max(x_vals) + x_pad,
    name = "Historical weather-year draw (simulated)",
    nameLocation = "middle",
    nameGap = 30,
    nameMoveOverlap = FALSE,
    nameTextStyle = wise_eaxis_name(),
    axisLabel = wise_eaxis_label(formatter = htmlwidgets::JS(
      "function(v){ return String(Math.round(v)); }"
    )),
    splitLine = wise_esplit_line(),
    axisLine = list(lineStyle = list(color = .wise_grid))
  )
  e$x$opts$yAxis <- list(
    type = "value",
    min = min(y_vals) - y_pad,
    max = max(y_vals) + y_pad,
    name = x_label,
    nameLocation = "end",
    nameGap = 20,
    nameRotate = 0,
    nameMoveOverlap = FALSE,
    nameTextStyle = wise_eaxis_name(align = "left"),
    axisLabel = .wise_result_axis_label(x_label),
    splitLine = wise_esplit_line()
  )
  e$x$opts$series <- series
  e$x$opts$legend <- modifyList(
    list(top = 4, left = "center", orient = "horizontal", data = as.list(legend_names)),
    wise_elegend_style()
  )
  e$x$opts$tooltip <- list(
    trigger = "axis", confine = TRUE,
    axisPointer = list(type = "line", snap = TRUE),
    formatter = htmlwidgets::JS(sprintf("function(ps) {
      function esc(s) { return String(s == null ? '' : s).replace(/[&<>\"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[c]; }); }
      var percent = %s;
      function num(v) { return Number.isFinite(v) ? (percent ? v*100 : v).toLocaleString('en-US', {maximumFractionDigits: percent ? 1 : 3}) + %s : 'Not available'; }
      var groups = {}, order = [];
      ps.forEach(function(p) {
        var d = p.data || {}; if (d.kind !== 'model') return;
        var label = d.scenario + (d.source ? ' / ' + d.source : '');
        if (!groups[label]) { groups[label] = {values:[], marker:p.marker}; order.push(label); }
        var v = p.value[1]; if (Number.isFinite(v)) groups[label].values.push(v);
      });
      var out = order.map(function(label) {
        var g = groups[label], v = g.values.sort(function(a,b){return a-b;}), n = v.length;
        if (!n) return '';
        var median = n%%2 ? v[(n-1)/2] : (v[n/2-1]+v[n/2])/2;
        return g.marker + '<b>' + esc(label) + '</b>: ' + (n === 1 ? num(v[0]) :
          'Min ' + num(v[0]) + ' / Median ' + num(median) + ' / Max ' + num(v[n-1]));
      });
      if (!out.length) return '';
      return '<b>Weather year ' + String(Math.round(ps[0].value[0])) + '</b><br>' + out.join('<br>');
    }", tolower(as.character(percent)),
      jsonlite::toJSON(.wise_result_rate_unit(x_label), auto_unbox = TRUE))
  ))
  e$x$opts$grid <- list(containLabel = TRUE, left = 8, right = 20, top = 86, bottom = 54)
  wise_echart_theme(e)
}

# ---- echart_model_robustness -------------------------------------------------

#' Interactive climate-model robustness scatter
#'
#' Climate-model robustness chart: one point per climate
#' model's mean across weather-year draws in its scenario colour, plus the
#' orange ensemble-median marker per scenario. Item tooltip.
#' @noRd
echart_model_robustness <- function(tbl, x_label = "Expected annual outcome",
                                    height = "420px") {
  if (is.null(tbl) || !nrow(tbl)) {
    return(echart_blank("Climate-model robustness is unavailable.", height = height))
  }
  cats <- unique(as.character(tbl$scenario))
  cat_idx <- setNames(as.character(seq_along(cats) - 1L), cats)
  colours <- stats::setNames(vapply(cats, function(s) {
    if (identical(s, "Historical")) return(.wise_history)
    ssp <- .normalise_ssp(s)
    if (ssp %in% names(.ssp_colours)) unname(.ssp_colours[[ssp]]) else .wise_slate
  }, character(1)), cats)

  e <- .e_step2_base(height)
  means <- list(
    name = "Model means",
    type = "scatter",
    symbolSize = 9,
    z = 2,
    itemStyle = list(color = .wise_support, opacity = 0.7),
    data = lapply(seq_len(nrow(tbl)), function(i) {
      list(
        value = list(tbl$model_mean[[i]], cat_idx[[as.character(tbl$scenario)[[i]]]]),
        scenario = as.character(tbl$scenario[[i]]),
        model = if ("model_id" %in% names(tbl)) as.character(tbl$model_id[[i]]) else NULL,
        n_years = if ("n_weather_years" %in% names(tbl)) tbl$n_weather_years[[i]] else NULL,
        itemStyle = list(color = unname(colours[[as.character(tbl$scenario[[i]])]]), opacity = .65)
      )
    })
  )
  centers <- unique(tbl[c("scenario", "center")])
  centers <- list(
    name = "Ensemble median",
    type = "scatter",
    symbolSize = 13,
    z = 3,
    itemStyle = list(color = .wise_policy, borderColor = .wise_policy_dark, borderWidth = 1.2),
    data = lapply(seq_len(nrow(centers)), function(i) {
      list(value = list(centers$center[[i]], cat_idx[[as.character(centers$scenario)[[i]]]]),
        scenario = as.character(centers$scenario[[i]]))
    })
  )
  e$x$opts$xAxis <- list(
    type = "value",
    scale = TRUE,
    name = x_label,
    nameLocation = "middle",
    nameGap = 30,
    nameMoveOverlap = FALSE,
    nameTextStyle = wise_eaxis_name(),
    axisLabel = .wise_result_axis_label(x_label),
    splitLine = wise_esplit_line(),
    axisLine = list(lineStyle = list(color = .wise_grid))
  )
  e$x$opts$yAxis <- list(
    type = "category",
    data = as.list(as.character(seq_along(cats) - 1L)),
    axisLabel = wise_eaxis_label(
      interval = 0L,
      formatter = htmlwidgets::JS(sprintf(
        "function(v){ var m = %s; return m[v] === undefined ? '' : m[v]; }",
        jsonlite::toJSON(as.list(stats::setNames(
          as.list(sub(" / ", "\n", cats, fixed = TRUE)),
          as.character(seq_along(cats) - 1L)
        )), auto_unbox = TRUE)
      ))
    ),
    axisLine = list(lineStyle = list(color = .wise_grid)),
    axisTick = list(show = FALSE),
    splitLine = wise_esplit_line(show = FALSE)
  )
  e$x$opts$series <- list(means, centers)
  e$x$opts$tooltip <- list(trigger = "item", confine = TRUE,
    formatter = htmlwidgets::JS(sprintf("function(p) {
      var d = p.data || {};
      function esc(s) { return String(s).replace(/[&<>\"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[c]; }); }
      var percent = %s, v = p.value[0];
      var label = d.model ? 'Model mean' : 'Ensemble median';
      var text = '<b>' + esc(d.scenario) + '</b>';
      if (d.model) text += '<br>Model/member: ' + esc(d.model);
      text += '<br>' + label + ': <b>' + (Number.isFinite(v) ?
        (percent ? v*100 : v).toLocaleString('en-US', {maximumFractionDigits: percent ? 1 : 3}) + %s : 'Not available') + '</b>';
      if (Number.isFinite(d.n_years)) text += '<br>Weather years: ' + d.n_years;
      return text;
    }", tolower(as.character(nzchar(.wise_result_rate_unit(x_label)))),
      jsonlite::toJSON(.wise_result_rate_unit(x_label), auto_unbox = TRUE))))
  e$x$opts$grid <- list(containLabel = TRUE, left = 8, right = 24, top = 24, bottom = 62)
  wise_echart_theme(e)
}

# ---- echart_exceedance -------------------------------------------------------

#' Interactive exceedance probability curve
#'
#' echarts renderer for exceedance probability. Same per-(scenario, rank)
#' statistics: across-model median curve, inter-model quantile band and
#' coefficient band (both reduced to their two boundary curves - see the
#' judgment note below), endpoint scenario labels.
#'
#' Orientation: the static builder drew outcome on x and probability on y
#' under coord_flip(); the echarts widget keeps that reading (outcome on the
#' value axis) with the probability axis horizontal.
#'
#' Judgment calls, documented for review:
#' - Uncertainty ribbons are explicit closed polygons rather than stacked-area
#'   bands. ECharts can anchor a transparent lower stack segment at zero, which
#'   produces an incorrect ribbon on the log probability axis.
#' - logit_x has no echarts counterpart: the probability axis uses log10
#'   with the same supported return-period tick labels (percent-formatted).
#'   Custom label and tick positions use ECharts >= 5.5.1.
#' @noRd
echart_exceedance <- function(curves_tbl,
                              x_label,
                              n_sim_years = NULL,
                              logit_x = FALSE,
                              band_q = c(lo = 0.10, hi = 0.90),
                              ensemble_band_q = c(lo = 0, hi = 1),
                              height = "400px") {
  if (is.null(curves_tbl) || nrow(curves_tbl) == 0L) {
    return(echart_blank("Run a simulation to see exceedance probabilities.", height = height))
  }

  has_source <- "source" %in% names(curves_tbl)
  if (has_source) {
    curves_tbl <- curves_tbl[!(curves_tbl$is_historical &
      curves_tbl$source == "Policy"), , drop = FALSE]
    grp_cols <- c("scenario", "source", "rank")
  } else {
    grp_cols <- c("scenario", "rank")
  }

  agg_df <- curves_tbl |>
    dplyr::group_by(dplyr::across(dplyr::all_of(grp_cols))) |>
    dplyr::summarise(
      exceed_prob = dplyr::first(.data$exceed_prob),
      central = mean(.data$welfare_val, na.rm = TRUE),
      intermod_lo = unname(stats::quantile(.data$welfare_val,
        ensemble_band_q[["lo"]], na.rm = TRUE
      )),
      intermod_hi = unname(stats::quantile(.data$welfare_val,
        ensemble_band_q[["hi"]], na.rm = TRUE
      )),
      n_models = dplyr::n(),
      is_historical = any(.data$is_historical),
      .groups = "drop"
    )

  if (!is.null(band_q)) {
    sd_grp <- if (has_source) c("scenario", "source") else "scenario"
    coef_sd_scn <- curves_tbl |>
      dplyr::group_by(dplyr::across(dplyr::all_of(sd_grp))) |>
      dplyr::summarise(
        coef_sd_typ = stats::median(.data$coef_sd, na.rm = TRUE),
        .groups = "drop"
      )
    agg_df <- dplyr::left_join(agg_df, coef_sd_scn, by = sd_grp)
    agg_df$coef_lo <- agg_df$central + stats::qnorm(band_q[["lo"]]) * agg_df$coef_sd_typ
    agg_df$coef_hi <- agg_df$central + stats::qnorm(band_q[["hi"]]) * agg_df$coef_sd_typ
  } else {
    agg_df$coef_lo <- NA_real_
    agg_df$coef_hi <- NA_real_
  }
  if (has_source) {
    agg_df$line_id <- paste(agg_df$scenario, agg_df$source, sep = " | ")
  } else {
    agg_df$line_id <- as.character(agg_df$scenario)
  }

  scenario_levels <- c(
    "Historical",
    sort(unique(as.character(agg_df$scenario[!agg_df$is_historical])))
  )
  scenario_colour_map <- stats::setNames(vapply(scenario_levels, function(s) {
    if (identical(s, "Historical")) {
      return(.wise_support)
    }
    ssp <- .normalise_ssp(s)
    if (ssp %in% names(.ssp_colours)) unname(.ssp_colours[[ssp]]) else .wise_slate
  }, character(1L)), scenario_levels)
  # Period linetypes from the static builder's year-style resolution.
  agg_df$yr_lbl <- ifelse(agg_df$is_historical, "Historical",
    vapply(agg_df$scenario, .parse_year, character(1L))
  )
  fut_yr_labels <- sort(unique(agg_df$yr_lbl[agg_df$yr_lbl != "Historical"]))
  yr_styles <- .resolve_year_styles(fut_yr_labels)
  line_type_map <- c("Historical" = "solid", yr_styles$linetype_map)
  e_type_of <- function(scn) {
    yr <- .parse_year(scn)
    t <- if (!is.null(yr) && !is.na(yr) && yr %in% names(line_type_map)) {
      unname(line_type_map[[yr]])
    } else {
      "solid"
    }
    if (identical(t, "dotdash") || identical(t, "longdash")) "dashed" else
      if (identical(t, "twodash")) "dashed" else t
  }

  max_prob <- max(agg_df$exceed_prob, na.rm = TRUE)
  is_adverse_tail <- max_prob <= 0.55
  support_years <- if (!is.null(n_sim_years) && is.finite(n_sim_years)) {
    max(2L, floor(n_sim_years))
  } else {
    NA_integer_
  }
  supported_rp <- function(x) {
    if (!is.finite(support_years)) {
      return(x)
    }
    denom <- suppressWarnings(as.numeric(sub(".*:", "", names(x))))
    x[is.na(denom) | denom <= support_years]
  }
  rp_tick_label <- function(nm, prob) {
    paste0(
      sub(":", " in ", nm), "\n(",
      scales::percent(prob, accuracy = 1), ")"
    )
  }

  e <- .e_step2_base(height)
  series <- list()
  show_ens <- !is.null(ensemble_band_q) &&
    (ensemble_band_q[["hi"]] > ensemble_band_q[["lo"]])

  for (lid in unique(as.character(agg_df$line_id))) {
    rows <- agg_df[agg_df$line_id == lid, , drop = FALSE]
    rows <- rows[order(rows$exceed_prob), , drop = FALSE]
    scn <- as.character(rows$scenario[[1L]])
    col <- unname(scenario_colour_map[[scn]] %||% .wise_slate)
    lty <- e_type_of(scn)
    if (has_source && identical(as.character(rows$source[[1L]]), "Policy")) {
      col <- .wise_policy
      lty <- "dashed"
    }
    p <- rows$exceed_prob

    if (show_ens && !rows$is_historical[[1L]]) {
      series <- c(series, .e_line_band(
        paste0(lid, "__ensemble"), p, rows$intermod_lo, rows$intermod_hi,
        col, opacity = 0.2, z = 1
      ))
    }
    if (any(is.finite(rows$coef_lo))) {
      ok <- is.finite(rows$coef_lo) & is.finite(rows$coef_hi)
      series <- c(series, .e_line_band(
        paste0(lid, "__coefficient"), p[ok], rows$coef_lo[ok],
        rows$coef_hi[ok], col, opacity = 0.12,
        lower_type = "dashed", z = 1
      ))
    }
    line <- .e_line_series(lid, p, rows$central, col, width = 2, type = lty)[[1L]]
    line$endLabel <- list(
      show = TRUE, formatter = gsub(" / | \\| ", "\n", lid),
      color = col, fontSize = 12, fontWeight = "bold", distance = 8
    )
    line$labelLayout <- list(moveOverlap = "shiftY")
    line$emphasis <- list(focus = "series")
    series <- c(series, list(line))
  }

  # Probability axis: log10 with return-period ticks in the adverse tail
  # (same support rule as the static builder); percent-formatted labels.
  if (is_adverse_tail) {
    log_rp <- c("1:2" = 0.50, RP_LOW)
    log_rp <- supported_rp(log_rp)
    log_rp <- log_rp[order(log_rp, decreasing = TRUE)]
    log_breaks <- unname(log_rp)
    log_labels <- mapply(rp_tick_label, names(log_rp), unname(log_rp),
      USE.NAMES = FALSE
    )
    min_prob <- max(min(agg_df$exceed_prob, na.rm = TRUE), 0.005)
    keep_b <- log_breaks >= min_prob * 0.9
    low_lim <- min(min_prob * 0.9, min(log_breaks[keep_b]) * 0.9)
    tick_vals <- log_breaks[keep_b]
    tick_labels <- log_labels[keep_b]
    x_min <- low_lim
    x_max <- 0.55
  } else {
    rp_low <- supported_rp(RP_LOW)
    rp_high <- supported_rp(RP_HIGH)
    tick_vals <- sort(unique(c(
      unname(rp_low), 0.50,
      1 - unname(rp_high)
    )))
    tick_labels <- ifelse(
      tick_vals == 0.5, "Median",
      paste0(
        "1 in ", format(round(1 / tick_vals)), "\n(",
        scales::percent(tick_vals, accuracy = 1), ")"
      )
    )
    x_min <- 0.005
    x_max <- 0.995
  }

  e$x$opts$xAxis <- list(
    type = "log",
    min = x_min,
    max = x_max,
    name = if (is_adverse_tail) {
      "Annual adverse exceedance probability (AEP)"
    } else {
      "Annual exceedance probability"
    },
    nameLocation = "middle",
    nameGap = 48,
    nameMoveOverlap = FALSE,
    nameTextStyle = wise_eaxis_name(),
    axisTick = list(show = TRUE, customValues = as.list(tick_vals)),
    axisLabel = wise_eaxis_label(
      fontSize = 11,
      showMinLabel = TRUE,
      showMaxLabel = TRUE,
      hideOverlap = FALSE,
      customValues = as.list(tick_vals),
      formatter = htmlwidgets::JS(sprintf(
        "function(v){ var m = %s; return m[v] === undefined ? v : m[v]; }",
        jsonlite::toJSON(as.list(stats::setNames(
          as.list(tick_labels), as.list(tick_vals)
        )), auto_unbox = TRUE)
      ))
    ),
    splitLine = wise_esplit_line(),
    axisLine = list(lineStyle = list(color = .wise_grid))
  )
  e$x$opts$yAxis <- list(
    type = "value",
    scale = TRUE,
    name = x_label,
    nameLocation = "middle",
    nameGap = 48,
    nameRotate = 90,
    nameMoveOverlap = FALSE,
    nameTextStyle = wise_eaxis_name(),
    axisLabel = .wise_result_axis_label(x_label),
    splitLine = wise_esplit_line()
  )
  e$x$opts$series <- series
  e$x$opts$tooltip <- list(
    trigger = "axis", confine = TRUE,
    axisPointer = list(type = "line", snap = TRUE),
    formatter = htmlwidgets::JS(sprintf("function(ps) {
      function esc(s) { return String(s).replace(/[&<>\"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[c]; }); }
      ps = ps.filter(function(p) { return p.seriesName.indexOf('__') === -1; });
      if (!ps.length) return '';
      var prob = ps[0].value[0];
      var heading = (prob * 100).toLocaleString('en-US', {maximumFractionDigits: 1}) + '%% annual probability';
      if (prob > 0) heading += ' (1 in ' + (1 / prob).toLocaleString('en-US', {maximumFractionDigits: 1}) + ')';
      var percent = %s;
      return heading + '<br>' + ps.map(function(p) {
        var v = p.value[1];
        return p.marker + esc(p.seriesName) + ': <b>' +
          (Number.isFinite(v) ? (percent ? v*100 : v).toLocaleString('en-US', {maximumFractionDigits: percent ? 1 : 3}) + %s : 'Not available') + '</b>';
      }).join('<br>');
    }", tolower(as.character(nzchar(.wise_result_rate_unit(x_label)))),
      jsonlite::toJSON(.wise_result_rate_unit(x_label), auto_unbox = TRUE)))
  )
  # Right-hand gutter so the endpoint scenario labels stay clear of the
  # curves, mirroring the static builder's 22% expansion.
  e$x$opts$grid <- list(containLabel = TRUE, left = 65, right = 145, top = 28, bottom = 82)
  wise_echart_theme(e)
}

# ============================================================================
# Shared reactable styling for the Step 2 tables (guidelines sec. 6). Mirrors the
# mod_1_02 .stats_reactable() recipe: compact client-side table, soft-wrapped
# text cells, raw (unrounded) values in the data - display rounding only via
# colFormat where the old DT rounded.
# ============================================================================

.step2_reactable <- function(tab, col_defs = NULL, default_page_size = 10) {
  cols <- lapply(names(tab), function(nm) {
    if (!is.null(col_defs) && !is.null(col_defs[[nm]])) {
      return(col_defs[[nm]])
    }
    reactable::colDef(class = "wise-dt-wrap", minWidth = 70)
  })
  names(cols) <- names(tab)
  reactable::reactable(
    tab,
    columns = cols,
    compact = TRUE,
    searchable = FALSE,
    defaultPageSize = default_page_size,
    showPageSizeOptions = TRUE,
    pageSizeOptions = c(10, 25, 50, 100),
    highlight = TRUE
  )
}

# Display-only number formats for the return-period threshold table. Values
# within [-1, 1] (rates, poverty gap/severity, Gini) get 4 decimals so
# sub-percentage-point differences stay visible; other outcomes get 2.
# The integer Obs column is left unformatted.
.threshold_col_defs <- function(df) {
  num <- names(df)[vapply(df, is.numeric, logical(1))]
  num <- setdiff(num, "Obs")
  vals <- unlist(df[num], use.names = FALSE)
  vals <- vals[is.finite(vals)]
  digits <- if (length(vals) && max(abs(vals)) <= 1) 4L else 2L
  stats::setNames(lapply(num, function(nm) {
    reactable::colDef(
      format = reactable::colFormat(digits = digits),
      class = "wise-dt-wrap", minWidth = 70
    )
  }), num)
}

.step2_reactable_note <- function(note) {
  .step2_reactable(data.frame(Note = note))
}
