#' 1_01_sample UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_1_01_sample_ui <- function(id) {
  ns <- NS(id)
  tagList(
    wellPanel(
      uiOutput(ns("unit_ui")),
      uiOutput(ns("sample_ui")),
      uiOutput(ns("survey_year_ui"))
    )
  )
}

#' 1_01_sample Server Functions
#'
#' @param id Module id.
#' @param survey_list Reactive tibble from mod_0_overview (survey metadata).
#' @param connection_params Reactive named list from mod_0_overview
#'   (connection type + credentials/path).
#'
#' @noRd
mod_1_01_sample_server <- function(id, connection_params, survey_list) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    # List available files at the connection endpoint ----

    # CR-PERF-09: only the selected unit's folder is listed.
    available_files <- reactive({
      req(connection_params(), input$unit)
      list_available_files(connection_params(), input$unit)
    })

    # Level of analysis selector ----

    output$unit_ui <- renderUI({
      pill_toggle(
        inputId = ns("unit"),
        label = "Level of analysis",
        choices = c(
          "Individual" = "ind",
          "Household"  = "hh",
          "Firm"       = "firm"
        ),
        selected = wise_spec_defaults()$sample$unit
      )
    })

    # Surveys available at the endpoint for the selected unit ----

    surveys <- reactive({
      req(input$unit, survey_list())
      wise_available_surveys(survey_list(), input$unit, connection_params(), available_files())
    })

    # Economy selector ----

    output$sample_ui <- renderUI({
      req(surveys())
      sv <- surveys()
      if (nrow(sv) == 0) {
        return(no_data_warning(
          "No data files found for the selected level of analysis."
        ))
      }
      choices <- setNames(sv$code, sv$economy)
      choices <- choices[!duplicated(choices)]
      selectizeInput(
        inputId  = ns("economy"),
        label    = "Economy",
        choices  = choices,
        selected = wise_default_economy(sv$code),
        multiple = TRUE,
        options  = list(maxItems = 2, placeholder = "Select up to 2 economies")
      )
    })

    # Available survey years per selected economy ----

    available_years <- reactive({
      req(input$economy, surveys())
      get_available_years(surveys(), input$economy)
    })

    # Year selector UI ----

    output$survey_year_ui <- renderUI({
      req(input$economy, available_years())
      sv <- surveys()
      req(nrow(sv) > 0)
      codes <- intersect(input$economy, unique(sv$code))
      req(length(codes) > 0)
      all_yrs <- available_years()

      year_inputs <- lapply(codes, function(code) {
        yrs <- all_yrs[[code]]
        economy_name <- sv |>
          dplyr::filter(.data$code == !!code) |>
          dplyr::pull(.data$economy) |>
          head(1)
        if (length(economy_name) == 0) economy_name <- code
        # INT-01: keep the user's year selection when the input is rebuilt
        # (economy toggled); reset only years no longer available.
        prev_yrs <- shiny::isolate(input[[paste0("year_", code)]])
        selectizeInput(
          inputId  = ns(paste0("year_", code)),
          label    = paste("Survey years -", economy_name),
          choices  = yrs,
          selected = .restore_selection(prev_yrs, yrs, fallback = wise_default_years(yrs)),
          multiple = TRUE,
          options  = list(placeholder = paste("Select years for", economy_name))
        )
      })

      tagList(year_inputs)
    })

    # These controls are prerequisites for loading the survey sample. Render
    # them even when Step 1 has not been visited so configuration replay does
    # not depend on navbar state.
    lapply(c("unit_ui", "sample_ui", "survey_year_ui"), function(out_id) {
      shiny::outputOptions(output, out_id, suspendWhenHidden = FALSE)
    })

    # Collect selected years from dynamic inputs ----

    selected_years_by_code <- reactive({
      req(input$economy)
      years_list <- lapply(
        stats::setNames(input$economy, input$economy),
        function(code) input[[paste0("year_", code)]]
      )
      Filter(Negate(is.null), years_list)
    })

    # Selected surveys ----

    selected_surveys <- reactive({
      req(input$economy)
      years_by_code <- selected_years_by_code()
      req(length(years_by_code) > 0)
      build_selected_surveys(surveys(), years_by_code)
    })

    # Return API ----

    list(
      selected_surveys = selected_surveys,
      analysis_unit    = reactive(input$unit)
    )
  })
}
