#' Results tab content UI (inserted into the Results tabPanel once).
#' @noRd
.results_content_ui <- function(ns, so, weather_var = NULL) {
  so_name <- if (!is.null(so) && "name" %in% names(so) && !is.null(so[["name"]])) {
    as.character(so[["name"]][1])
  } else {
    "welfare"
  }
  so_type <- if (!is.null(so) && "type" %in% names(so) && !is.null(so[["type"]])) {
    as.character(so[["type"]][1])
  } else {
    "numeric"
  }
  so_label <- if (!is.null(so) && "label" %in% names(so) && !is.null(so[["label"]])) {
    as.character(so[["label"]][1])
  } else {
    so_name
  }
  so_level <- if (!is.null(so) && "level" %in% names(so) && !is.null(so[["level"]])) {
    as.character(so[["level"]][1])
  } else {
    ""
  }

  outcome_lbl <- tolower(so_label)
  unit_lbl <- switch(tolower(so_level),
    ind  = "individuals",
    firm = "firms",
    "households"
  )
  panel_title <- paste0("How to summarise ", outcome_lbl, " across ", unit_lbl, "?")

  wx_phrase <- format_weather_heading_phrase(weather_var)
  sec1_heading <- if (nzchar(wx_phrase)) {
    paste0(
      "How is ", outcome_lbl, " predicted to vary with ", wx_phrase, " across climate scenarios?"
    )
  } else {
    paste0("How is ", outcome_lbl, " predicted to vary across climate scenarios and weather years?")
  }

  agg_choices <- hist_aggregate_choices(so_type, so_name)

  pov_units <- if (!is.null(so) && "units" %in% names(so) && !is.null(so[["units"]]) &&
    nzchar(as.character(so[["units"]][1]))) {
    as.character(so[["units"]][1])
  } else {
    "$/day, 2021 PPP"
  }
  pov_val <- if (!is.null(so) && "povline" %in% names(so) && !is.null(so[["povline"]]) &&
    is.finite(so[["povline"]][1]) && so[["povline"]][1] > 0) {
    so[["povline"]][1]
  } else {
    3.00
  }

  tagList(
    # 0. Stale banner (INT-08) ----
    shiny::tagList(
      shiny::uiOutput(ns("stale_banner")),
      shiny::uiOutput(ns("provisional_banner"))
    ),
    shiny::uiOutput(ns("simulation_summary_ui")),

    # 1. Analysis controls: Aggregation method & poverty line ----
    shiny::div(
      class = "results-aggregation-panel",
      shiny::div(
        class = "results-aggregation-head",
        style = "margin-bottom: 8px;",
        shiny::h5(
          panel_title,
          info_popover(
            title = "Aggregation method",
            shiny::p(
              "Choose how household-level welfare is aggregated into an annual",
              "population outcome for each simulated weather year and climate model.",
              "Poverty and prosperity metrics evaluate outcomes relative to the",
              "specified poverty line; prosperity gap uses a fixed threshold of 28."
            ),
            shiny::p(
              "Survey weights are used as supplied. They are not converted between",
              "household and person level, so the aggregate represents whichever",
              "population the survey weights describe."
            )
          ),
          style = "font-size: 0.92rem; font-weight: 700; color: #173042; margin: 0;"
        )
      ),
      shiny::div(
        style = "display: flex; align-items: center; gap: 14px; flex-wrap: wrap;",
        pill_toggle(
          inputId  = ns("cmp_agg_method"),
          label    = NULL,
          aria_label = "Aggregation method",
          choices  = agg_choices,
          selected = "mean",
          layout   = "horizontal"
        ),
        pill_toggle(
          inputId = ns("cmp_deviation"),
          label = NULL,
          aria_label = "Outcome or difference from historical",
          choices = c(
            "Outcome level"                 = "none",
            "Difference from historical mean"   = "mean",
            "Difference from historical median" = "median"
          ),
          selected = "none",
          layout = "horizontal"
        ),
        shiny::conditionalPanel(
          condition = paste0(
            "['headcount_ratio','gap','fgt2']",
            ".indexOf(input['", ns("cmp_agg_method"), "']) > -1"
          ),
          shiny::div(
            style = "display: flex; align-items: center; gap: 6px;",
            shiny::tags$label(
              `for` = ns("pov_line"),
              style = "font-size: 0.8rem; font-weight: 600; color: #526575; margin: 0; white-space: nowrap;",
              paste0("Poverty line (", pov_units, "):")
            ),
            shiny::numericInput(
              ns("pov_line"),
              label = NULL,
              value = pov_val,
              min   = 0,
              step  = 0.5,
              width = "105px"
            )
          )
        ),
        shiny::conditionalPanel(
          condition = paste0(
            "input['", ns("cmp_agg_method"), "'] === 'prosperity_gap'"
          ),
          shiny::div(
            class = "text-muted small",
            style = "font-size: 0.8rem;",
            paste0(
              "Prosperity gap uses a fixed threshold of 28; currency and time applicability ",
              "are described in the headline context.",
              if (identical(toupper(pov_units), "LCU")) {
                paste(
                  " The threshold is in 2021 PPP dollars per day and is not converted;",
                  "this outcome is in local currency, so the gap is not comparable."
                )
              }
            )
          )
        )
      )
    ),

    # 2. Headline cards ----
    shiny::uiOutput(ns("headline_cards_ui")),
    # Section 1: Central outcomes & weather-year variation ----
    shiny::h4(
      sec1_heading,
      info_popover(
        title = "Annual weather variation",
        shiny::p(
          "Each dot represents the population aggregate outcome under one simulated",
          "weather year. The box and violin illustrate the full range of annual",
          "weather-year variation for the fixed baseline population under each",
          "climate regime."
        ),
        shiny::p(
          "The dashed vertical line marks the historical baseline mean. The white circle",
          "shows the central expected outcome."
        ),
        docs = TRUE
      ),
      style = "font-size: 1.05rem; font-weight: 700; color: #173042; margin-top: 24px; margin-bottom: 8px;"
    ),
    shiny::div(
      class = "results-section-card",
      shiny::div(
        style = "display: flex; justify-content: flex-end; align-items: center; margin-bottom: 8px;",
        pill_toggle(
          ns("annual_distribution_type"),
          label    = NULL,
          aria_label = "Distribution chart type",
          choices  = c("Violin" = "violin", "Boxplot" = "boxplot"),
          selected = "violin",
          layout   = "horizontal"
        )
      ),
      wise_chart_output(
        ns("annual_distribution_plot"),
        "Distribution of annual aggregates across simulated weather years by climate scenario",
        height = "470px"
      ),
      shiny::tags$p(
        class = "text-muted small",
        style = "margin-top: 18px; margin-bottom: 0;",
        paste0(
          "Each dot is one simulated weather-year annual aggregate for the fixed baseline population. ",
          "The selected violin or boxplot summarizes the distribution; open circles mark scenario means. ",
          "This captures weather-year variability, not household inequality."
        )
      )
    ),

    # Section 2: Adverse weather years (tail risk) ----
    shiny::h4(
      "What outcomes are predicted in adverse weather years?",
      info_popover(
        title = "Adverse weather-year risk",
        shiny::p(
          "Adverse return-period outcomes represent severe annual weather conditions.",
          "An adverse 1-in-10-year outcome is reached or exceeded in the unfavorable",
          "direction in approximately one out of ten simulated weather years."
        ),
        shiny::p(
          "Points show expected outcomes and adverse-year thresholds; intervals",
          "show disagreement across CMIP6 climate models (ensemble spread)."
        ),
        docs = TRUE
      ),
      style = "font-size: 1.05rem; font-weight: 700; color: #173042; margin-top: 24px; margin-bottom: 8px;"
    ),
    shiny::div(
      class = "results-section-card",
      shiny::div(
        style = "display: flex; justify-content: flex-end; align-items: center; margin-bottom: 8px;",
        pill_toggle(
          ns("ensemble_band"),
          label = "Climate model spread",
          choices = c(
            "None" = "none",
            "Full ensemble spread" = "minmax",
            "95%" = "p025_p975",
            "90%" = "p05_p95",
            "80%" = "p10_p90"
          ),
          selected = "none",
          layout = "horizontal"
        )
      ),
      wise_chart_output(
        ns("adverse_dot_plot"),
        "Expected and adverse-year outcomes with climate-model ensemble spread",
        height = "380px"
      ),
      shiny::tags$p(
        class = "text-muted small",
        style = "margin-top: 8px; margin-bottom: 0;",
        paste0(
          "Points are equal-weight means across climate models of each model's expected and adverse-year values. ",
          "Adverse tail direction is mapped automatically according to the selected outcome metric. ",
          "Horizontal bars show inter-model ensemble spread across climate projections."
        )
      )
    ),

    # Section 3: Exceedance probability curves ----
    shiny::h4(
      "What is the probability of severe outcomes occurring?",
      info_popover(
        title = "Exceedance probability",
        shiny::p(
          "Shows the annual probability of reaching or exceeding severe outcome",
          "thresholds across simulated weather years under each climate regime.",
          "The probability axis labels standard return periods (e.g. 1 in 10 or 1 in 20 year events)."
        ),
        shiny::p(
          "The navy curve is the historical baseline. Coloured curves show the",
          "equal-weight mean across climate models, with shaded ribbons indicating inter-model spread."
        ),
        docs = TRUE
      ),
      style = "font-size: 1.05rem; font-weight: 700; color: #173042; margin-top: 24px; margin-bottom: 8px;"
    ),
    shiny::div(
      class = "results-section-card",
      shiny::div(
        style = "display: flex; justify-content: flex-end; align-items: center; margin-bottom: 8px;",
        pill_toggle(
          inputId = ns("exceedance_model_spread"),
          label = "Climate model spread",
          choices = c(
            "None"                 = "none",
            "Full ensemble spread" = "minmax",
            "95%"                  = "p025_p975",
            "90%"                  = "p05_p95",
            "80%"                  = "p10_p90"
          ),
          selected = "none",
          layout = "horizontal"
        )
      ),
      wise_chart_output(
        ns("exceedance_plot"),
        "Exceedance probability curves across simulated climate scenarios",
        height = "400px"
      ),
      shiny::tags$p(
        class = "text-muted small",
        style = "margin-top: 8px; margin-bottom: 0;",
        paste0(
          "Read each curve as the annual probability of reaching an outcome level in the adverse direction: ",
          "lower outcomes for higher-is-better measures and higher outcomes for lower-is-better measures. ",
          "Coloured lines show the across-model median; shaded ribbons show climate-model disagreement for each ",
          "future baseline and policy series. Return-period guides and ticks are limited to the available simulated ",
          "years per climate model; unsupported periods are not extrapolated."
        )
      )
    ),

    # Section 4: Decision & return-period table ----
    shiny::h4(
      "Detailed return-period outcomes and uncertainty",
      info_popover(
        title = "Return-period decision table",
        shiny::p(
          "Summary of central expected outcomes and severe weather-year thresholds",
          "for each scenario across return periods, with climate model and econometric uncertainty bounds."
        ),
        shiny::p(
          "With 30 simulated years a 1-in-20 value rests on the two most extreme years, and its sampling",
          "error is not in the bounds. The climate-model members share the same sequence of observed",
          "template years, so they are not independent years: the spread across members measures",
          "disagreement in the climate signal, not more weather variability."
        ),
        docs = TRUE
      ),
      style = "font-size: 1.05rem; font-weight: 700; color: #173042; margin-top: 24px; margin-bottom: 8px;"
    ),
    shiny::div(
      class = "results-section-card",
      shiny::div(
        style = "display: flex; justify-content: flex-end; align-items: center; margin-bottom: 8px;",
        wise_reactable_csv_button(
          ns("summary_threshold_table"),
          "climate_outcome_thresholds"
        )
      ),
      reactable::reactableOutput(ns("summary_threshold_table")),
      shiny::tags$p(
        class = "text-muted small",
        style = "margin-top: 8px; margin-bottom: 0;",
          paste0(
            "Adverse point estimates use the selected metric's baseline annual quantile within each model and an ",
            "equal-model mean across SSP models; this differs from distribution-curve medians. Bounds are existing ",
            "diagnostics, not uncertainty estimates for the equal-model mean."
          )
      )
    ),

    # Section 5: Uncertainty decomposition ----
    shiny::h4(
      "What drives the uncertainty in these predictions?",
      info_popover(
        title = "Uncertainty sources",
        shiny::p(
          "Compares the absolute standard deviation contributed by each distinct source:",
          "year-to-year weather variability, climate-model disagreement, and model-estimation uncertainty."
        ),
        shiny::p(
          paste0(
            "Coefficient uncertainty is the analytic delta-method standard error from the fitted model's ",
            "coefficient covariance matrix. It follows the Results view: a level, or the difference from the ",
            "historical mean or median, as the bar label says. A level's coefficient bar depends on the ",
            "residual rule: under \"resample\" it uses every covariate and is several times larger than ",
            "under \"original\". It is shown as one standard ",
            "deviation, not a 95% confidence interval;"
          ),
          "an approximate normal 95% interval would be estimate +/- 1.96 times this value."
        ),
        shiny::p(
          paste0(
            "Residual draws have their own bar when the residual rule is \"resample\". Their year-to-year ",
            "noise is also part of the inter-annual bar, so under \"resample\" that bar is not weather alone."
          )
        ),
        shiny::p(
          "Because standard deviations are not additive, bars are displayed side-by-side on a common scale."
        ),
        docs = TRUE
      ),
      style = "font-size: 1.05rem; font-weight: 700; color: #173042; margin-top: 24px; margin-bottom: 8px;"
    ),
    shiny::div(
      class = "results-section-card",
      wise_chart_output(
        ns("uncertainty_sources_plot"),
        "Standard deviation of outcome by uncertainty source",
        height = "300px"
      ),
      shiny::tags$p(
        class = "text-muted small",
        style = "margin-top: 8px; margin-bottom: 0;",
        paste0(
          "Bars are standard deviations in outcome units, not confidence intervals. ",
          "Inter-annual variability is the within-model standard deviation across simulated weather years; ",
          "inter-model spread is the standard deviation of model means across climate models; ",
          "coefficient uncertainty is the analytic delta-method SE from the fitted model covariance ",
          "for the selected view (level or difference from the historical mean or median); ",
          "residual draws, when the \"resample\" rule is on, are shown separately."
        )
      )
    )
  )
}


#' Placeholder rows for scenarios still computing (provisional mode only)
#'
#' Appends one row per pending scenario to the threshold table: scenario label,
#' Estimate "computing...", every other column blank.
#' @noRd
.append_pending_threshold_rows <- function(df, pending) {
  pending <- as.character(pending %||% character(0))
  scn_col <- intersect(c("Scenario / Period", "Scenario"), names(df))[1L]
  if (is.null(df) || !nrow(df) || !length(pending) || is.na(scn_col) ||
      !"Estimate" %in% names(df)) {
    return(df)
  }
  pending <- setdiff(pending, df[[scn_col]])
  if (!length(pending)) return(df)
  new <- df[rep(NA_integer_, length(pending)), , drop = FALSE]
  new[[scn_col]] <- pending
  new$Estimate <- "computing..."
  out <- rbind(df, new)
  # rbind() leaves character row names, which reactable would display.
  rownames(out) <- NULL
  out
}

# Lazy per-method aggregation list ----
# Built inside mod_2_02_results_server(); the S3 methods force the builder on
# first access. Defined at top level and registered (not in the module
# closure) so dispatch does not depend on the caller's environment.

.force_lazy_aggregation_method <- function(x) {
  if (!inherits(x, "wise_lazy_aggregation_method_list")) {
    return(x)
  }
  state <- attr(x, "state", exact = TRUE)
  if (!isTRUE(state$built)) {
    state$value <- state$builder()
    state$built <- TRUE
  }
  x
}

#' @export
#' @noRd
`[[.wise_lazy_aggregation_method_list` <- function(x, i, ...) {
  x <- .force_lazy_aggregation_method(x)
  attr(x, "state", exact = TRUE)$value[[i]]
}

#' @export
#' @noRd
`$.wise_lazy_aggregation_method_list` <- function(x, name) {
  x <- .force_lazy_aggregation_method(x)
  attr(x, "state", exact = TRUE)$value[[name]]
}

#' @export
#' @noRd
names.wise_lazy_aggregation_method_list <- function(x) {
  names(unclass(x))
}

#' @export
#' @noRd
length.wise_lazy_aggregation_method_list <- function(x) 1L

#' 2_02_results Server Functions
#'
#' Appends a Results tab to the main tabset once the historical simulation
#' has run. All comparison outputs update reactively as saved_scenarios change.
#'
#' @param id              Module id.
#' @param hist_sim        ReactiveVal. Named list with slots:
#'   \code{$preds} (full prediction data frame), \code{$agg} (pre-aggregated
#'   summary by method x weighted x deviation x sim_year), \code{$so}
#'   (selected outcome metadata), \code{$pov_line} (simulation-time poverty
#'   line), \code{$has_weights} (logical weight flag), \code{$weather_raw},
#'   \code{$train_data}, \code{$n_pre_join}.
#' @param saved_scenarios ReactiveVal holding named scenario entries.
#' @param selected_hist   Reactive one-row data frame from weathersim.
#' @param selected_weather Reactive data frame of selected weather variables.
#' @param tabset_id       Character id of the parent tabset panel.
#' @param tabset_session  Shiny session for the tabset.
#' @param live_run        Reactive; NULL or the streaming-run list from
#'   mod_2_01 (see review/step2_live_run_contract.md). Drives the provisional
#'   display source.
#' @param adopted_partials Reactive; accepted for the cache-seeding phase,
#'   not read yet.
#' @param display_settings_out Optional reactiveVal written with
#'   \code{list(method, pov_line, bandwidth_p0)} in committed mode only.
#'
#' @noRd
mod_2_02_results_server <- function(id,
                                    hist_sim,
                                    saved_scenarios,
                                    selected_hist,
                                    selected_weather = NULL,
                                    tabset_id,
                                    tabset_session = NULL,
                                     residuals = reactive("original"),
                                     skip_coef_draws = reactive(FALSE),
                                     shared_aggregation_cache = NULL,
                                     stale = reactive(FALSE),
                                     live_run = reactive(NULL),
                                     adopted_partials = reactive(NULL),
                                     display_settings_out = NULL) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    if (is.null(tabset_session)) tabset_session <- session$parent %||% session

    # INT-08: stale banner above the results pane. This surface gates its
    # CSV export while stale.
    output$stale_banner <- renderUI({
      if (isTRUE(stale())) {
        .stale_banner(
          "Step 2 simulation results",
          note = NULL
        )
      } else {
        NULL
      }
    })

    # Exports are committed-only. While a run streams (provisional mode) the
    # shared display closures are fed by partials, so each registered `fun`
    # is wrapped to signal "not ready" (req), which the bundle skips silently.
    # Once the run is adopted, or cancelled with the committed run showing,
    # exports work again from the committed data.
    # The condition is a wise_export_skip, which the bundle reports as a
    # skipped artefact with this note (README and notification) rather than
    # dropping it silently.
    .committed_only <- function(fun) {
      force(fun)
      function() {
        if (.is_provisional()) {
          stop(structure(
            class = c("wise_export_skip", "error", "condition"),
            list(
              message = paste(
                "A new Step 2 run is still in progress; export again once",
                "it has finished."
              ),
              call = NULL
            )
          ))
        }
        fun()
      }
    }

    # results_source(): single display source ----
    # Every display consumer reads this instead of hist_sim()/saved_scenarios().
    # Returns NULL when there is nothing to show, otherwise a plain list:
    #   mode              "committed" | "provisional"
    #   so                outcome row
    #   has_weights, has_draws, residuals, weight_key
    #   analysis_unit, sim_summary, hist_label  (NULL when provisional)
    #   scenario_names    landed scenario labels (NULL only when committed
    #                     saved_scenarios() is NULL)
    #   scenario_n_models named integer, same order as scenario_names
    #   pending_names     labels still computing (provisional only)
    #   methods_available aggregation methods the outcome supports
    #   locked_method / locked_pov_line / locked_bandwidth
    #                     NULL when committed; the partial's display settings
    #                     when provisional
    #   progress          NULL when committed; list(groups_done, groups_total)
    #   hist_agg(method), scn_agg(method)
    #                     nested list(<weight slot> = list(<method> = table));
    #                     committed: today's lazy workspace path; provisional:
    #                     streamed partial tables (every method in
    #                     methods_available), NULL for other methods.
    # Provisional wins when live_run() has a historical partial. C-class
    # consumers (incidence, aggregation workspace/cache, exports, the
    # Diagnostics return API) keep reading hist_sim()/saved_scenarios().
    # live_run() is rewritten on every 0.5 s progress tick (elapsed, member
    # counters). Display consumers depend only on the run identity and its
    # partials, so mirror those into a reactiveVal: identical writes do not
    # invalidate, and charts re-render once per landed partial, not per tick.
    live_data <- reactiveVal(NULL)
    observe({
      lr <- live_run()
      live_data(if (is.null(lr)) NULL else list(
        generation = lr$generation,
        scenario_labels = lr$scenario_labels,
        groups_total = lr$groups_total,
        partials = lr$partials
      ))
    })

    results_source <- reactive({
      live <- live_data()
      hp <- live$partials$historical
      if (!is.null(live) && !is.null(hp)) {
        disp <- hp$display %||% list()
        method <- disp$method %||% "mean"
        wk <- disp$weight_key %||%
          if (isTRUE(hp$has_weights)) "weighted" else "unweighted"
        landed <- live$partials$scenarios %||% list()
        labels <- as.character(live$scenario_labels %||% character(0))
        # names(list()) is NULL and intersect(x, NULL) is NULL in R >= 4.2;
        # a NULL scenario_names would read as "no scenarios" and req() out
        # every chart while only the historical partial has landed.
        landed_names <- as.character(names(landed) %||% character(0))
        scn_names <- c(
          intersect(labels, landed_names),
          setdiff(landed_names, labels)
        )
        # Every streamed method is served from the partial's `tables`; a
        # partial without `tables` carries only the captured method (`table`).
        tbl_of <- function(p, m) {
          p$tables[[m]] %||% if (identical(m, method)) p$table else NULL
        }
        streamed <- unique(c(
          method,
          as.character(hp$display$methods %||% names(hp$tables))
        ))
        streamed <- intersect(
          c(unname(hist_aggregate_choices(hp$so$type, hp$so$name)), method),
          streamed
        )
        wrap <- function(tbl, m) {
          if (is.null(tbl)) return(NULL)
          list(
            unweighted = setNames(list(tbl), m),
            weighted = setNames(list(tbl), m)
          )
        }
        return(list(
          mode = "provisional",
          so = hp$so,
          has_weights = isTRUE(hp$has_weights),
          has_draws = isTRUE(hp$has_draws),
          residuals = disp$residuals %||% "original",
          weight_key = wk,
          analysis_unit = NULL,
          sim_summary = NULL,
          hist_label = NULL,
          scenario_names = scn_names,
          scenario_n_models = vapply(
            scn_names, function(nm) as.integer(landed[[nm]]$n_models %||% NA_integer_),
            integer(1)
          ),
          pending_names = setdiff(labels, scn_names),
          methods_available = streamed,
          locked_method = method,
          locked_pov_line = disp$pov_line,
          locked_bandwidth = disp$bandwidth_p0,
          progress = list(
            groups_done = length(landed),
            groups_total = live$groups_total %||% length(labels)
          ),
          hist_agg = function(m) {
            if (m %in% streamed) wrap(tbl_of(hp, m), m) else NULL
          },
          scn_agg = function(m) {
            if (!m %in% streamed || !length(scn_names)) return(NULL)
            setNames(
              lapply(scn_names, function(nm) wrap(tbl_of(landed[[nm]], m), m)),
              scn_names
            )
          }
        ))
      }
      hs <- hist_sim()
      if (is.null(hs)) {
        return(NULL)
      }
      sc <- if (!is.null(saved_scenarios)) saved_scenarios() else NULL
      so <- hs$so
      list(
        mode = "committed",
        so = so,
        has_weights = isTRUE(hs$has_weights),
        has_draws = !is.null(hs$chol_obj),
        residuals = hs$residuals %||% residuals() %||% "original",
        weight_key = if (isTRUE(hs$has_weights)) "weighted" else "unweighted",
        analysis_unit = hs$analysis_unit,
        sim_summary = hs$sim_summary,
        hist_label = hs$hist_label,
        scenario_names = if (is.null(sc)) NULL else if (length(sc)) names(sc) else character(0),
        scenario_n_models = NULL,
        pending_names = character(0),
        methods_available = unname(hist_aggregate_choices(so$type, so$name)),
        locked_method = NULL,
        locked_pov_line = NULL,
        locked_bandwidth = NULL,
        progress = NULL,
        hist_agg = function(m) .get_hist_agg(m),
        scn_agg = function(m) .get_scn_agg(m)
      )
    })
    .is_provisional <- reactive({
      !is.null(live_data()$partials$historical)
    })

    output$simulation_summary_ui <- renderUI({
      src <- results_source()
      # Provisional: reduced card from what the partials carry (no
      # sim_summary / baseline survey); n_models comes from each partial.
      summary_hist <- if (is.null(src)) {
        NULL
      } else if (identical(src$mode, "provisional")) {
        list(so = src$so)
      } else {
        hist_sim()
      }
      summary_scn <- if (is.null(src)) {
        NULL
      } else if (identical(src$mode, "provisional")) {
        setNames(
          lapply(src$scenario_names, function(nm) {
            list(n_models = unname(src$scenario_n_models[[nm]]))
          }),
          src$scenario_names
        )
      } else {
        saved_scenarios()
      }
      simulation_summary_card(
        hist_sim = summary_hist,
        saved_scenarios = summary_scn,
        selected_hist = if (!is.null(selected_hist)) selected_hist() else NULL
      )
    })

    # Metadata views for the headline cards. Committed: the objects
    # themselves. Provisional: only what the partials carry (so, landed
    # scenario names), which makes the cards degrade to "Unavailable" for
    # the prediction-count note.
    .display_hist_sim <- function() {
      src <- results_source()
      if (!is.null(src) && identical(src$mode, "provisional")) {
        return(list(so = src$so))
      }
      hist_sim()
    }
    .display_saved_scenarios <- function() {
      src <- results_source()
      if (!is.null(src) && identical(src$mode, "provisional")) {
        return(setNames(
          vector("list", length(src$scenario_names)), src$scenario_names
        ))
      }
      if (!is.null(saved_scenarios)) saved_scenarios() else list()
    }

    # Observed-survey calibration of the simulated historical baseline
    # (committed results only; the placeholder frame carries no survey).
    baseline_check_rv <- reactive({
      req(hist_agg_rv())
      if (.is_provisional()) return(NULL)
      wk <- weight_key()
      method <- .selected_method()
      step2_baseline_check_view(
        hist_sim(), hist_agg_rv()[[wk]][[method]], method, pov_line_val(), wk
      )
    })

    # Coefficient (estimation) uncertainty of the climate shift for the first
    # future scenario shown on the cards: needs the aggregation gradients, so
    # it is NULL when coefficient uncertainty was skipped.
    delta_ci_rv <- reactive({
      req(hist_agg_rv())
      if (.is_provisional()) return(NULL)
      bands <- headline_bands_rv()
      fut <- bands[!bands$is_historical, , drop = FALSE]
      if (!nrow(fut)) return(NULL)
      wk <- weight_key()
      method <- .selected_method()
      entry <- scenario_agg_rv()[[fut$scenario[[1L]]]]
      step2_delta_ci_view(
        bands, hist_agg_rv()[[wk]][[method]],
        stats::setNames(list(entry[[wk]][[method]]), fut$scenario[[1L]])
      )
    })

    # Weather-support summary of the first future scenario on the cards
    # (computed during the run; absent for older runs or when unavailable).
    weather_support_rv <- reactive({
      req(hist_agg_rv())
      if (.is_provisional()) return(NULL)
      step2_weather_support_view(
        headline_bands_rv(), saved_scenarios(),
        if (!is.null(selected_weather)) selected_weather() else NULL
      )
    })

    headline_cards_data_rv <- reactive({
      req(headline_bands_rv())
      bands <- headline_bands_rv()
      if (!nrow(bands) ||
        !all(c("is_historical", "scenario") %in% names(bands))) {
        return(NULL)
      }
      step2_headline_cards(
        bands = bands,
        threshold_tbl = tryCatch(threshold_table_rv(), error = function(e) NULL),
        hist_sim = tryCatch(.display_hist_sim(), error = function(e) NULL),
        saved_scenarios = tryCatch(.display_saved_scenarios(),
          error = function(e) list()
        ),
        method = .selected_method(),
        timeseries_curves = tryCatch(timeseries_curves_rv(), error = function(e) NULL),
        deviation = input$cmp_deviation %||% "none",
        baseline_check = tryCatch(baseline_check_rv(), error = function(e) NULL),
        delta_ci = tryCatch(delta_ci_rv(), error = function(e) NULL),
        weather_support = tryCatch(weather_support_rv(), error = function(e) NULL),
        metadata = step2_card_metadata(
          tryCatch(.display_hist_sim(), error = function(e) NULL),
          .selected_method(), pov_line_val(), weight_key()
        )
      )
    })

    output$headline_cards_ui <- renderUI({
      cards <- headline_cards_data_rv()
      if (is.null(cards)) {
        return(NULL)
      }
      src <- results_source()
      note <- if (identical(src$mode, "provisional")) {
        shiny::div(
          class = "headline-card-note provisional-note",
          style = "margin: -4px 0 10px;",
          paste0(
            "Based on ", length(src$scenario_names), " of ",
            length(src$scenario_names) + length(src$pending_names), " scenarios"
          )
        )
      }
      shiny::tagList(headline_cards_ui(cards), note)
    })

    # Lazy delta-method aggregation ----
    # Replaces the eager compute_hist_agg / compute_scenario_agg path. Returns
    # the same nested list shape (weighted/unweighted -> method -> tibble) so
    # downstream consumers in fct_sim_compare.R see a compatible schema.
    agg_methods <- reactive({
      req(hist_sim())
      so <- results_source()$so
      unname(hist_aggregate_choices(so$type, so$name))
    })

    # Input updates can lag outcome changes by a browser round-trip. Keep every
    # aggregation consumer on a method supported by the current outcome.
    .selected_method <- reactive({
      src <- results_source()
      req(src)
      # Provisional: follow the control among the streamed methods, else the
      # method captured at submit.
      if (identical(src$mode, "provisional")) {
        selected <- input$cmp_agg_method
        return(
          if (!is.null(selected) && selected %in% src$methods_available) {
            selected
          } else {
            src$locked_method
          }
        )
      }
      choices <- agg_methods()
      selected <- input$cmp_agg_method %||% "mean"
      if (length(choices) && selected %in% choices) selected else "mean"
    })

    # pov_line is always supplied (the aggregation pre-computes every method
    # per year, not just the currently selected one). Non-poverty methods
    # ignore it; poverty methods need it. Default 3.00 USD/day if the input
    # hasn't been initialised yet.
    .pov_line_input <- debounce(reactive({
      as.numeric(input$pov_line %||% 3.00)
    }), 400)
    pov_line_val <- reactive({
      if (.is_provisional()) {
        locked <- results_source()$locked_pov_line
        if (!is.null(locked)) return(as.numeric(locked))
      }
      .pov_line_input()
    })

    bandwidth_p0 <- reactive({
      if (.is_provisional()) {
        locked <- results_source()$locked_bandwidth
        if (!is.null(locked)) return(as.numeric(locked))
      }
      # No UI control sets the kernel bandwidth; use the fixed default.
      0.05
    })


    # Aggregation workspace + per-method cache ----
    # Captures the heavy dependencies that invalidate every cached method
    # (hist_sim, saved scenarios, residuals, coef-draw skipping) into a
    # workspace that's recreated whenever any of them changes. The workspace
    # carries a mutable cache so we only compute each aggregation method once
    # per workspace version. The Results tab reads only the currently selected
    # method, and an eager observer pre-computes the default ("mean") as soon
    # as hist_sim() arrives - so the first render is fast even before the
    # user clicks anything.
    #
    # Display-only controls (coefficient band, poverty line, headcount
    # bandwidth) are deliberately NOT workspace dependencies: changing them
    # used to destroy the whole cache. Instead they are read at cache-lookup
    # time and folded into the per-method cache key for exactly the methods
    # that consume them (see .pl_bw_key).
    cache_workspace_ref <- new.env(parent = emptyenv())
    cache_workspace_ref$current <- NULL

    .clear_aggregation_cache <- function(ws = cache_workspace_ref$current) {
      if (is.null(ws)) {
        return(invisible(NULL))
      }
      .clear_workspace_cache(ws)
      if (identical(ws, cache_workspace_ref$current)) {
        cache_workspace_ref$current <- NULL
      }
      invisible(NULL)
    }



    .cache_snapshot <- function(ws = cache_workspace_ref$current) {
      .aggregation_cache_snapshot(ws)
    }
    aggregation_cache <- function() {
      published <- tryCatch(shiny::isolate(hist_sim()), error = function(e) NULL)
      if (is.null(published)) {
        return(.cache_snapshot(NULL))
      }
      .cache_snapshot()
    }

    agg_workspace <- reactive({
      req(hist_sim())
      .clear_aggregation_cache()
      cache_order <- new.env(parent = emptyenv())
      cache_order$keys <- character(0)
      cache_order$max_entries <- 8L
      cache_order$hits <- 0L
      cache_order$misses <- 0L
      cache_order$evictions <- character(0)
       ws <- list(
        hs = hist_sim(),
        sc = saved_scenarios(),
        res = hist_sim()$residuals %||% residuals() %||% "original",
        skip = isTRUE(skip_coef_draws()),
        cache = new.env(parent = emptyenv()),
         cache_order = cache_order,
         prep_cache = .new_aggregation_preparation_cache(max_entries = 32L),
         weighted_suite_cache = new.env(parent = emptyenv())
       )
      cache_workspace_ref$current <- ws
      .seed_aggregation_cache(ws)
      ws
    })

    session$onSessionEnded(function() .clear_aggregation_cache())
    observeEvent(hist_sim(),
      {
        if (is.null(hist_sim())) .clear_aggregation_cache()
      },
      ignoreInit = FALSE
    )




    # Cache seeding from adopted partials (plan 5.5) ----
    # When the workspace is built for the run whose partials were just adopted
    # (hist_sim()$.sig identical to the adoption signature), the displayed
    # method's tables are pre-inserted under the keys .get_hist_agg() /
    # .get_scn_agg() would use, so the first committed render does not
    # re-aggregate it. Pure cache: any mismatch (signature, method, residuals,
    # skip_coef, is_log, weight slot, model count) leaves the cache untouched.
    # The pov_line/bandwidth are folded into the key exactly as for a normal
    # lookup, so a different poverty line in the committed controls simply
    # misses the seeded entry. adopted_partials() is read with isolate():
    # mod_2_01 sets it in the same commit as hist_sim()/saved_scenarios().
    # Scenarios are seeded per slot: a scenario without a matching partial
    # keeps its normal lazy builder inside the same cached value.

    .seed_aggregation_cache <- function(ws) {
      ap <- shiny::isolate(adopted_partials())
      hp <- ap$partials$historical
      sig <- ws$hs$.sig
      if (is.null(hp) || is.null(sig) || !identical(sig, ap$dependency_signature)) {
        return(invisible(FALSE))
      }
      expected_wk <- if (isTRUE(ws$hs$has_weights)) "weighted" else "unweighted"
      # Table of method m carried by partial p (`tables`, else the captured
      # method's `table`).
      tbl_of <- function(p, m) {
        tbl <- p$tables[[m]] %||%
          if (identical(m, p$display$method)) p$table else NULL
        if (is.data.frame(tbl)) tbl else NULL
      }
      matches <- function(p, so, expect_models = NULL) {
        d <- p$display
        if (is.null(d)) return(FALSE)
        if (is.null(d$method) || !is.character(d$method) || length(d$method) != 1L) {
          return(FALSE)
        }
        if (is.null(tbl_of(p, d$method))) return(FALSE)
        if (!identical(d$method, hp$display$method)) return(FALSE)
        if (!identical(d$weight_key, expected_wk)) return(FALSE)
        if (!identical(d$residuals, ws$res)) return(FALSE)
        if (!identical(isTRUE(d$skip_coef), isTRUE(ws$skip))) return(FALSE)
        if (!identical(isTRUE(d$is_log), isTRUE(so$transform == "log"))) return(FALSE)
        if (!identical(d$pov_line, hp$display$pov_line) ||
            !identical(d$bandwidth_p0, hp$display$bandwidth_p0)) {
          return(FALSE)
        }
        if (!is.null(expect_models) && !is.null(p$n_models) &&
            !identical(as.integer(p$n_models), as.integer(expect_models))) {
          return(FALSE)
        }
        TRUE
      }
      if (!matches(hp, ws$hs$so)) return(invisible(FALSE))
      pl_v <- hp$display$pov_line
      bw <- hp$display$bandwidth_p0
      wk <- hp$display$weight_key
      supported <- unname(hist_aggregate_choices(ws$hs$so$type, ws$hs$so$name))
      methods <- intersect(
        supported,
        unique(c(hp$display$method, hp$display$methods, names(hp$tables)))
      )
      methods <- methods[vapply(methods, function(m) !is.null(tbl_of(hp, m)), logical(1))]
      if (!length(methods)) return(invisible(FALSE))

      # One historical entry and one scenario entry per method. The workspace
      # cache is capped at 8 entries, which would evict seeded methods as
      # soon as the whole suite (up to 2 entries per method) is inserted;
      # size it to the seeded method count, still bounded.
      ws$cache_order$max_entries <- max(
        ws$cache_order$max_entries, 2L * length(methods) + 2L
      )

      sc <- ws$sc
      landed <- ap$partials$scenarios %||% list()
      ok_scn <- if (length(sc) > 0L) {
        Filter(function(nm) {
          p <- landed[[nm]]
          !is.null(p) &&
            matches(p, sc[[nm]]$so %||% ws$hs$so, length(sc[[nm]]$pipelines))
        }, names(sc))
      } else {
        character(0)
      }
      for (method in methods) {
        key_sfx <- .pl_bw_key(method, pl_v, bw)
        hist_val <- .build_hist_for_method(
          ws, method, pl_v, bandwidth_p0, agg_methods, shared_aggregation_cache
        )
        hist_val[[wk]] <- .seeded_lazy(tbl_of(hp, method), method)
        .cache_put(ws, paste0("h_", method, key_sfx), hist_val)

        seeded <- FALSE
        if (length(sc) > 0L) {
          scn_val <- .build_scn_for_method(ws, method, pl_v, bandwidth_p0, agg_methods)
          for (nm in ok_scn) {
            tbl <- tbl_of(landed[[nm]], method)
            if (!is.null(tbl)) {
              scn_val[[nm]][[wk]] <- .seeded_lazy(tbl, method)
              seeded <- TRUE
            }
          }
          if (seeded) .cache_put(ws, paste0("s_", method, key_sfx), scn_val)
        }
      }
      invisible(TRUE)
    }

    .get_hist_agg <- function(method) {
      ws <- agg_workspace()
      pl_v <- pov_line_val()
      bw <- bandwidth_p0()
      key <- paste0("h_", method, .pl_bw_key(method, pl_v, bw))
      cached <- .cache_get(ws, key)
      if (!isTRUE(cached$found)) {
        value <- .build_hist_for_method(
          ws, method, pl_v, bandwidth_p0, agg_methods, shared_aggregation_cache
        )
        .cache_put(ws, key, value)
      } else {
        value <- cached$value
      }
      value
    }

    .get_scn_agg <- function(method) {
      ws <- agg_workspace()
      pl_v <- pov_line_val()
      bw <- bandwidth_p0()
      key <- paste0("s_", method, .pl_bw_key(method, pl_v, bw))
      cached <- .cache_get(ws, key)
      if (!isTRUE(cached$found)) {
        value <- .build_scn_for_method(ws, method, pl_v, bandwidth_p0, agg_methods)
        .cache_put(ws, key, value)
      } else {
        value <- cached$value
      }
      value
    }

    hist_agg_rv <- reactive({
      method <- .selected_method()
      results_source()$hist_agg(method)
    })

    scenario_agg_rv <- reactive({
      src <- results_source()
      req(src, !is.null(src$scenario_names))
      if (length(src$scenario_names) == 0L) {
        return(NULL)
      }
      method <- .selected_method()
      src$scn_agg(method)
    })

    # Reactive computations (carried over from mod_2_06) ----


    # Always use survey weights when available (UI toggle removed - weighting
    # is the correct default for survey-based welfare estimates).
    weight_key <- reactive({
      src <- results_source()
      if (!is.null(src)) src$weight_key else "unweighted"
    })

    # Shared deviation reference - used by all_series_tbl and exceedance_ribbon
    hist_ref_val <- reactive({
      req(hist_agg_rv())
      step2_hist_ref(
        hist_agg_rv()[[weight_key()]][[.selected_method()]],
        input$cmp_deviation %||% "none"
      )
    })

    # Per-coefficient gradient of the historical reference being subtracted
    # (step2_hist_f_ref()), used by .apply_contrast_sd() below.
    hist_F_agg_ref <- reactive({
      req(hist_agg_rv())
      step2_hist_f_ref(
        hist_agg_rv()[[weight_key()]][[.selected_method()]],
        input$cmp_deviation %||% "none"
      )
    })

    # Replace per-(model, year) coefficient SDs with paired-contrast SDs
    # when a deviation reference is active. By overwriting `value_all_sd`
    # here, every downstream consumer (pointrange_bands_rv,
    # threshold_table_rv, exceedance_curves_rv) automatically uses the
    # tightened contrast variance.
    .apply_contrast_sd <- step2_contrast_sd

    # The aggregation tables of the selected metric as one series: the
    # historical run, then the scenarios (the landed ones unless
    # `selected_only` is FALSE), with the contrast SDs applied.
    .contrast_series <- function(selected_only = TRUE) {
      wk <- weight_key()
      method <- .selected_method()
      F_ref <- hist_F_agg_ref()
      series <- list(
        Historical = .apply_contrast_sd(hist_agg_rv()[[wk]][[method]], F_ref)
      )
      sa <- scenario_agg_rv()
      if (!is.null(sa) && length(sa) > 0L) {
        for (dk in names(sa)) {
          if (isTRUE(selected_only) && !dk %in% selected_scenario_names()) next
          series[dk] <- list(.apply_contrast_sd(sa[[dk]][[wk]][[method]], F_ref))
        }
      }
      series
    }

    # One immutable derived frame per published run/control state. Every
    # Results consumer below resolves its model/year matrix from this frame,
    # avoiding repeated reshaping and preserving identical canonical ordering.
    derived_results_frame_rv <- reactive({
      req(hist_agg_rv())
      wk <- weight_key()
      method <- .selected_method()
      deviation <- input$cmp_deviation %||% "none"
      F_ref <- hist_F_agg_ref()
      entries <- list()
      add_entry <- function(tbl, label, historical) {
        tbl <- .lazy_aggregation_table(tbl, method)
        if (is.null(tbl) || !nrow(tbl)) {
          return(invisible(NULL))
        }
        tbl <- .apply_contrast_sd(tbl, F_ref)
        key <- digest::digest(tbl, serialize = TRUE)
        entry <- new.env(parent = emptyenv())
        entry$table <- tbl
        entry$matrix <- by_model_matrix(tbl)
        entry$scenario <- label
        entry$is_historical <- historical
        entry$key <- key
        lockEnvironment(entry, bindings = TRUE)
        entries[[label]] <<- entry
        invisible(NULL)
      }
      add_entry(hist_agg_rv()[[wk]][[method]], "Historical", TRUE)
      sa <- scenario_agg_rv()
      if (!is.null(sa)) {
        for (label in names(sa)) {
          add_entry(sa[[label]][[wk]][[method]], label, FALSE)
        }
      }
      frame <- new.env(parent = emptyenv())
      frame$method <- method
      frame$deviation <- deviation
      frame$weight <- wk
      frame$.entries <- entries
      frame$.matrices <- stats::setNames(
        lapply(entries, `[[`, "matrix"),
        vapply(entries, `[[`, character(1L), "key")
      )
      lockEnvironment(frame, bindings = TRUE)
      frame
    })


    # Coefficient draws availability ----
    has_draws <- reactive({
      src <- results_source()
      req(src)
      isTRUE(src$has_draws)
    })


    # Landed scenario names only; pending ones are handled by placeholders.
    selected_scenario_names <- reactive({
      results_source()$scenario_names %||% character(0)
    })

    agg_hist <- reactive({
      req(hist_agg_rv())
      method <- .selected_method()
      deviation <- input$cmp_deviation %||% "none"
      out <- hist_agg_rv()[[weight_key()]][[method]]
      req(!is.null(out))
      hist_ref <- hist_ref_val()
      if (!identical(deviation, "none") && nrow(out) > 0) {
        out <- dplyr::mutate(out, value = value - hist_ref)
      }
      x_label <- if (identical(deviation, "none")) {
        label_agg_method(method)
      } else {
        paste0(label_agg_method(method), " \u2014 ", label_deviation(deviation))
      }
      list(out = out, x_label = x_label)
    })

    # `exceedance_ribbon` removed - the ribbon is now built inside
    # the static exceedance renderer directly from each series' (value_all, value_all_sd)
    # using analytic delta-method bands, so there is nothing to precompute here.

    # Three-source uncertainty decomposition ----
    # All three downstream displays (hero, exceedance, table) source their
    # bands from the helpers below. Each helper produces a per-scenario view
    # that decomposes uncertainty into:
    #   - coefficient (per-outcome SE from value_all_sd)
    #   - inter-annual (within-model spread of value_all across years)
    #   - inter-model  (across-model spread of model means; future only)

    # Helpers are now defined in R/fct_uncertainty_helpers.R as package-internal
    # functions so Module 3 can call the same code path. Aliases keep the
    # existing inline call sites below readable.
    .by_model_matrix <- function(tbl) {
      frame <- derived_results_frame_rv()
      key <- digest::digest(tbl, serialize = TRUE)
      hit <- .results_frame_matrix(frame, key)
      if (!is.null(hit)) {
        return(hit)
      }
      by_model_matrix(tbl)
    }

    # pointrange_bands_rv: one row per scenario, three nested bands ----
    pointrange_bands_rv <- reactive({
      req(hist_agg_rv())
      step2_pointrange_bands(
        .contrast_series(TRUE),
        step2_ensemble_band_q(input$ensemble_band),
        hist_ref_val(), .by_model_matrix
      )
    })

    wise_export_table(
      key = "climate_adverse_support",
      label = "Climate baseline-anchored adverse support",
      step = 2L,
      fun = .committed_only(function() {
        support <- attr(threshold_table_rv(), "adverse_support")
        if (is.data.frame(support)) support else data.frame()
      }),
      description = paste0(
        "Per-model annual selected-metric baseline quantile and interpolation year-rank support. ",
        "SSP point centers are equal-model means."
      )
    )

    # Only the expected headline changes center; all existing chart/threshold
    # reactives retain their median ensemble convention and deviation behavior.
    headline_bands_rv <- reactive({
      bands <- pointrange_bands_rv()
      step2_headline_bands(bands, .contrast_series(FALSE), hist_ref_val(), .by_model_matrix)
    })

    # timeseries_curves_rv: per (scenario, model, sim_year) values ----
    build_timeseries_curves <- function(selected_only = TRUE) {
      req(hist_agg_rv())
      step2_timeseries_curves(
        .contrast_series(selected_only), hist_ref_val(), .by_model_matrix
      )
    }

    timeseries_curves_rv <- reactive(build_timeseries_curves(TRUE))
    annual_distribution_curves_rv <- reactive(build_timeseries_curves(FALSE))

    # variance_breakdown_rv: one row per scenario, three components ----
    # Aggregates the per-(sim_year) var_within / var_across columns to scalars
    # and re-computes var_coef from the per-(model, year) SD list-column.
    variance_breakdown_rv <- reactive({
      req(derived_results_frame_rv())
      step2_variance_breakdown(.contrast_series(TRUE), .by_model_matrix)
    })

    # exceedance_curves_rv: per (scenario, model) ECDF rows ----
    # One row per (scenario, model, rank). welfare_val is sorted in the adverse
    # tail direction; exceed_prob is (rank - 0.5)/n_pts limited to <= 0.50 AEP.
    exceedance_curves_rv <- reactive({
      req(hist_agg_rv())
      hist_ref <- hist_ref_val()
      wk <- weight_key()
      method <- .selected_method()
      so_obj <- tryCatch(results_source()$so, error = function(e) NULL)
      spec <- metric_metadata(method, so_obj)
      adverse_tail <- spec$adverse_tail

      one_scenario <- function(tbl, scenario_label, is_hist) {
        if (is.null(tbl) || nrow(tbl) == 0L) {
          return(NULL)
        }
        mm <- .by_model_matrix(tbl)
        if (is.null(mm)) {
          return(NULL)
        }
        vals <- mm$vals
        sds <- mm$sds
        n_yrs <- ncol(vals)
        if (n_yrs == 0L) {
          return(NULL)
        }

        do.call(dplyr::bind_rows, lapply(seq_len(nrow(vals)), function(i) {
          v <- vals[i, ]
          s <- sds[i, ]
          ok <- is.finite(v)
          if (!any(ok)) {
            return(NULL)
          }
          v <- v[ok]
          s <- s[ok]
          n_pts <- length(v)

          # Adverse tail direction:
          # If adverse_tail == "low" (welfare/consumption): smaller is worse -> ascending.
          # If adverse_tail == "high" (poverty): larger is worse -> descending.
          ord <- if (identical(adverse_tail, "high")) {
            order(v, decreasing = TRUE)
          } else {
            order(v, decreasing = FALSE)
          }
          v_ord <- v[ord]
          s_ord <- if (length(s) == length(ord)) s[ord] else rep(0, length(ord))
          # Hazen plotting positions, (rank - 0.5) / n: the same convention as
          # the threshold table's rank_interp(), so "1 in 10" agrees in both.
          probs <- (seq_along(ord) - 0.5) / n_pts

          # Limit strictly to adverse tail: 0.50 AEP or less
          keep <- probs <= 0.50
          if (!any(keep)) {
            return(NULL)
          }

          tibble::tibble(
            scenario      = scenario_label,
            model_id      = mm$model_ids[[i]],
            rank          = seq_along(ord)[keep],
            welfare_val   = v_ord[keep] - hist_ref,
            coef_sd       = s_ord[keep],
            exceed_prob   = probs[keep],
            is_historical = is_hist
          )
        }))
      }

      rows <- list(one_scenario(
        .apply_contrast_sd(hist_agg_rv()[[wk]][[method]], hist_F_agg_ref()),
        "Historical", TRUE
      ))
      sa <- scenario_agg_rv()
      if (!is.null(sa) && length(sa) > 0L) {
        for (dk in names(sa)) {
          if (!dk %in% selected_scenario_names()) next
          rows[[length(rows) + 1L]] <- one_scenario(
            .apply_contrast_sd(sa[[dk]][[wk]][[method]], hist_F_agg_ref()),
            dk, FALSE
          )
        }
      }
      dplyr::bind_rows(Filter(Negate(is.null), rows))
    })

    # threshold_table_rv: long-format rows ready to pivot wide ----
    # One row per (scenario, Estimate, RP). Estimate names are derived from
    # the user's band quantile selection: e.g., with coef=p10_p90 and
    # ensemble=minmax the rows are "Central (P50)", "Coef P10", "Coef P90",
    # "Ensemble min", "Ensemble max", "Pooled P10", "Pooled P90". Pooled
    # rows combine the coefficient and inter-model components assuming
    # independence: SE_pooled = sqrt(coef_sd^2 + var_across_at_rp).
    # Historical (no inter-model component) does not emit Pooled rows -
    # they would duplicate the Coef rows.
    threshold_table_rv <- reactive({
      req(hist_agg_rv())
      step2_threshold_table(
        .contrast_series(TRUE),
        bq_coef = resolve_band_q("p10_p90"),
        bq_ens = step2_ensemble_band_q(input$ensemble_band),
        hist_ref = hist_ref_val(),
        method = .selected_method(),
        so = tryCatch(results_source()$so, error = function(e) NULL),
        mm_fn = .by_model_matrix
      )
    })

    # UI-48: register Step 2's result figures for the export bundle.
    wise_export_table(
      key = "climate_headline_summary",
      label = "Climate headline summary cards",
      step = 2L,
      fun = .committed_only(function() step2_headline_df(headline_cards_data_rv())),
      description = paste(
        paste0(
          "Headline values are display-formatted; native numeric endpoints, units, selected deviation, metric ",
          "context, and summary operators are included."
        ),
        paste0(
          "Expected, model-agreement and range summaries average years within model and weight climate models ",
          "equally; adverse annual selected-metric quantiles use an equal-model mean."
        )
      )
    )

    # Zero-arg echarts closures shared by the renders and the export bundle
    # (guidelines section 7): one builder call per chart, used for both the live
    # output and wise_export_figure(). Heights match the UI slots.
    pointrange_chart <- function() {
      bands <- pointrange_bands_rv()
      req(bands)
      if (identical(input$ensemble_band %||% "none", "none")) {
        bands$intermod_lo <- NA_real_
        bands$intermod_hi <- NA_real_
      }
      echart_pointrange_climate(
        bands_tbl    = bands,
        x_label      = agg_hist()$x_label,
        group_order  = "scenario_x_year",
        show_coef    = FALSE,
        height       = "600px"
      )
    }
    wise_export_figure(
      key = "climate_outcome_distribution",
      label = "Simulated welfare by scenario and period",
      step = 2L,
      fun = .committed_only(pointrange_chart),
      description = paste0(
        "Simulated welfare by climate scenario and projection period; equal-weight mean across climate-model means, ",
        "the same centre as the expected headline."
      ),
      width = 10, height = 6.5
    )

    annual_distribution_chart <- function() {
      req(annual_distribution_curves_rv())
      echart_annual_distribution(
        annual_distribution_curves_rv(),
        x_label = metric_axis_label(
          .selected_method(),
          results_source()$so,
          input$cmp_deviation %||% "none"
        ),
        plot_type = input$annual_distribution_type %||% "violin",
        height = "470px",
        pending = results_source()$pending_names
      )
    }
    # Streaming renders: while provisional, keep the existing ECharts instance
    # (dispose = FALSE) when only new scenario data arrived, so ECharts animates
    # the added series instead of redrawing the whole chart from zero. A change
    # of run, mode or display control, or the last pending scenario landing,
    # forces a full redraw because setOption() merging cannot remove series.
    .SMOOTH_CONTROLS <- c(
      "cmp_agg_method", "cmp_deviation", "annual_distribution_type",
      "ensemble_band", "exceedance_model_spread"
    )
    smooth_state <- new.env(parent = emptyenv())
    .smooth_echart <- function(ch, id) {
      key <- shiny::isolate({
        src <- results_source()
        list(
          provisional = identical(src$mode, "provisional"),
          generation = live_data()$generation,
          pending = length(src$pending_names) > 0L,
          controls = lapply(.SMOOTH_CONTROLS, function(nm) input[[nm]])
        )
      })
      prev <- smooth_state[[id]]
      smooth_state[[id]] <- key
      if (isTRUE(key$provisional) && identical(prev, key)) ch$x$dispose <- FALSE
      ch
    }

    output$annual_distribution_plot <- echarts4r::renderEcharts4r({
      ch <- annual_distribution_chart()
      req(!is.null(ch))
      .smooth_echart(ch, "annual_distribution_plot")
    })

    incidence_data_rv <- reactive({
      # Committed only: needs full pipelines and the survey.
      req(!.is_provisional(), hist_sim(), saved_scenarios(), shiny::isolate(input$cmp_agg_method))
      step2_incidence_all(hist_sim(), saved_scenarios(), selected_scenario_names())
    })

    # Distributional incidence table: raw values; the CSV button for it
    # lives in the export bundle's reactable flow (there is no mounted UI
    # slot - the data table is exported as the bundle artefact below).
    wise_export_table(
      key = "climate_distributional_incidence_data",
      label = "Distributional incidence data",
      step = 2L,
      fun = .committed_only(function() {
        annotate_visualization_export(
          incidence_data_rv(), .selected_method(), hist_sim()$so,
          observation_unit = "household-level simulated welfare effect",
          aggregation_order = paste0(
            "fixed weighted observed baseline decile; weighted mean over households and model summaries"
          ),
          uncertainty = "scenario/model variation summarized by selected model set"
        )
      }),
      description = "Tidy weighted incidence data by fixed baseline welfare decile."
    )

    # Export the same tidy annual aggregates used by the distribution plot.
    annual_distribution_export <- function() {
      curves <- annual_distribution_curves_rv()
      req(curves)
      annotate_visualization_export(
        curves,
        .selected_method(),
        results_source()$so,
        observation_unit = "annual aggregate for fixed survey population under one weather-year draw",
        aggregation_order = "weighted household aggregate by model and weather-year; model means retained",
        uncertainty = "inter-annual weather variation"
      )
    }
    wise_export_figure(
      key = "climate_annual_distribution",
      label = "Annual outcome distribution across weather years",
      step = 2L,
      fun = .committed_only(annual_distribution_chart),
      description = paste0(
        "Annual aggregate distribution for the fixed population; one observation is one model-weather-year draw."
      ),
      width = 10, height = 6.5
    )
    wise_export_table(
      key = "climate_annual_distribution_data",
      label = "Annual outcome distribution data",
      step = 2L,
      fun = .committed_only(annual_distribution_export),
      description = "Tidy data behind the annual aggregate distribution, including metric and aggregation metadata."
    )
    # UI-48: one builder behind the on-screen table, its CSV button and the
    # export bundle.
    threshold_table_df <- function() {
      tbl <- threshold_table_rv()
      if (is.null(tbl) || !nrow(tbl) || !"Estimate" %in% names(tbl)) {
        return(NULL)
      }
      step2_threshold_df(
        tbl, .selected_method(),
        tryCatch(results_source()$so, error = function(e) NULL),
        tryCatch(results_source()$sim_summary, error = function(e) NULL)
      )
    }

    uncertainty_chart <- function() {
      req(variance_breakdown_rv())
      echart_variance_contribution(
        variance_breakdown_rv(), height = "300px",
        percent = identical(metric_metadata(
          .selected_method(), results_source()$so
        )$format, "percent"),
        reference = input$cmp_deviation %||% "none"
      )
    }
    output$uncertainty_sources_plot <- echarts4r::renderEcharts4r({
      ch <- uncertainty_chart()
      req(!is.null(ch))
      .smooth_echart(ch, "uncertainty_sources_plot")
    })
    outputOptions(output, "uncertainty_sources_plot", suspendWhenHidden = TRUE)

    wise_export_figure(
      key = "climate_uncertainty_sources",
      label = "Climate simulation uncertainty sources",
      step = 2L,
      fun = .committed_only(uncertainty_chart),
      description = paste0(
        paste0(
          "Standard deviation contribution from weather-year, coefficient, residual, and climate-model ",
          "uncertainty sources."
        )
      ),
      width = 9, height = 5
    )

    adverse_dot_data_rv <- reactive({
      req(threshold_table_rv())
      step2_adverse_dot_view(
        threshold_table_rv(), .selected_method(), results_source()$so,
        ensemble_none = identical(input$ensemble_band %||% "none", "none")
      )
    })
    adverse_dot_chart <- function() {
      req(adverse_dot_data_rv())
      echart_step2_adverse_dot(
        adverse_dot_data_rv(),
        x_label = metric_axis_label(
          .selected_method(),
          results_source()$so,
          input$cmp_deviation %||% "none"
        ),
        height = "380px",
        pending = results_source()$pending_names
      )
    }
    output$adverse_dot_plot <- echarts4r::renderEcharts4r({
      ch <- adverse_dot_chart()
      req(!is.null(ch))
      .smooth_echart(ch, "adverse_dot_plot")
    })
    outputOptions(output, "adverse_dot_plot", suspendWhenHidden = TRUE)

    wise_export_figure(
      key = "climate_adverse_return_periods",
      label = "Outcome in adverse weather years",
      step = 2L,
      fun = .committed_only(adverse_dot_chart),
      description = "Expected and adverse return-period outcomes with inter-model ensemble spread.",
      width = 9, height = 5
    )

    wise_export_table(
      key = "climate_outcome_thresholds",
      label = "Outcome threshold exceedance",
      step = 2L,
      fun = .committed_only(threshold_table_df),
      description = paste(
        "Simulated welfare outcomes against each threshold, by climate",
        "scenario and projection period, with uncertainty bounds."
      )
    )

    # Return-period decision table as a reactable (guidelines section 6): raw values
    # in the data, rounded only for display (.threshold_col_defs()), rendered
    # client-side; the CSV download moved to the shared client-side
    # wise_reactable_csv_button() next to the widget. INT-08: while the
    # results are stale the table stays visible.
    threshold_reactable <- function() {
      df <- threshold_table_df()
      if (is.null(df) || nrow(df) == 0L) {
        return(.step2_reactable_note("Insufficient data"))
      }
      src <- results_source()
      if (identical(src$mode, "provisional")) {
        df <- .append_pending_threshold_rows(df, src$pending_names)
      }
      .step2_reactable(df, col_defs = .threshold_col_defs(df))
    }
    output$summary_threshold_table <- reactable::renderReactable({
      threshold_reactable()
    })

    # UI-48: the exceedance curve, for the export bundle.
    exceedance_chart <- function() {
      curves <- exceedance_curves_rv()
      ah <- agg_hist()
      if (is.null(curves) || is.null(ah)) {
        return(NULL)
      }
      sel_spread <- input$exceedance_model_spread %||% "none"
      ens_q <- if (identical(sel_spread, "none")) {
        c(lo = 0.5, hi = 0.5)
      } else {
        resolve_band_q(sel_spread)
      }
      echart_exceedance(
        curves_tbl = curves,
        x_label = metric_axis_label(
          .selected_method(),
          results_source()$so,
          input$cmp_deviation %||% "none"
        ),
        n_sim_years = nrow(ah$out),
        logit_x = TRUE,
        band_q = NULL,
        ensemble_band_q = ens_q,
        height = "400px"
      )
    }
    wise_export_figure(
      key = "climate_exceedance_curve",
      label = "Welfare exceedance probability",
      step = 2L,
      fun = .committed_only(exceedance_chart),
      description = paste(
        "Probability of welfare falling below each level in adverse weather years, by climate scenario",
        "and projection period."
      ),
      width = 10, height = 6.5
    )

    output$exceedance_plot <- echarts4r::renderEcharts4r({
      ch <- exceedance_chart()
      req(!is.null(ch))
      .smooth_echart(ch, "exceedance_plot")
    })


    # observeEvent handlers ----

    # Insert the Results tab once the display source first has data
    # (provisional or committed); remove it again when the source is empty
    # (INT-07) so the empty state returns and a later run re-inserts a fresh
    # tab instead of writing into a stale one.
    #
    # The pane is built from the outcome (`so`) only; values flow through
    # reactives. It is therefore rebuilt (clear + insert) only when the
    # outcome changes or a committed run replaces a committed run (today's
    # behaviour) - never on each partial, and not on provisional -> committed
    # adoption or committed <-> provisional switches with an unchanged `so`.
    results_tab_added <- reactiveVal(FALSE)
    # Bumped each time the pane is (re)built, so control state can be re-sent.
    pane_rev <- reactiveVal(0L)

    # Run identity of the provisional source. A reactiveVal drops identical
    # writes, so the lifecycle observers below do not re-fire per partial.
    live_pane_key <- reactiveVal(NULL)
    observe({
      lr <- live_run()
      hp <- lr$partials$historical
      live_pane_key(
        if (is.null(hp)) NULL else list(generation = lr$generation, so = hp$so)
      )
    })
    .pane_trigger <- function() list(hist_sim(), live_pane_key())
    .pane_so <- function() {
      lk <- live_pane_key()
      if (!is.null(lk)) lk$so else hist_sim()$so
    }
    pane_state <- new.env(parent = emptyenv())
    pane_state$mode <- NULL
    pane_state$so <- NULL

    observeEvent(.pane_trigger(),
      {
        provisional <- !is.null(live_pane_key())
        if (is.null(.pane_so())) {
          if (results_tab_added()) {
            shiny::removeTab(
              inputId = tabset_id,
              target  = "sim_tab",
              session = tabset_session
            )
            results_tab_added(FALSE)
          }
          pane_state$mode <- NULL
          pane_state$so <- NULL
          return()
        }
        so <- .pane_so()
        mode <- if (provisional) "provisional" else "committed"
        keep_pane <- results_tab_added() &&
          identical(so, pane_state$so) &&
          !(identical(mode, "committed") && identical(pane_state$mode, "committed"))
        pane_state$mode <- mode
        pane_state$so <- so
        if (keep_pane) {
          return()
        }

        # UI-50: only ever one Results tab. This used to append unconditionally,
        # so every re-run of Step 2 added another copy - and because the new tab
        # carried a second `#results_section`, the `insertUI()` below targeted
        # the *first* match, filling the original tab and leaving the new one
        # empty. Steps 1 and 3 already guarded their appends; this brings Step 2
        # into line.
        if (!results_tab_added()) {
          shiny::appendTab(
            inputId = tabset_id,
            shiny::tabPanel(
              title = "Results",
              value = "sim_tab",
              shiny::div(id = ns("results_section"))
            ),
            select = TRUE,
            session = tabset_session
          )
          results_tab_added(TRUE)
        } else {
          # The tab is already there. Clear its contents so the re-run's results
          # replace the previous run's rather than stacking beneath them - the
          # pane is built from the outcome (`so`), which a new run may have
          # changed.
          # Both this and the insert below are deferred to the end of the flush
          # and run in call order, so the clear always precedes the rewrite.
          # Deferring also keeps the first-run path byte-for-byte as it was:
          # appendTab's DOM insertion lands before anything targets
          # #results_section.
          shiny::removeUI(selector = paste0("#", ns("results_section"), " > *"), multiple = TRUE)
          try(shiny::updateTabsetPanel(tabset_session,
            inputId = tabset_id,
            selected = "sim_tab"
          ), silent = TRUE)
        }

        sw_obj <- tryCatch(
          if (is.function(selected_weather)) selected_weather() else selected_weather,
          error = function(e) NULL
        )
        wx_lbl <- if (!is.null(sw_obj) && "label" %in% names(sw_obj) && length(sw_obj$label)) {
          paste(tolower(sw_obj$label), collapse = ", ")
        } else if (!is.null(sw_obj) && "name" %in% names(sw_obj) && length(sw_obj$name)) {
          paste(tolower(sw_obj$name), collapse = ", ")
        } else {
          ""
        }

        shiny::insertUI(
          selector = paste0("#", ns("results_section")),
          where    = "afterBegin",
          ui       = .results_content_ui(ns, so, weather_var = wx_lbl)
        )
        pane_rev(isolate(pane_rev()) + 1L)
      },
      ignoreInit = TRUE,
      ignoreNULL = FALSE
    )

    # On subsequent runs, just re-select the tab.
    observeEvent(.pane_trigger(),
      {
        if (!is.null(.pane_so())) {
          shiny::updateTabsetPanel(
            session  = tabset_session,
            inputId  = tabset_id,
            selected = "sim_tab"
          )
        }
      },
      ignoreInit = TRUE
    )

    # Keep agg method choices in sync with outcome.
    observeEvent(.pane_trigger(),
      {
        req(.pane_so())
        so <- .pane_so()
        choices <- hist_aggregate_choices(so$type, so$name)
        current <- isolate(input$cmp_agg_method)
        new_sel <- if (!is.null(current) && current %in% choices) current else "mean"
        src <- isolate(results_source())
        if (identical(src$mode, "provisional") &&
            !new_sel %in% src$methods_available) {
          new_sel <- src$locked_method
        }
        shiny::updateRadioButtons(session, "cmp_agg_method",
          choices  = choices,
          selected = new_sel,
          inline   = TRUE
        )
      },
      ignoreInit = TRUE
    )

    # Provisional banner ----
    # Shown only while a streaming run drives the display. Progress uses the
    # same fraction as the sidebar run panel (.step2_live_pct()).
    output$provisional_banner <- renderUI({
      src <- results_source()
      if (is.null(src) || !identical(src$mode, "provisional")) {
        return(NULL)
      }
      lr <- live_run()
      n_done <- length(src$scenario_names)
      n_all <- n_done + length(src$pending_names)
      pct <- .step2_live_pct(list(
        has_hist = TRUE,
        done_labels = names(lr$partials$scenarios) %||% character(0),
        groups_total = lr$groups_total, groups_done = lr$groups_done,
        current_label = lr$current_label,
        member_index = lr$member_index, period_members = lr$period_members
      ))
      shiny::div(
        class = "alert alert-info provisional-banner",
        style = "margin-bottom: 12px; padding: 8px 12px; font-size: 0.85rem;",
        # While streaming, keep landed charts fully visible during the
        # per-partial recalculation instead of Shiny's dimmed state. Removed
        # with the banner, so committed-mode loading cues are unchanged.
        shiny::tags$style(
          paste0("#", ns("results_section"), " .recalculating { opacity: 1 !important; transition: none; }")
        ),
        shiny::div(
          shiny::strong("Simulation in progress: "),
          paste0(n_done, " of ", n_all, " scenarios ready. Results are provisional.")
        ),
        if (!is.null(pct)) {
          shiny::div(
            class = "progress",
            shiny::div(
              class = "progress-bar", role = "progressbar",
              `aria-valuenow` = round(100 * pct), `aria-valuemin` = 0,
              `aria-valuemax` = 100,
              style = sprintf("width: %d%%;", round(100 * pct))
            )
          )
        },
        shiny::div(
          class = "text-muted",
          paste(
            "The poverty line unlocks when the run finishes.",
            if (length(setdiff(
              unname(hist_aggregate_choices(src$so$type, src$so$name)),
              src$methods_available
            ))) "Prosperity gap is also unavailable until then.",
            "Step 3 uses the last completed run, and Step 2 exports",
            "wait for the run to finish."
          )
        )
      )
    })

    # Control gating ----
    # One observer keyed on the display mode: in provisional mode only the
    # method pills that were not streamed (typically prosperity_gap) and the
    # poverty line are disabled; any exit (adoption, cancel, stale, failure)
    # flips the mode back and re-enables them. pane_rev() re-sends the state
    # after the pane is (re)built, because inserted controls start enabled.
    # The pill selection is only forced to the captured method when the
    # current one is unavailable; it is not written to display_settings_out
    # (committed-only).
    .gate_key <- reactive({
      src <- results_source()
      if (is.null(src) || !identical(src$mode, "provisional")) {
        list(provisional = FALSE)
      } else {
        list(
          provisional = TRUE, locked = src$locked_method, so = src$so,
          available = src$methods_available
        )
      }
    })
    observe({
      key <- .gate_key()
      pane_rev()
      req(results_tab_added())
      if (isTRUE(key$provisional)) {
        choices <- unname(hist_aggregate_choices(key$so$type, key$so$name))
        update_pill_toggle_disabled(
          session, "cmp_agg_method",
          disabled = setdiff(choices, key$available),
          tooltip = "Available when the simulation completes"
        )
        update_input_disabled(session, "pov_line", TRUE,
          tooltip = "Available when the simulation completes"
        )
        current <- shiny::isolate(input$cmp_agg_method)
        if (is.null(current) || !current %in% key$available) {
          shiny::updateRadioButtons(session, "cmp_agg_method",
            selected = key$locked
          )
        }
      } else {
        update_pill_toggle_disabled(session, "cmp_agg_method", FALSE)
        update_input_disabled(session, "pov_line", FALSE)
      }
    })

    # Display settings writer ----
    # Publishes the committed-mode controls so the next run is submitted with
    # them (mod_2_01 reads this at submit). Not written while provisional,
    # and not before the controls exist.
    if (!is.null(display_settings_out)) {
      observe({
        src <- results_source()
        req(src, identical(src$mode, "committed"), input$cmp_agg_method)
        display_settings_out(list(
          method = .selected_method(),
          pov_line = pov_line_val(),
          bandwidth_p0 = bandwidth_p0()
        ))
      })
    }

    # Suspend outputs when Results tab is hidden ----
    outputOptions(output, "annual_distribution_plot", suspendWhenHidden = TRUE)
    outputOptions(output, "summary_threshold_table", suspendWhenHidden = TRUE)
    outputOptions(output, "exceedance_plot", suspendWhenHidden = TRUE)

    # Return API ----
    ts_committed <- new.env(parent = emptyenv())
    ts_committed$value <- NULL
    # timeseries_curves bundles everything the Diagnostics tab needs to render
    # the per-model trajectories plot (the plot lives there now): the
    # per-(scenario, model, sim_year) table, the x-axis label, and the
    # inter-model band quantiles resolved from the Results-tab controls.
    list(
      variance_breakdown = variance_breakdown_rv,
      results_tab_added = results_tab_added,
      aggregation_cache = aggregation_cache,
      derived_results_frame = derived_results_frame_rv,
      timeseries_curves = reactive({
        # Diagnostics is never driven by provisional data: while a run
        # streams, return the last committed value (no dependency on the
        # partials, so it does not recompute per partial). Kept lazily rather
        # than by an eager observer so the table is only built when the
        # Diagnostics tab asks for it. NULL if nothing was committed yet.
        if (.is_provisional()) {
          return(ts_committed$value)
        }
        if (is.null(hist_sim())) ts_committed$value <- NULL
        req(timeseries_curves_rv())
        ens_q <- if (!identical(input$ensemble_band %||% "none", "none")) {
          resolve_band_q(input$ensemble_band %||% "none")
        } else {
          c(lo = 0.5, hi = 0.5)
        }
        out <- list(
          tbl     = timeseries_curves_rv(),
          x_label = metric_axis_label(.selected_method(), results_source()$so),
          ens_q   = ens_q
        )
        ts_committed$value <- out
        out
      })
    )
  })
}
