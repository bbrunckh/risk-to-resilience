# Model and covariate selection ----
# Pure functions for model type and covariate selection logic.
# Used by mod_1_06_model_server(). Stateless and testable without Shiny.


# Policy scenario definitions ----

#' Policy scenario definitions
#'
#' `POLICY_DEFINITIONS` (the lever table of a data directory without policy
#' metadata) and `policy_definitions()` (from a variable list) live in
#' `fct_policy_registry.R`. Each entry is keyed by lever code and holds a
#' human-readable label and the variables the policy requires in the model.
#'
#' @name policy_definitions_doc
#' @noRd
NULL


#' Apply derived columns (`POLICY_DERIVED`) to a survey data frame
#'
#' Adds the derived columns to `df`. Currently supports `combine = "and_one"`, a
#' three-valued AND: 1 if all sources are 1, 0 if any source is 0 (even when
#' another is NA), and NA otherwise. Skips a derivation when its sources are not
#' all present in `df`, and when the column already exists: a data directory
#' that publishes the variable keeps its own values.
#'
#' @param df A data frame (typically the merged survey data).
#'
#' @return `df` with derived policy columns added.
#' @export
apply_policy_derivations <- function(df) {
  for (vname in names(POLICY_DERIVED)) {
    spec <- POLICY_DERIVED[[vname]]
    if (vname %in% names(df)) next
    if (!all(spec$sources %in% names(df))) next
    mat <- as.matrix(df[, spec$sources, drop = FALSE])
    if (identical(spec$combine, "and_one")) {
      any_zero <- rowSums(mat == 0, na.rm = TRUE) > 0
      all_one <- rowSums(mat == 1, na.rm = TRUE) == ncol(mat)
      df[[vname]] <- ifelse(any_zero, 0L, ifelse(all_one, 1L, NA_integer_))
    }
  }
  df
}


#' Add metadata rows for derived policy variables to `variable_list`
#'
#' Adds a row for each derived variable defined in `POLICY_DERIVED` so
#' that the rest of the app (labels, role-based filtering) can find it.
#' Existing rows with the same `name` are left unchanged, so a data directory
#' that publishes the variable keeps its own row.
#'
#' @param vl A data frame with at least `name` and `label` columns.
#'
#' @return `vl` extended with derived-variable rows.
#' @export
add_derived_policy_vars_to_vl <- function(vl) {
  if (is.null(vl) || nrow(vl) == 0) {
    return(vl)
  }
  for (vname in names(POLICY_DERIVED)) {
    if (vname %in% vl$name) next
    spec <- POLICY_DERIVED[[vname]]
    role <- spec$role %||% "hh"
    new_row <- vl[NA_integer_, , drop = FALSE][1, , drop = FALSE]
    new_row$name <- vname
    if ("label" %in% names(new_row)) new_row$label <- spec$label %||% vname
    # Flags of the sources: a derived row is a binary household variable
    # like them, so role checks (`%in% 1L`) do not see NA.
    src <- vl[vl$name %in% spec$sources, , drop = FALSE]
    all_src <- nrow(src) == length(spec$sources)
    for (flag in c("id", "outcome", "hazard", "ind", "hh", "firm", "area", "interact", "fe")) {
      if (flag %in% names(new_row)) new_row[[flag]] <- 0L
    }
    if ("interact" %in% names(new_row)) {
      new_row$interact <- as.integer(all_src && all(src$interact %in% 1L))
    }
    if ("type" %in% names(new_row)) {
      types <- unique(src$type)
      new_row$type <- if (all_src && length(types) == 1L && !is.na(types)) types else "logical"
    }
    if (role %in% names(new_row)) new_row[[role]] <- 1L
    # A list that marks levers also marks the derived one.
    if ("policy" %in% names(new_row) && any(nzchar(.policy_text(vl[["policy"]], nrow(vl))))) {
      new_row$policy <- spec$policy %||% ""
      if ("policy_group" %in% names(new_row)) new_row$policy_group <- spec$policy_group %||% ""
    }
    vl <- rbind(vl, new_row)
  }
  vl
}

#' Named vector of policy choices for selectize input
#' @param variable_list Variable list (or `NULL`): its `policy` column decides
#'   the levers, see `policy_registry()`.
#' @return Named character vector (display label -> lever code).
#' @export
get_policy_choices <- function(variable_list = NULL) {
  defs <- policy_definitions(variable_list)
  setNames(names(defs), vapply(defs, `[[`, character(1), "label"))
}

#' Determine which variables are locked by selected policies, split by level
#'
#' Returns a level-based list so that policy availability can be checked against
#' the current analysis level (ind/hh/firm/area). The locked variables are added
#' to the model as interaction terms with the weather hazard.
#'
#' @param selected_policies Character vector of lever codes (e.g.
#'   \code{"electricity"}); earlier letter keys (\code{"A"}) are accepted.
#' @param variable_list     Data frame with \code{name} column and role flags
#'   \code{ind}, \code{hh}, \code{firm}, \code{area}.
#'
#' @return Named list with elements \code{ind}, \code{hh}, \code{firm},
#'   \code{area}, each a character vector of locked variable names.
#' @export
get_policy_locked_vars <- function(selected_policies, variable_list = NULL) {
  empty <- list(
    ind = character(0), hh = character(0),
    firm = character(0), area = character(0)
  )
  if (is.null(selected_policies) || length(selected_policies) == 0) {
    return(empty)
  }
  if (is.null(variable_list) || nrow(variable_list) == 0) {
    return(empty)
  }

  defs <- policy_definitions(variable_list)
  all_vars <- unique(unlist(lapply(policy_normalise_keys(selected_policies), function(k) {
    defs[[k]]$vars
  })))

  vl <- variable_list[variable_list$name %in% all_vars, , drop = FALSE]
  if (nrow(vl) == 0) {
    return(empty)
  }

  get_role <- function(role) {
    v <- vl[[role]]
    if (is.null(v)) {
      return(character(0))
    }
    vl$name[!is.na(v) & v == 1L]
  }
  list(
    ind = get_role("ind"), hh = get_role("hh"),
    firm = get_role("firm"), area = get_role("area")
  )
}


# Variable list filtering ----

#' Filter a variable list to columns present and sufficiently non-missing in df
#'
#' A variable is considered valid when it exists as a column in `df` and at
#' least `min_complete` proportion of its values are non-missing. When
#' `group_cols` are present in `df`, completeness is evaluated within each
#' group (e.g. each survey-year combination) and a variable must meet the
#' threshold in **every** group to be retained. When `outcome` is supplied,
#' completeness is computed only over rows where the outcome is non-missing -
#' i.e. the rows that would actually be used in the model.
#'
#' @param df            A data frame (e.g. `survey_weather()`).
#' @param variable_list A data frame with at minimum a `name` column.
#' @param min_complete  Numeric in \[0, 1\]. Minimum proportion non-missing
#'   required in each group (or overall when no group columns are found).
#'   Default `0.5`.
#' @param group_cols    Character vector of column names used to define groups
#'   for per-group completeness checks. Only columns actually present in `df`
#'   are used. Default `c("code", "year", "survname")`.
#' @param outcome       Scalar character. Name of the outcome column in `df`.
#'   When non-`NULL` and present in `df`, only rows where the outcome is
#'   non-missing are used for completeness calculations. Default `NULL`.
#' @param row_rules     Optional named list of functions, one per variable
#'   that is only defined for part of the sample (for example employment for
#'   people of working age). Each takes `df` and returns a logical vector of
#'   the rows the variable must be complete on; its completeness is checked
#'   on those rows only. A rule that cannot be evaluated (a column it needs is
#'   missing) leaves the variable on the usual all-rows check. Default `NULL`.
#'
#' @return The filtered `variable_list`.
#'
#' @export
filter_valid_vars <- function(df, variable_list, min_complete = 0.5,
                              group_cols = c("code", "year", "survname"),
                              outcome = NULL, row_rules = NULL) {
  if (is.null(df) || is.null(variable_list)) {
    return(variable_list)
  }

  if (!is.null(outcome) && outcome %in% names(df)) {
    df <- df[!is.na(df[[outcome]]), , drop = FALSE]
  }

  group_cols <- intersect(group_cols, names(df))

  if (length(group_cols) == 0) {
    valid <- names(df)[colMeans(!is.na(df)) >= min_complete]
  } else if (nrow(df) == 0) {
    # No rows: completeness is vacuously met in every group, matching the
    # per-group scan this replaces (min over no groups).
    valid <- c(group_cols, setdiff(names(df), group_cols))
  } else {
    data_cols <- setdiff(names(df), group_cols)
    group_key <- do.call(paste, c(df[group_cols], sep = "\x01"))
    groups <- unique(group_key)

    # One grouped pass over the frame (C-level rowsum) instead of one full
    # scan per group: completeness matrix, rows = data columns, cols = groups
    # in first-appearance order (PERF-08).
    grp_idx <- match(group_key, groups)
    n_g <- tabulate(grp_idx, nbins = length(groups))
    notna <- !is.na(df[data_cols])
    storage.mode(notna) <- "double"
    sums <- rowsum(notna, grp_idx, reorder = FALSE)
    comp_mat <- t(sums / n_g)

    # a column is valid only if it meets the threshold in every group
    min_comp <- if (is.matrix(comp_mat)) apply(comp_mat, 1, min) else comp_mat
    valid <- c(group_cols, data_cols[min_comp >= min_complete])
  }

  # variables defined for part of the sample: complete on that part, in every group
  for (v in intersect(names(row_rules), names(df))) {
    rows <- tryCatch(as.logical(row_rules[[v]](df)), error = function(e) NULL)
    if (is.null(rows) || length(rows) != nrow(df)) next
    rows <- rows %in% TRUE
    key <- if (length(group_cols)) do.call(paste, c(df[group_cols], sep = "\x01")) else rep("", nrow(df))
    comp <- tapply(!is.na(df[[v]][rows]), key[rows], mean)
    # a group with no such rows (or no group at all) cannot show completeness
    ok <- length(comp) > 0L && all(comp >= min_complete) && all(unique(key) %in% names(comp))
    valid <- setdiff(valid, v)
    if (ok) valid <- c(valid, v)
  }

  variable_list[variable_list$name %in% valid, , drop = FALSE]
}


#' Filter a variable list to rows matching a role flag
#'
#' Selects rows where the column named by `role` equals `1`. Supported roles:
#' `"fe"`, `"hh"`, `"ind"`, `"area"`, `"firm"`, `"interact"`.
#'
#' @param variable_list A data frame with a column named by `role`.
#' @param role          Scalar character naming the role column.
#' @param extra_filter  Optional named list of additional column/value
#'   inequality filters (e.g. `list(type = "numeric")` to exclude numeric rows).
#'
#' @return The filtered `variable_list`.
#'
#' @export
filter_vars_by_role <- function(variable_list, role, extra_filter = NULL) {
  if (is.null(variable_list) || nrow(variable_list) == 0) {
    return(variable_list)
  }
  if (!role %in% names(variable_list)) {
    return(variable_list[0L, , drop = FALSE])
  }

  # %in% is NA-safe: a missing role flag must not inject an all-NA row.
  out <- variable_list[variable_list[[role]] %in% 1L, , drop = FALSE]

  if (!is.null(extra_filter)) {
    for (col in names(extra_filter)) {
      if (col %in% names(out)) {
        out <- out[!out[[col]] %in% extra_filter[[col]], , drop = FALSE]
      }
    }
  }

  out
}


# Model type helpers ----

#' Model type choices and radio-button label for a given outcome type
#'
#' @param outcome_type Scalar character. `"logical"` for binary outcomes;
#'   `"numeric"` / `"double"` / `"integer"` for continuous outcomes.
#'
#' @return A named list with:
#'   \describe{
#'     \item{`choices`}{Character vector of model type choices.}
#'     \item{`label`}{Scalar character label for the radio button group.}
#'   }
#'
#' @export
model_type_choices <- function(outcome_type) {
  if (identical(outcome_type, "logical")) {
    list(
      choices = c("Logistic regression", "Linear regression"),
      label   = "Classification model"
    )
  } else {
    list(
      choices = c("Linear regression", "Unconditional quantile regression (RIF)"),
      label   = "Regression model"
    )
  }
}


# Covariate exclusion ----

#' Remove already-selected variables from a candidate variable list
#'
#' Filters out variables already used as the outcome, weather predictors,
#' interaction terms, or fixed effects.
#'
#' @param candidate_vl  Data frame with a `name` column.
#' @param outcome_name  Scalar character. Selected outcome variable name.
#' @param weather_names Character vector. Selected weather variable names.
#' @param interactions  Character vector. Selected interaction variable names.
#' @param fixedeffects  Character vector. Selected fixed effect names.
#'
#' @return `candidate_vl` with excluded rows removed.
#'
#' @export
exclude_selected_vars <- function(candidate_vl,
                                  outcome_name = character(0),
                                  weather_names = character(0),
                                  interactions = character(0),
                                  fixedeffects = character(0)) {
  if (is.null(candidate_vl) || nrow(candidate_vl) == 0) {
    return(candidate_vl)
  }

  exclude <- unique(c(
    outcome_name %||% character(0),
    weather_names %||% character(0),
    interactions %||% character(0),
    fixedeffects %||% character(0)
  ))

  candidate_vl <- candidate_vl[!candidate_vl$name %in% exclude, , drop = FALSE]
  if ("outcome" %in% names(candidate_vl)) {
    candidate_vl <- candidate_vl[is.na(candidate_vl$outcome) | candidate_vl$outcome != 1L, , drop = FALSE]
  }
  candidate_vl
}


# Engine inference ----

#' Infer the fitting engine from the model type
#'
#' Linear and logistic regression default to `"fixest"` (high-dimensional FE
#' via `feols`/`feglm`). Tree-based types map to `"ranger"` or `"xgboost"`
#' respectively.
#'
#' @param model_type Scalar character. E.g. `"Linear regression"`.
#'
#' @return Scalar character engine key matching an `ENGINE_REGISTRY` entry.
#'
#' @export
infer_engine <- function(model_type) {
  switch(model_type %||% "",
    "Linear regression" = "fixest",
    "Logistic regression" = "fixest",
    "Random forest" = "ranger",
    "XGBoost" = "xgboost",
    "Unconditional quantile regression (RIF)" = "rif",
    "fixest" # safe default
  )
}


# Specification assembly ----

#' Assemble the full model selection specification
#'
#' Collects all model configuration inputs into a single named list with
#' `NULL`-safe defaults.
#'
#' @param model_type          Scalar character. E.g. `"Linear regression"`.
#' @param engine              Scalar character. Engine key from `ENGINE_REGISTRY`.
#'   When `NULL` (default), inferred automatically from `model_type` via
#'   `infer_engine()`: linear/logistic -> `"fixest"`, random forest ->
#'   `"ranger"`, XGBoost -> `"xgboost"`.
#' @param interactions        Character vector of interaction variable names.
#' @param interaction_mode    Scalar character. `"saturated"` (default) or
#'   `"pairwise"`. See `fit_model()` for details.
#' @param fixedeffects        Character vector of fixed effect variable names.
#' @param covariate_selection Scalar character. `"User-defined"` or `"Lasso"`.
#' @param ind_covariates      Character vector of individual covariate names.
#' @param hh_covariates       Character vector of household covariate names.
#' @param firm_covariates     Character vector of firm covariate names.
#' @param area_covariates     Character vector of area covariate names.
#' @param cluster             Character vector of clustering variable names for
#'   clustered standard errors (supported by compatible engines).
#' @param lasso_alpha         Numeric in \[0, 1\]. Elastic net mixing parameter
#'   (`1` = Lasso, `0` = Ridge). Default `1`.
#' @param lasso_lambda        Scalar character. Lambda selection rule:
#'   `"lambda.1se"` (default, more regularisation) or `"lambda.min"`.
#' @param lasso_nfolds        Integer. Number of cross-validation folds. Default `10`.
#' @param lasso_standardize   Logical. Whether to standardise predictors before
#'   fitting. Default `TRUE`.
#' @param mi_m                Integer. Number of Lasso selection repetitions
#'   (random CV folds each; the name is historical). Default `5`.
#' @param stability_threshold Numeric in \[0, 1\]. Minimum selection frequency
#'   across repetitions for a variable to be retained. Default `0.5`.
#'
#' @return A named list. All `NULL` inputs are coerced to their defaults.
#'   Lasso fields are always present but only meaningful when
#'   `covariate_selection == "Lasso"`.
#'
#' @export
build_selected_model <- function(model_type = NULL,
                                 engine = NULL,
                                 interactions = NULL,
                                 interaction_mode = NULL,
                                 fixedeffects = NULL,
                                 covariate_selection = NULL,
                                 ind_covariates = NULL,
                                 hh_covariates = NULL,
                                 firm_covariates = NULL,
                                 area_covariates = NULL,
                                 cluster = NULL,
                                 lasso_alpha = NULL,
                                 lasso_lambda = NULL,
                                 lasso_nfolds = NULL,
                                 lasso_standardize = NULL,
                                 mi_m = NULL,
                                 stability_threshold = NULL) {
  chr0 <- character(0)
  list(
    type                = model_type %||% chr0,
    engine              = engine %||% infer_engine(model_type),
    interactions        = interactions %||% chr0,
    interaction_mode    = interaction_mode %||% "pairwise",
    fixedeffects        = fixedeffects %||% chr0,
    covariate_selection = covariate_selection %||% "User-defined",
    ind_covariates      = ind_covariates %||% chr0,
    hh_covariates       = hh_covariates %||% chr0,
    firm_covariates     = firm_covariates %||% chr0,
    area_covariates     = area_covariates %||% chr0,
    cluster             = cluster %||% chr0,
    # Lasso options - only meaningful when covariate_selection == "Lasso"
    lasso_alpha         = lasso_alpha %||% 1,
    lasso_lambda        = lasso_lambda %||% "lambda.1se",
    lasso_nfolds        = lasso_nfolds %||% 10L,
    lasso_standardize   = lasso_standardize %||% TRUE,
    mi_m                = mi_m %||% 5L,
    stability_threshold = stability_threshold %||% 0.5
  )
}
