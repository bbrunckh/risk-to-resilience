# Keep the last (key, value) pair: returns the stored value when `key` repeats,
# otherwise computes, stores and returns it. A failed compute stores nothing.
.memoise_last <- function(cache, key, compute) {
  if (identical(cache$key, key)) {
    return(cache$value)
  }
  value <- compute()
  cache$key <- key
  cache$value <- value
  value
}

#' 1_06_model UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
#' @importFrom glmnet cv.glmnet glmnet
mod_1_06_model_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("model_summary_ui")),
    wellPanel(
      uiOutput(ns("model_selector_ui"))
    ),
    wellPanel(
      uiOutput(ns("policy_ui"))
    ),
    # UI-02: shared flyout block - anchored to its toggle, one-open state,
    # aria-expanded, focus management, Escape to close (see custom.js).
    config_flyout_block(
      ns("model_settings_toggle"),
      "Model settings",
      toggle_label = "Model settings",
      uiOutput(ns("model_specs_ui"))
    ),
    shiny::uiOutput(ns("run_prereq_ui")),
    shiny::actionButton(ns("run_model"), "Run model",
      class = "btn-primary", style = "width: 100%;"
    )
  )
}

#' 1_06_model Server Functions
#'
#' @param id               Module id.
#' @param variable_list    Reactive data frame of variable metadata.
#' @param analysis_unit   Reactive scalar with level of analysis (ind/hh/firm).
#' @param selected_outcome Reactive data frame row for the selected outcome.
#' @param selected_weather Reactive data frame of selected weather specs.
#' @param survey_weather   Reactive data frame of merged survey + weather data.
#' @param run_trigger      Optional reactive trigger for a programmatic fit.
#'
#' @noRd
mod_1_06_model_server <- function(id,
                                  variable_list,
                                  analysis_unit,
                                  selected_outcome,
                                  selected_weather,
                                  survey_weather,
                                  run_trigger = shiny::reactive(NULL)) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    show_level <- function(role) {
      if (identical(role, "area")) {
        return(TRUE)
      }
      unit <- if (is.null(analysis_unit)) NULL else analysis_unit()
      if (is.null(unit) || length(unit) == 0) {
        return(TRUE)
      }
      identical(unit, role)
    }

    # Valid variable list (present + >= 90 % non-missing) ----

    valid_vl <- reactive({
      req(survey_weather(), variable_list())
      wise_valid_vars(survey_weather(), variable_list(), selected_outcome()$name)
    })

    # Role-filtered variable lists ----

    fe_vars <- reactive(filter_vars_by_role(valid_vl(), "fe"))
    hh_vars <- reactive(filter_vars_by_role(valid_vl(), "hh"))
    ind_vars <- reactive(filter_vars_by_role(valid_vl(), "ind"))
    area_vars <- reactive(filter_vars_by_role(valid_vl(), "area"))
    firm_vars <- reactive(filter_vars_by_role(valid_vl(), "firm"))

    # Interaction vars: flagged for interaction AND not numeric (avoids
    # overfitting - numeric vars should be binned first). Outcome-flagged
    # variables qualify (for example the labour status variables), except the
    # outcome of this run.
    interact_vars <- reactive({
      x <- filter_vars_by_role(valid_vl(), "interact", extra_filter = list(type = "numeric"))
      x[!x$name %in% selected_outcome()$name, , drop = FALSE]
    })

    # Settings summary banner ----

    output$model_summary_ui <- renderUI({
      so <- tryCatch(selected_outcome(), error = function(e) NULL)
      sw <- tryCatch(selected_weather(), error = function(e) NULL)
      if (is.null(so) || is.null(sw) || nrow(sw) == 0) {
        return(NULL)
      }

      # Map variable names to labels via the full variable list
      vl <- tryCatch(variable_list(), error = function(e) NULL)
      to_labels <- function(nms) {
        if (is.null(nms) || length(nms) == 0) {
          return(NULL)
        }
        vapply(nms, function(v) {
          l <- if (!is.null(vl)) vl$label[vl$name == v] else character(0)
          if (length(l) > 0 && !is.na(l[1]) && nzchar(l[1])) l[1] else v
        }, character(1))
      }

      # Fall back to the rendered inputs' defaults before they register
      model_txt <- input$model_type %||%
        model_type_choices(so$type)$choices[1]
      cov_txt <- input$covariates %||% "User-defined"
      model_row_spec <- list(
        type = model_txt,
        interactions = input$interactions %||% "urban",
        interaction_mode = "pairwise",
        fixedeffects = input$fixedeffects %||% c("year", "gaul1_code"),
        hh_covariates = input$hhcov %||% character(0),
        area_covariates = input$areacov %||% character(0),
        ind_covariates = input$indcov %||% character(0),
        firm_covariates = input$firmcov %||% character(0),
        covariate_selection = cov_txt
      )
      model_row_spec$hh_covariates <- input$hhcov %||% character(0)
      model_row_spec$area_covariates <- input$areacov %||% character(0)
      model_row_spec$ind_covariates <- input$indcov %||% character(0)
      model_row_spec$firm_covariates <- input$firmcov %||% character(0)

      selection_summary_card(
        title = shiny::tags$span(class = "model-summary-title", model_txt),
        badge = cov_txt,
        rows = model_card_rows(
          model_row_spec,
          label_fun = function(v) to_labels(v)[1],
          outcome_label = so$label,
          weather_labels = as.character(sw$label),
          include_model_type = FALSE
        ),
        compact = TRUE
      )
    })


    # Model type selector ----

    output$model_selector_ui <- renderUI({
      # CR-A11Y-03: themed amber warning with an icon, not inline red alone.
      if (is.null(selected_outcome()) || !length(selected_outcome())) {
        return(no_data_warning(
          "Select an outcome variable to choose model type."
        ))
      }
      if (is.null(survey_weather()) || !nrow(as.data.frame(survey_weather()))) {
        return(no_data_warning(
          "Load survey and weather data to select model type."
        ))
      }

      mc <- model_type_choices(selected_outcome()$type)
      pill_toggle(
        inputId  = ns("model_type"),
        label    = mc$label,
        choices  = mc$choices,
        layout   = "vertical"
      )
    })

    # Policy scenarios toggle ----

    output$policy_ui <- renderUI({
      req(input$model_type)

      vl <- valid_vl()
      defs <- policy_definitions(vl)
      choices <- get_policy_choices(vl)
      avail <- if (!is.null(vl) && nrow(vl) > 0) {
        all_policy_vars <- unique(unlist(lapply(defs, `[[`, "vars")))
        present <- intersect(all_policy_vars, vl$name)
        choices[vapply(choices, function(k) {
          any(defs[[k]]$vars %in% present)
        }, logical(1))]
      } else {
        character(0)
      }

      if (length(avail) == 0) {
        return(shiny::helpText(
          "No policy-relevant variables are available in the current data.",
          style = "font-size: 12px;"
        ))
      }

      tagList(
        shiny::selectizeInput(
          ns("selected_policies"),
          label    = "Policy scenario",
          choices  = avail,
          selected = NULL,
          multiple = TRUE,
          options  = list(maxItems = 1, placeholder = "Select policy scenario")
        ),
        uiOutput(ns("policy_locked_info"))
      )
    })

    output$policy_locked_info <- renderUI({
      locked <- policy_locked()
      all_locked <- unique(c(locked$ind, locked$hh, locked$firm, locked$area))
      if (length(all_locked) == 0) {
        return(NULL)
      }

      vl <- valid_vl()
      items <- lapply(all_locked, function(v) {
        lbl <- if (!is.null(vl) && v %in% vl$name) {
          vl$label[vl$name == v][1]
        } else {
          v
        }
        lvl <- ""
        for (role in c("ind", "hh", "firm", "area")) {
          if (v %in% locked[[role]]) {
            lvl <- switch(role,
              ind = "Individual",
              hh = "Household",
              firm = "Firm",
              area = "Area"
            )
            break
          }
        }
        tags$li(paste0(lbl, " (", lvl, ")"))
      })

      tagList(
        tags$small(
          class = "text-muted",
          "Variables interacted with weather"
        ),
        do.call(tags$ul, c(items, list(style = "font-size: 12px;")))
      )
    })

    # Reactive: locked vars by level from selected policies
    policy_locked <- reactive({
      get_policy_locked_vars(input$selected_policies, valid_vl())
    })

    # Enforce locked vars in the interactions selectize
    observe({
      locked <- policy_locked()
      all_locked <- unique(c(locked$ind, locked$hh, locked$firm, locked$area))
      if (length(all_locked) > 0) {
        current <- input$interactions
        if (!all(all_locked %in% current)) {
          shiny::updateSelectizeInput(
            session, "interactions",
            selected = unique(c(current, all_locked))
          )
        }
      }
    })

    # Model specification panel ----

    output$model_specs_ui <- renderUI({
      req(input$model_type)

      ixn <- interact_vars()
      fe <- fe_vars()

      tagList(
        # Interaction with weather hazard
        {
          locked <- policy_locked()
          all_locked <- unique(c(locked$ind, locked$hh, locked$firm, locked$area))
          has_policy <- length(all_locked) > 0

          if (has_policy) {
            vl_all <- valid_vl()
            choices_locked <- stats::setNames(all_locked, vapply(
              all_locked, function(v) {
                l <- if (!is.null(vl_all)) vl_all$label[vl_all$name == v]
                if (length(l) > 0) l[1] else v
              }, character(1)
            ))
            tagList(
              # custom.js locks the selectize inside .wise-lock-selectize once it
              # is initialised (no inline script)
              tags$div(
                class = "wise-lock-selectize",
                shiny::selectizeInput(
                  ns("interactions"),
                  label = shiny::tagList("Interaction with ", wise_math("Haz_{kt}")),
                  choices = choices_locked,
                  selected = all_locked,
                  multiple = TRUE,
                  options = list(
                    maxItems = length(all_locked),
                    plugins  = list("remove_button")
                  )
                )
              ),
              tags$small(
                class = "text-muted",
                style = "display:block;margin-top:-10px;margin-bottom:8px;",
                "Set by the selected policy scenario."
              )
            )
          } else if (nrow(ixn) > 0) {
            # INT-01: keep the user's interaction selection across rebuilds.
            prev_ixn <- shiny::isolate(input$interactions)
            shiny::selectizeInput(
              ns("interactions"),
              label = shiny::tagList("Interactions with ", wise_math("Haz_{kt}")),
              choices = setNames(ixn$name, ixn$label),
              selected = .restore_selection(prev_ixn, ixn$name,
                fallback = if ("urban" %in% ixn$name) "urban" else NULL
              ),
              multiple = TRUE,
              options = list(
                maxItems = 1,
                placeholder = "Select interaction variable"
              )
            )
          } else {
            shiny::helpText("No interaction variables available.",
              style = "font-size: 12px;"
            )
          }
        },

        # Fixed effects
        if (nrow(fe) > 0) {
          # INT-01: keep the user's fixed-effect selection across rebuilds.
          prev_fe <- shiny::isolate(input$fixedeffects)
          shiny::selectizeInput(
            ns("fixedeffects"),
            label = "Fixed effects",
            choices = setNames(fe$name, fe$label),
            selected = .restore_selection(prev_fe, fe$name,
              fallback = wise_default_fixed_effects(fe$name)
            ),
            multiple = TRUE,
            options = list(placeholder = "Select (several) fixed effects")
          )
        } else {
          shiny::helpText("No fixed effect variables available.",
            style = "font-size: 12px;"
          )
        },
        hr(),

        # Covariate selection method
        pill_toggle(
          ns("covariates"),
          label = shiny::tagList(
            "Covariate selection",
            info_popover(
              title = "Lasso covariate selection",
              shiny::p(
                "Lasso selects from all available covariates except weather,",
                "interactions, and fixed effects."
              )
            )
          ),
          choices = c("User-defined", "Lasso"),
          selected = "User-defined"
        ),
        uiOutput(ns("covariate_inputs"))
      )
    })

    # Covariate inputs ----

    output$covariate_inputs <- renderUI({
      req(input$covariates)

      make_choice_labels <- function(df) {
        if (is.null(df) || nrow(df) == 0) {
          return(stats::setNames(character(0), character(0)))
        }
        nm <- df$name
        if (is.null(nm)) {
          return(stats::setNames(character(0), character(0)))
        }
        lbl <- if ("label" %in% names(df)) df$label else nm
        lbl <- ifelse(is.na(lbl) | !nzchar(lbl), nm, lbl)
        keep <- !is.na(nm) & nzchar(nm)
        stats::setNames(nm[keep], lbl[keep])
      }

      # USER-DEFINED COVARIATES ----
      if (input$covariates == "User-defined") {
        ind <- exclude_selected_vars(
          ind_vars(),
          outcome_name = selected_outcome()$name,
          weather_names = selected_weather()$name,
          interactions = input$interactions,
          fixedeffects = input$fixedeffects
        )
        hh <- exclude_selected_vars(
          hh_vars(),
          outcome_name = selected_outcome()$name,
          weather_names = selected_weather()$name,
          interactions = input$interactions,
          fixedeffects = input$fixedeffects
        )
        firm <- exclude_selected_vars(
          firm_vars(),
          outcome_name = selected_outcome()$name,
          weather_names = selected_weather()$name,
          interactions = input$interactions,
          fixedeffects = input$fixedeffects
        )
        area <- exclude_selected_vars(
          area_vars(),
          outcome_name = selected_outcome()$name,
          weather_names = selected_weather()$name,
          interactions = input$interactions,
          fixedeffects = input$fixedeffects
        )

        # The covariate panel re-renders whenever outcome/weather/interaction/
        # fixed-effect choices change; restore each level's previous selection
        # so those rebuilds stop wiping the user's picks (INT-01).
        prev_ind <- shiny::isolate(input$indcov)
        prev_hh <- shiny::isolate(input$hhcov)
        prev_firm <- shiny::isolate(input$firmcov)
        prev_area <- shiny::isolate(input$areacov)

        tagList(
          # Individual-level covariates
          if (show_level("ind") && nrow(ind) > 0) {
            shiny::selectizeInput(
              ns("indcov"),
              label    = shiny::tagList("Individual characteristics ", wise_math("X_{ijt}")),
              choices  = make_choice_labels(ind),
              selected = .restore_selection(prev_ind, ind$name, fallback = NULL),
              multiple = TRUE,
              options  = list(placeholder = "Select individual covariates")
            )
          },

          # Household-level covariates
          if (show_level("hh") && nrow(hh) > 0) {
            shiny::selectizeInput(
              ns("hhcov"),
              label    = shiny::tagList("Household characteristics ", wise_math("X_{ijt}")),
              choices  = make_choice_labels(hh),
              selected = .restore_selection(prev_hh, hh$name, fallback = NULL),
              multiple = TRUE,
              options  = list(placeholder = "Select household covariates")
            )
          },

          # Firm-level covariates
          if (show_level("firm") && nrow(firm) > 0) {
            shiny::selectizeInput(
              ns("firmcov"),
              label    = "Firm characteristics",
              choices  = make_choice_labels(firm),
              selected = .restore_selection(prev_firm, firm$name, fallback = NULL),
              multiple = TRUE,
              options  = list(placeholder = "Select firm covariates")
            )
          },

          # Area-level covariates
          if (show_level("area") && nrow(area) > 0) {
            shiny::selectizeInput(
              ns("areacov"),
              label    = shiny::tagList("Area characteristics ", wise_math("E_{jt}")),
              choices  = make_choice_labels(area),
              selected = .restore_selection(prev_area, area$name, fallback = NULL),
              multiple = TRUE,
              options  = list(placeholder = "Select area covariates")
            )
          }
        )
      } else if (input$covariates == "Lasso") {
        tagList(
          shiny::tags$details(
            class = "lasso-disclosure",
            shiny::tags$summary("Forced inclusion / exclusion"),
            uiOutput(ns("lasso_force_ui"))
          ),
          shiny::tags$details(
            class = "lasso-disclosure",
            shiny::tags$summary("Advanced settings"),
            uiOutput(ns("lasso_advanced_ui"))
          )
        )
      }
    })

    # UI-42: both panels live inside the "Model settings" flyout, which is a
    # conditionalPanel - hidden outputs are suspended by default, so the
    # interaction / fixed-effect / covariate inputs (and their defaults) never
    # existed until the user opened the flyout, and "Run model" silently
    # no-opped on `req(input$covariates)` until they did. Render them eagerly;
    # the flyout still controls visibility.
    lapply(c(
      "model_selector_ui", "policy_ui", "model_specs_ui",
      "covariate_inputs"
    ), function(out_id) {
      shiny::outputOptions(output, out_id, suspendWhenHidden = FALSE)
    })

    # Helper: vars at a given level (ind/hh/firm/area) from valid_vl
    .vars_at_level <- function(role) {
      vl <- valid_vl()
      if (is.null(vl) || !role %in% names(vl)) {
        return(vl[0L, , drop = FALSE])
      }
      vl[!is.na(vl[[role]]) & vl[[role]] == 1L, , drop = FALSE]
    }

    # Helper: per-level named choices vector (label -> name), excluding
    # outcome and weather variables.
    .level_choices <- function(role) {
      vl_role <- .vars_at_level(role)
      if (nrow(vl_role) == 0) {
        return(stats::setNames(character(0), character(0)))
      }
      out_y <- if (!is.null(selected_outcome())) selected_outcome()$name else character(0)
      out_w <- if (!is.null(selected_weather())) selected_weather()$name else character(0)
      keep <- !vl_role$name %in% c(out_y, out_w)
      if ("outcome" %in% names(vl_role)) {
        keep <- keep & (is.na(vl_role$outcome) | vl_role$outcome != 1L)
      }
      stats::setNames(vl_role$name[keep], vl_role$label[keep])
    }

    output$lasso_force_ui <- renderUI({
      req(input$covariates == "Lasso")

      already_in <- unique(c(input$interactions, input$fixedeffects))

      level_block <- function(role, role_label) {
        if (!show_level(role)) {
          return(NULL)
        }
        choices <- .level_choices(role)
        if (length(choices) == 0) {
          return(NULL)
        }

        default_in <- intersect(already_in, choices)
        # INT-01: restore prior force selections when the panel re-renders.
        prev_in <- shiny::isolate(input[[paste0("force_in_", role)]])
        prev_out <- shiny::isolate(input[[paste0("force_out_", role)]])
        in_choices <- choices[!choices %in% prev_out]
        out_choices <- choices[!choices %in% prev_in]

        tagList(
          tags$strong(role_label),
          shiny::selectizeInput(
            ns(paste0("force_in_", role)),
            label = "Force include",
            choices = in_choices,
            selected = .restore_selection(prev_in, in_choices,
              fallback = if (length(default_in) > 0) default_in else NULL
            ),
            multiple = TRUE,
            options = list(placeholder = "Select covariates to force in")
          ),
          shiny::selectizeInput(
            ns(paste0("force_out_", role)),
            label    = "Force exclude",
            choices  = out_choices,
            selected = .restore_selection(prev_out, out_choices, fallback = NULL),
            multiple = TRUE,
            options  = list(placeholder = "Select covariates to force out")
          ),
          tags$hr(style = "margin: 8px 0;")
        )
      }

      tagList(
        tags$small(
          class = "text-muted",
          style = "display:block;margin-bottom:6px;"
        ),
        level_block("ind", "Individual covariates"),
        level_block("hh", "Household covariates"),
        level_block("firm", "Firm covariates"),
        level_block("area", "Area covariates")
      )
    })

    # Mutual exclusion between force-include and force-exclude ----
    # When a var is selected as force-include, remove it from force-exclude
    # choices, and vice versa. Target inputs are isolated and repeated target
    # states are skipped, so an update cannot invalidate its own observer.
    lapply(c("ind", "hh", "firm", "area"), function(role) {
      in_id <- paste0("force_in_", role)
      out_id <- paste0("force_out_", role)
      sent <- new.env(parent = emptyenv())
      sent$include <- sent$exclude <- NULL

      observe({
        if (!show_level(role)) {
          return()
        }
        chosen_in <- input[[in_id]]
        choices <- .level_choices(role)
        if (length(choices) == 0) {
          return()
        }
        out_choices <- choices[!choices %in% chosen_in]
        target <- list(
          choices  = out_choices,
          selected = intersect(shiny::isolate(input[[out_id]]), out_choices)
        )
        if (!identical(target, sent$exclude)) {
          shiny::updateSelectizeInput(session, out_id,
            choices = target$choices,
            selected = target$selected
          )
          sent$exclude <- target
        }
      })

      observe({
        if (!show_level(role)) {
          return()
        }
        chosen_out <- input[[out_id]]
        choices <- .level_choices(role)
        if (length(choices) == 0) {
          return()
        }
        in_choices <- choices[!choices %in% chosen_out]
        target <- list(
          choices  = in_choices,
          selected = intersect(shiny::isolate(input[[in_id]]), in_choices)
        )
        if (!identical(target, sent$include)) {
          shiny::updateSelectizeInput(session, in_id,
            choices = target$choices,
            selected = target$selected
          )
          sent$include <- target
        }
      })
    })

    # Reactive: collected forced-in / forced-out by level
    lasso_forced <- reactive({
      list(
        ind = list(
          inc = input$force_in_ind %||% character(0),
          exc = input$force_out_ind %||% character(0)
        ),
        hh = list(
          inc = input$force_in_hh %||% character(0),
          exc = input$force_out_hh %||% character(0)
        ),
        firm = list(
          inc = input$force_in_firm %||% character(0),
          exc = input$force_out_firm %||% character(0)
        ),
        area = list(
          inc = input$force_in_area %||% character(0),
          exc = input$force_out_area %||% character(0)
        )
      )
    })

    output$lasso_advanced_ui <- renderUI({
      req(input$covariates == "Lasso")

      # INT-01: the panel is destroyed/recreated on every toggle; restore the
      # previous settings so closing and reopening does not reset them.
      prev <- function(id) shiny::isolate(input[[id]])
      dflt <- wise_default_lasso()

      tagList(
        sliderInput(
          ns("lasso_alpha"),
          "Elastic Net Mixing (alpha)",
          min = 0,
          max = 1,
          value = .restore_numeric(prev("lasso_alpha"), 0, 1, fallback = dflt$alpha),
          step = 0.1
        ),
        shiny::selectizeInput(
          ns("lasso_interactions"),
          label = "Lambda choice",
          choices = c("lambda.1se", "lambda.min"),
          selected = .restore_selection(prev("lasso_interactions"),
            c("lambda.1se", "lambda.min"),
            fallback = dflt$lambda
          ),
          multiple = FALSE,
          options = list(
            maxItems    = 1,
            placeholder = "Select lambda choice"
          )
        ),
        sliderInput(
          ns("lasso_nfolds"),
          "Cross-validation folds",
          min = 5,
          max = 20,
          value = .restore_numeric(prev("lasso_nfolds"), 5, 20, fallback = dflt$nfolds),
          step = 1
        ),
        pill_toggle(
          ns("lasso_standardize"),
          label = "Standardize predictors",
          choices = c("Standardize", "Do not standardize"),
          selected = .restore_selection(prev("lasso_standardize"),
            c("Standardize", "Do not standardize"),
            fallback = "Standardize"
          )
        ),
        sliderInput(
          ns("mi_m"),
          "Number of selection repetitions",
          min = 1,
          max = 20,
          value = .restore_numeric(prev("mi_m"), 1, 20, fallback = dflt$mi_m),
          step = 1
        ),
        sliderInput(
          ns("stability_threshold"),
          "Selection frequency threshold",
          min = 0.1,
          max = 1,
          value = .restore_numeric(prev("stability_threshold"), 0.1, 1, fallback = dflt$stability_threshold),
          step = 0.05
        )
      )
    })
    shiny::outputOptions(output, "lasso_force_ui", suspendWhenHidden = FALSE)
    shiny::outputOptions(output, "lasso_advanced_ui", suspendWhenHidden = FALSE)

    # LASSO MODEL ----
    #
    # REACT-16: the Lasso is a *run-time* step, not a selection-time one.
    # It used to be an eventReactive that `selected_model()` pulled on, which
    # meant merely switching "Covariate selection" to Lasso invalidated
    # `selected_model()`, and the first downstream reader (the stale-tracking
    # observers in mod_1_07) forced the fit right there in the sidebar. The
    # result is now held in a plain reactiveVal that only the run-button
    # observer below writes, so reading the model spec can never start a fit.
    lasso_store <- reactiveVal(NULL)
    lasso_cache <- new.env(parent = emptyenv())

    # Selecting a different covariate method, or changing anything the
    # selection depends on, drops the stored result: a Lasso set chosen for
    # another specification must not silently carry over into the next fit.
    observe({
      input$covariates
      input$interactions
      input$fixedeffects
      selected_outcome()
      selected_weather()
      lasso_forced()
      lasso_store(NULL)
    })

    .compute_lasso <- function() {
      withProgress(message = "Running Lasso...", value = 0, {
        incProgress(0.05, detail = "Preparing inputs")

        df <- prepare_outcome_df(as.data.frame(survey_weather()), selected_outcome())

        weather_vars <- as.character(selected_weather()$name)
        fe_vars <- as.character(input$fixedeffects)
        int_vars <- as.character(input$interactions)

        settings <- wise_lasso_settings(
          alpha = input$lasso_alpha, lambda = input$lasso_interactions,
          nfolds = input$lasso_nfolds, standardize = input$lasso_standardize,
          mi_m = input$mi_m,
          stability_threshold = input$stability_threshold
        )
        seed_val <- wise_current_seed()

        incProgress(0.15, detail = "Running MI + LASSO")

        # Forced exclusion: drop from candidate pool before Lasso
        forced <- lasso_forced()
        force_exc <- unique(c(
          forced$ind$exc, forced$hh$exc, forced$firm$exc, forced$area$exc
        ))
        vl_for_lasso <- wise_lasso_candidates(valid_vl(), force_exc)

        # R2-PERF-11: repeat clicks with identical inputs reuse the last
        # selection (about 3 s on BFA) instead of refitting.
        lasso_key <- rlang::hash(list(
          df, selected_outcome(), weather_vars, fe_vars, int_vars, vl_for_lasso,
          input$model_type, settings, seed_val
        ))
        .memoise_last(lasso_cache, lasso_key, function() {
          wise_lasso_selection(
            df = df,
            selected_outcome = selected_outcome(),
            weather_vars = weather_vars,
            fe_vars = fe_vars,
            int_vars = int_vars,
            valid_vl = vl_for_lasso,
            model_type = input$model_type,
            settings = settings,
            seed = seed_val
          )
        })
      })
    }

    # Run the Lasso on the click, before mod_1_07's fit observer reads
    # `selected_model()`. The explicit priority is what orders the two - both
    # observers key off the same button, and flush order between equal
    # priorities is not something to rely on.
    run_event <- shiny::reactiveVal(NULL)
    shiny::observeEvent(input$run_model,
      {
        if (shiny::isTruthy(input$run_model)) {
          run_event(list(source = "manual", value = input$run_model))
        }
      },
      ignoreInit = FALSE,
      ignoreNULL = TRUE
    )
    shiny::observeEvent(run_trigger(),
      {
        ext <- run_trigger()
        if (!is.null(ext)) run_event(list(source = "pipeline", value = ext))
      },
      ignoreInit = FALSE,
      ignoreNULL = TRUE
    )

    observeEvent(run_event(),
      {
        if (!isTRUE(input$covariates == "Lasso")) {
          lasso_store(NULL)
          return(invisible(NULL))
        }
        sw <- tryCatch(survey_weather(), error = function(e) NULL)
        so <- tryCatch(selected_outcome(), error = function(e) NULL)
        wx <- tryCatch(selected_weather(), error = function(e) NULL)
        if (is.null(sw) || is.null(so) || is.null(wx)) {
          showNotification(
            "Lasso needs an outcome, weather variables and loaded data.",
            type = "error", duration = 5
          )
          return(invisible(NULL))
        }
        # REACT-02: one fit at a time
        if (!fit_guard$begin()) {
          return(invisible(NULL))
        }
        on.exit(fit_guard$end(), add = TRUE)
        result <- tryCatch(
          {
            .compute_lasso()
          },
          error = function(e) {
            showNotification(
              wise_user_error(e, "Lasso"),
              type = "error",
              duration = 5
            )
            NULL
          }
        )
        lasso_store(result)
      },
      priority = 100
    )

    # Return API ----

    selected_model <- reactive({
      req(input$model_type)

      # UI-42: the covariate/interaction/fixed-effect controls live inside the
      # "Model settings" flyout. Their inputs are registered eagerly (see the
      # outputOptions calls above), but the spec must still be well-defined on
      # the very first flush, before any of them has reported in - otherwise
      # the model has weather, a default interaction and default fixed effects
      # and still refuses to run. Fall back to the rendered defaults instead
      # of req()-ing on them.
      cov_method <- input$covariates %||% "User-defined"

      # Resolve covariates by role
      covs <- if (cov_method == "Lasso") {
        wise_lasso_covariates(lasso_store()$selected_covariates, valid_vl(), lasso_forced())
      } else {
        list(
          hh = input$hhcov %||% character(0),
          area = input$areacov %||% character(0),
          ind = input$indcov %||% character(0),
          firm = input$firmcov %||% character(0)
        )
      }

      # Policy-locked vars are enforced as interactions
      locked <- policy_locked()
      all_locked <- unique(c(locked$ind, locked$hh, locked$firm, locked$area))
      # UI-42: mirror the defaults `model_specs_ui` renders with, so a spec
      # read before those inputs have reported carries the same interaction
      # and fixed effects the sidebar is showing.
      ixn_sel <- input$interactions %||% {
        ixn <- tryCatch(interact_vars(), error = function(e) NULL)
        if (!is.null(ixn) && "urban" %in% ixn$name) "urban" else character(0)
      }
      fe_sel <- input$fixedeffects %||% {
        fe <- tryCatch(fe_vars(), error = function(e) NULL)
        if (is.null(fe)) {
          character(0)
        } else {
          wise_default_fixed_effects(fe$name)
        }
      }
      interactions <- unique(c(ixn_sel, all_locked))

      # Cluster-robust VCV at the survey-location panel level. Matches
      # COEF_VCOV_SPEC (~loc_id_panel) in fct_simulations.R so that the SEs
      # displayed in Step 1 and the coefficient uncertainty propagated in
      # Step 2 come from one sampling distribution. loc_id_panel is only
      # joined when the H3 files loaded successfully in Survey stats -
      # otherwise fall back to fixest's default VCV.
      sw_cols <- tryCatch(colnames(survey_weather()),
        error = function(e) character(0)
      )

      sm <- wise_selected_model(
        model_type          = input$model_type,
        interactions        = interactions,
        fixed_effects       = fe_sel,
        covariate_selection = cov_method,
        covariates          = covs,
        lasso = list(
          alpha               = input$lasso_alpha,
          lambda              = input$lasso_interactions,
          nfolds              = input$lasso_nfolds,
          standardize         = isTRUE(input$lasso_standardize == "Standardize"),
          mi_m                = input$mi_m,
          stability_threshold = input$stability_threshold
        ),
        cluster             = wise_cluster_var(sw_cols)
      )
      # R2-BUG-11: flag a Lasso spec that has no successful selection behind it
      # (not yet run, or the run failed) so mod_1_07 refuses to fit it instead
      # of fitting the forced-in covariates only under a "Lasso" label. An
      # attribute keeps the spec contents (and so the run signature) unchanged.
      if (identical(cov_method, "Lasso")) {
        attr(sm, "lasso_missing") <- is.null(lasso_store())
      }
      sm
    })

    selected_policies_rv <- reactive({
      input$selected_policies
    })

    # REACT-02: shared busy guard for model fitting (Lasso + fit both key off
    # input$run_model). Exposed so mod_1_07's fit observer honours it too.
    fit_guard <- .busy_guard(session, run_model)

    # Run-button prerequisites (UI-29) ----
    # The fit observers req() on these upstream inputs; surface them before
    # the click instead of letting the button silently no-op.
    run_prereqs_missing <- reactive({
      missing <- character(0)
      # Upstream reactives can throw silent req() errors when nothing is
      # loaded; either way the prerequisite is unmet.
      so <- tryCatch(selected_outcome(), error = function(e) NULL)
      swd <- tryCatch(selected_weather(), error = function(e) NULL)
      svy <- tryCatch(survey_weather(), error = function(e) NULL)
      if (is.null(so) || nrow(as.data.frame(so)) == 0) {
        missing <- c(missing, "an outcome")
      }
      if (is.null(swd) || nrow(as.data.frame(swd)) == 0) {
        missing <- c(missing, "weather variables")
      }
      if (is.null(svy) || nrow(as.data.frame(svy)) == 0) {
        missing <- c(missing, "survey and weather data")
      }
      if (is.null(input$model_type) || !nzchar(input$model_type)) {
        missing <- c(missing, "a model type")
      }
      missing
    })

    output$run_prereq_ui <- renderUI({
      missing <- run_prereqs_missing()
      if (!length(missing)) {
        return(NULL)
      }
      shiny::div(
        class = "alert alert-warning warning-message",
        role = "alert",
        style = "font-size: 13px; margin-bottom: 4px;",
        shiny::tags$b("To run the model, first select "),
        paste(missing, collapse = ", "), "."
      )
    })

    observe({
      shiny::updateActionButton(
        session,
        inputId = "run_model",
        disabled = length(run_prereqs_missing()) > 0
      )
    })

    list(
      selected_model    = selected_model,
      selected_policies = selected_policies_rv,
      run_model         = run_event,
      fit_guard         = fit_guard
    )
  })
}
