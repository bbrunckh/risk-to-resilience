#' 1_02_surveystats UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_1_02_surveystats_ui <- function(id) {
  ns <- NS(id)
  # The `dt-wrap` column style lives in custom.css. It used to be built here
  # as a bare tags$style() that was evaluated and then thrown away - the
  # tagList below is what the function returns - so the rule never reached the
  # page. It now also serves the weather stats tables (fct_weatherstats.R).
  tagList(
    uiOutput(ns("survey_stats_button_ui"))
  )
}

#' 1_02_surveystats Server Functions
#'
#' @param id Module id.
#' @param connection_params Reactive named list of connection parameters.
#' @param variable_list Reactive data frame of variable metadata.
#' @param selected_surveys Reactive data frame of selected surveys (from mod_1_01_sample).
#' @param cpi_ppp Reactive data frame of CPI/PPP deflators.
#' @param tabset_id Character id of the parent tabset panel to append the tab to.
#' @param tabset_session Shiny session for the parent tabset. Defaults to the parent session.
#' @param run_trigger Optional reactive trigger for a programmatic load.
#'
#' @noRd
mod_1_02_surveystats_server <- function(
  id,
  connection_params,
  variable_list,
  selected_surveys,
  cpi_ppp,
  tabset_id,
  tabset_session = NULL,
  analysis_unit = NULL,
  run_trigger = shiny::reactive(NULL)
) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    if (is.null(tabset_session)) {
      tabset_session <- session$parent %||% session
    }

    select_tab <- function(value) {
      if (is.null(tabset_id) || !nzchar(tabset_id)) {
        return(invisible(FALSE))
      }
      try(shiny::updateTabsetPanel(tabset_session, inputId = tabset_id, selected = value), silent = TRUE)
      invisible(TRUE)
    }

    notify <- function(msg, type = "message", duration = 5) {
      shiny::showNotification(msg, type = type, duration = duration)
    }

    # Button (shown once selected_surveys is populated) ----

    output$survey_stats_button_ui <- renderUI({
      req(nrow(selected_surveys()) > 0)
      actionButton(ns("survey_stats"), "Survey stats", class = "btn-primary", style = "width: 100%;")
    })

    shiny::outputOptions(output, "survey_stats_button_ui", suspendWhenHidden = FALSE)

    # REACT-02: double-click guard - one load at a time, button disabled
    # while running.
    load_guard <- .busy_guard(session, survey_stats)

    survey_tab_added <- reactiveVal(FALSE)

    # Data storage ----

    survey_data <- reactiveVal(NULL)
    # INT-08: bumped on every successful survey load; downstream run
    # signatures include it so a reload invalidates fit/sim/policy results
    # even when the selection string is unchanged.
    survey_version <- shiny::reactiveVal(0L)
    # Internal generation for every newly loaded survey frame. Unlike
    # survey_version, this also advances when downstream H3/panel work fails.
    survey_data_generation <- shiny::reactiveVal(0L)
    publish_new_survey_data <- function(value) {
      survey_data(value)
      survey_data_generation(
        shiny::isolate(survey_data_generation()) + 1L
      )
    }
    survey_wave_meta <- shiny::reactive({
      cached_survey_wave_metadata(
        session, shiny::isolate(survey_data()), survey_data_generation()
      )
    })
    # Monthly interview counts for the timing-of-interviews chart: aggregated
    # once per published survey frame and read by the on-screen echarts
    # render and the export figure, so neither re-aggregates on redraws.
    interview_summary <- shiny::reactive({
      summarise_interview_dates(survey_data())
    })
    # Completion generation used by the automatic configuration pipeline.
    # Cached requests count as successful completions; failed requests do not.
    load_done <- shiny::reactiveVal(0L)
    load_status <- shiny::reactiveVal("idle")
    # Per-H3-cell counts and mapped-location count behind the density map,
    # recomputed together for whichever wave the picker is on. The wave-keyed
    # allocation (PERF-43) runs once per load in density_waves(); a toggle
    # re-slices its per-wave cells instead of re-running the grouped passes.
    density_waves <- shiny::reactive({
      cd <- cell_data()
      df <- survey_data()
      if (is.null(cd) || is.null(df)) {
        return(NULL)
      }
      .density_wave_summary(cd$map, df)
    })
    density_cells <- function(wave = "all") {
      dw <- density_waves()
      cd <- cell_data()
      if (is.null(dw) || is.null(cd)) {
        return(NULL)
      }

      cells <- if (identical(wave, "all")) {
        # Pooled selection: row-sum the per-wave cells (same values as one
        # allocation pass over the full mapping, within rounding).
        g_h3 <- collapse::GRP(dw$cells, by = "h3")
        n_units <- collapse::fsum(dw$cells$n_units, g = g_h3, na.rm = TRUE)
        n_units[is.na(n_units)] <- 0
        data.frame(
          h3 = as.character(g_h3$groups$h3),
          n_units = as.numeric(n_units),
          stringsAsFactors = FALSE
        )
      } else {
        d <- dw$cells[dw$cells$wave %in% wave, c("h3", "n_units"), drop = FALSE]
        rownames(d) <- NULL
        d
      }

      # Per-cell bounds ride along for the payload's fit bounds. Only the bbox
      # columns are joined: the browser decodes geometry from cell ids, so the
      # geometry strings never enter the density payload path.
      bbox_cols <- intersect(
        c("h3", "xmin", "ymin", "xmax", "ymax"), names(cd$geom)
      )
      if (length(bbox_cols) > 1L && nrow(cells)) {
        cells <- dplyr::inner_join(
          cd$geom[, bbox_cols, drop = FALSE], cells, by = "h3"
        )
      }

      n_loc <- if (identical(wave, "all")) {
        # A location belongs to exactly one wave, so the pooled count is the
        # sum of the per-wave counts.
        as.integer(sum(dw$n_locations))
      } else {
        as.integer(unname(dw$n_locations[wave]) %||% 0L)
      }

      list(cells = cells, n_locations = n_loc)
    }
    # Cell geometry plus the location-to-cell mapping, shared with the outcome
    # and weather maps so they can merge overlapping locations onto cells.
    cell_data <- reactiveVal(NULL)
    # REACT-03: digest of the last successfully completed load request.
    last_load_sig <- reactiveVal(NULL)
    # PERF-36: bumped whenever a new map dataset lands in cell_data(); the
    # density observer fits the camera only when this changes. The fit must
    # not key on digest(selected_surveys()): that reactive is read inside the
    # observer, so changing the sample picker fired it against the old map
    # and stamped the new selection's key onto stale payloads - the refit
    # after the real load was then skipped and the camera kept the previous
    # sample's extent.
    map_data_version <- shiny::reactiveVal(0L)

    # Shared stats base (PERF-40 / PERF-42) ----
    # Every summary-stats table on the tab summarises the same survey frame;
    # one pass over the union of table variables feeds every table: the
    # grouped collapse for the aggregate (PERF-40) and, since PERF-42, the
    # entire display pipeline (missingness join, labels, N filter, sort,
    # renames, wrapping) so each table render is a row subset of a polished
    # frame. Exports slice the same frame, unrounded.
    # a function of the variable list: levers come from its `policy` column
    policy_vars <- wise_policy_vars

    stats_base <- reactive({
      sd <- survey_data()
      shiny::req(sd)
      vl <- if (is.function(variable_list)) variable_list() else variable_list

      union_vars <- wise_stats_vars(vl, sd)
      if (!length(union_vars)) {
        return(NULL)
      }
      stats_display_base(sd, vl, union_vars)
    })

    # Load and prepare data on button click ----

    survey_stats_event <- shiny::reactiveVal(NULL)
    shiny::observeEvent(input$survey_stats,
      {
        if (shiny::isTruthy(input$survey_stats)) {
          survey_stats_event(list(source = "manual", value = input$survey_stats))
        }
      },
      ignoreInit = FALSE,
      ignoreNULL = TRUE
    )
    shiny::observeEvent(run_trigger(),
      {
        ext <- run_trigger()
        if (!is.null(ext)) survey_stats_event(list(source = "pipeline", value = ext))
      },
      ignoreInit = FALSE,
      ignoreNULL = TRUE
    )

    observeEvent(survey_stats_event(),
      {
        if (!load_guard$begin()) {
          return(invisible(NULL))
        }
        on.exit(load_guard$end(), add = TRUE)
        load_done(load_done() + 1L)
        load_status("running")
        completed <- FALSE
        on.exit(
          {
            if (!completed) load_status("failure")
          },
          add = TRUE
        )
        req(nrow(selected_surveys()) > 0)

        # REACT-03: an identical request to the last completed load is served
        # from state instead of re-running the full I/O pipeline. The signature
        # covers everything this handler consumes; it is stored only when no
        # inner stage warned, so a partially failed load always retries on the
        # next click.
        sig <- digest::digest(list(
          selected_surveys(), connection_params(), variable_list(), cpi_ppp()
        ))
        load_ok <- TRUE
        if (identical(sig, last_load_sig())) {
          showNotification("Survey data is already loaded for this selection.",
            duration = 3, type = "message"
          )
          load_status("success")
          completed <- TRUE
          return(invisible(NULL))
        }

        busy_id <- showNotification("Loading survey data...", duration = NULL, type = "message")
        on.exit(removeNotification(busy_id), add = TRUE)

        # INT-06: drop the previous survey's map/cell state as soon as a reload
        # starts, and on every inner failure below. The hex-map payload
        # observer reacts by sending `clear`, so the previous survey's
        # geography can never outlive its microdata - a failure now leaves a
        # blank map instead of a misleading one.
        cell_data(NULL)

        ss <- selected_surveys()

        df <- tryCatch(
          load_survey_frame(ss, connection_params()),
          error = function(e) {
            notify(wise_user_error(e, "Loading survey data"), type = "error", duration = 8)
            NULL
          }
        )

        req(!is.null(df))

        df <- prepare_survey_data(df, variable_list(), cpi_ppp())
        # CR-BUG-16: report records the LCU -> PPP join could not convert.
        n_no_ppp <- survey_n_no_deflator(df, variable_list())
        if (n_no_ppp > 0L) {
          notify(sprintf(
            "%d of %d survey records have no CPI/PPP deflator, so their currency values are missing.",
            n_no_ppp, nrow(df)
          ), type = "warning", duration = 8)
        }

        for (msg in survey_identification_notes(df)) {
          notify(msg, type = "warning", duration = 10)
        }

        publish_new_survey_data(df)

        # H3 map data (computed once per button click) ----
        h3_df <- tryCatch(
          load_data(wise_h3_fnames(ss), connection_params()),
          error = function(e) {
            notify(paste(
              "Some map data could not be loaded. Survey results are still available:",
              wise_user_error(e)
            ), type = "warning", duration = 5)
            NULL
          }
        )

        if (!is.null(h3_df)) {
          # PERF-23: the h3 lazy relation is a view over remote parquet files.
          # Every downstream scan (map GeoJSON, cell geometry, cell map,
          # loc_panel's multiple passes, loc keys) would otherwise re-read the
          # files over the network. Materialise once into a local temp table;
          # all consumers in this block then read locally. The table is dropped
          # when the block ends (everything downstream collects eagerly).
          h3_local <- tryCatch(
            {
              nm <- basename(tempfile(pattern = "ss_h3_"))
              local_h3 <- dplyr::compute(h3_df, name = nm, temporary = TRUE)
              on.exit(
                try(DBI::dbRemoveTable(dbplyr::remote_con(local_h3), nm), silent = TRUE),
                add = TRUE
              )
              local_h3
            },
            error = function(e) {
              notify(paste(
                "Map data could not be prepared locally. Survey results are still available:",
                wise_user_error(e)
              ), type = "warning", duration = 5)
              h3_df
            }
          )

          tryCatch(
            {
              .duck_load_ext("h3")

              # Location of interviews map ----
              # One row per H3 cell: the per-cell bbox the payload's fit
              # bounds come from (geometry is decoded in the browser from
              # cell ids, so no geometry string is produced server-side),
              # plus the location-to-cell mapping shared with the outcome
              # and weather maps.
              cell_geo <- h3_local |>
                dplyr::distinct(h3) |>
                .h3_cell_bbox() |>
                collect_deterministic("h3")

              cell_map <- h3_local |>
                dplyr::select(code, year, survname, loc_id, h3, pop_2020) |>
                collect_deterministic(c("code", "year", "survname", "loc_id", "h3"))

              cell_data(list(geom = cell_geo, map = cell_map))
              map_data_version(map_data_version() + 1L)
            },
            error = function(e) {
              load_ok <<- FALSE
              notify(
                paste(
                  "The sample coverage map could not be prepared. Other survey results are still available:",
                  wise_user_error(e)
                ),
                type = "warning", duration = 5
              )
            }
          )

          tryCatch(
            {
              # CR-BUG-16: duplicated panel keys error (handled below) instead
              # of multiplying survey records; unmatched records are counted.
              df <- wise_join_location_panel(df, wise_location_panel(h3_local))
              n_no_panel <- if ("loc_id_panel" %in% names(df)) sum(is.na(df$loc_id_panel)) else 0L
              if (n_no_panel > 0L) {
                notify(sprintf(
                  "%d of %d survey records have no location data and are excluded from clustered models.",
                  n_no_panel, nrow(df)
                ), type = "warning", duration = 8)
              }
              publish_new_survey_data(df)
              survey_version(survey_version() + 1L)
            },
            error = function(e) {
              # INT-06: loc_id_panel is not a cosmetic join - downstream VCV
              # estimation falls back when it is missing, which changes inference.
              load_ok <<- FALSE
              notify(paste0(
                "Location-level uncertainty estimates are unavailable, so standard ",
                "survey-design uncertainty is being used. Details: ", wise_user_error(e)
              ), type = "warning", duration = 8)
            }
          )
        } else {
          load_ok <- FALSE
        }

        if (load_ok) last_load_sig(sig)
        # H3 geometry or panel metadata can fail independently of the survey
        # frame. Preserve the existing fallback behavior and publish the usable
        # survey load so downstream stages can continue.
        load_status("success")
        completed <- TRUE

        notify(
          "Survey data loaded. Summary statistics and maps are ready.",
          type = "message", duration = 3
        )

        # Outputs (defined once on first click) ----

        if (!survey_tab_added()) {
          # Interview dates bar chart. Grouped columns keep wave totals directly
          # comparable; the archived ggplot renderer remains available under
          # dev/archive/static_plots/ for design comparisons.
          interview_date_chart <- function() {
            unit <- if (is.function(analysis_unit)) analysis_unit() else NULL
            unit_label <- switch(unit %||% "hh",
              ind = "Individuals",
              firm = "Firms",
              "Households"
            )
            echart_interview_dates(
              interview_summary(),
              unit_label = unit_label,
              palette = "sequential",
              wave_labels = survey_wave_meta()$plot_labels,
              height = "300px"
            )
          }

          output$interview_date <- echarts4r::renderEcharts4r({
            ch <- interview_date_chart()
            req(!is.null(ch))
            ch
          })

          wise_export_figure(
            key = "interview_dates",
            label = "Interview dates",
            step = 1L,
            fun = interview_date_chart,
            description = paste(
              "When the selected surveys were fielded, by month - the calendar",
              "window the weather aggregation is matched against."
            ),
            width = 9, height = 5
          )

          # Unit label for legend/tooltip text ("households", "individuals",
          # "firms"), resolved live so an analysis-unit switch re-labels.
          unit_label <- function() {
            unit <- if (is.function(analysis_unit)) analysis_unit() else NULL
            switch(unit %||% "hh",
              ind = "individuals",
              firm = "firms",
              "households"
            )
          }

          # Location of interviews payload stream ----
          # One reactive observer drives the hex map: data loads and wave
          # toggles both land here as fresh `set` payloads (cheap - cell ids
          # and values only, no geometry serialization). The camera is fitted
          # only when the data key changes (PERF-36 view-key semantics), so a
          # wave toggle re-colours in place and the user's pan/zoom survives.
          density_key <- reactiveVal(NULL)
          density_lgd <- reactiveVal(NULL)
          density_nloc <- reactiveVal(NULL)
          observe({
            cd <- cell_data()
            wave <- input$map_wave %||% "all"

            density <- if (is.null(cd)) NULL else density_cells(wave)
            pl <- if (is.null(density)) {
              NULL
            } else {
              .density_hex_payload(density$cells, unit_label())
            }
            if (is.null(pl)) {
              hexmap_clear(session, ns, "density_map")
              density_key(NULL)
              density_lgd(NULL)
              density_nloc(NULL)
            } else {
              hexmap_update(session, ns, "density_map", pl$payload)
              # PERF-36: refit only when a new map dataset has landed; wave
              # re-colours keep pan/zoom.
              if (!identical(map_data_version(), shiny::isolate(density_key()))) {
                hexmap_fit(session, ns, "density_map", pl$payload$bounds)
                density_key(map_data_version())
              }
              density_lgd(pl$legend)

              density_nloc(density$n_locations)
            }
          })

          # R-side legend: same palette state as the payloads, rebuilt per wave
          # and positioned over the map's top-right corner by hexmap_ui().
          output$map_legend_ui <- shiny::renderUI({
            lgd <- density_lgd()
            shiny::req(!is.null(lgd))
            html <- .compact_legend_html(
              pal_info = lgd$pal_info,
              binned   = lgd$binned,
              levels   = lgd$levels,
              title    = lgd$title,
              info     = lgd$info
            )
            n <- density_nloc()
            note <- if (is.null(n)) {
              ""
            } else {
              paste0(
                '<div style="white-space: nowrap; font-size: 10px; color: #333; ',
                "background: rgba(255,255,255,0.88); border-radius: 4px; ",
                'padding: 2px 5px; margin-top: 2px;">',
                "Number of unique locations: ",
                format(n, big.mark = ",", scientific = FALSE), "</div>"
              )
            }
            htmltools::HTML(paste0(html, note))
          })

          # Wave toggle slider, shown only when there is more than one wave to pick.
          output$map_wave_ui <- shiny::renderUI({
            w <- survey_wave_meta()$waves
            if (is.null(w) || nrow(w) < 2) {
              return(NULL)
            }
            choices <- wave_slider_choices(w, include_all = TRUE)
            selected <- shiny::isolate(input$map_wave) %||% "all"
            if (!selected %in% choices) selected <- "all"
            wave_toggle_slider(
              ns("map_wave"),
              choices  = choices,
              selected = selected
            )
          })

          output$outcome_stats <- make_stats_reactable(survey_data, variable_list, "outcome",
            base = stats_base
          )

          # section 6: the Outcome stats section (heading + CSV button + table) only
          # renders when the variable list flags outcome candidates, so an
          # empty survey never shows an orphaned "Download CSV" control.
          output$outcome_stats_section_ui <- renderUI({
            vl <- if (is.function(variable_list)) variable_list() else variable_list
            has_outcome <- !is.null(vl) && !is.null(vl[["outcome"]]) &&
              any(vl[["outcome"]] == 1, na.rm = TRUE)
            if (!has_outcome) {
              return(NULL)
            }
            shiny::tagList(
              h4(
                "Outcome stats",
                info_popover(
                  title = "Outcome stats",
                  p(paste(
                    "Candidate outcome variables available for welfare",
                    "analysis in Step 1. Check the missingness column",
                    "before selecting an outcome - high missingness can",
                    "limit sample size after listwise deletion."
                  ))
                )
              ),
              p(class = "text-muted small", "Candidate outcome variables for welfare analysis"),
              shiny::tags$div(
                class = "wise-reactable-controls",
                wise_reactable_csv_button(ns("outcome_stats"), "survey_summary_outcome")
              ),
              reactable::reactableOutput(ns("outcome_stats"))
            )
          })
          output$ind_stats <- make_stats_reactable(survey_data, variable_list, "ind",
            base = stats_base
          )
          output$hh_stats <- make_stats_reactable(survey_data, variable_list, "hh",
            base = stats_base
          )
          output$firm_stats <- make_stats_reactable(survey_data, variable_list, "firm",
            base = stats_base
          )
          output$area_stats <- make_stats_reactable(survey_data, variable_list, "area",
            base = stats_base
          )

          # UI-48: register the same builders with the export bundle. Nothing is
          # computed here - the functions are called only if a bundle is asked
          # for, and return NULL for a level the survey has no variables at.
          local({
            levels <- list(
              outcome = "Outcome variables",
              ind     = "Individual-level variables",
              hh      = "Household-level variables",
              firm    = "Firm-level variables",
              area    = "Area-level variables"
            )
            for (flag in names(levels)) {
              local({
                f <- flag
                wise_export_table(
                  key = paste0("survey_summary_", f),
                  label = paste("Survey summary -", tolower(levels[[f]])),
                  step = 1L,
                  fun = function() {
                    build_stats_table(survey_data, variable_list, f,
                      base = stats_base
                    )
                  },
                  description = paste0(
                    "Weighted summary statistics (N, mean, SD, percentiles, % ",
                    "missing) for ", tolower(levels[[f]]),
                    ", by country and survey wave."
                  )
                )
              })
            }
          })

          # Only show characteristic tables relevant to the selected level of
          # analysis: individual level implies household + area also apply;
          # household level implies area also applies; firm level is separate.
          # Each table carries its client-side CSV download button (section 6).
          output$characteristic_tables_ui <- renderUI({
            unit <- if (is.function(analysis_unit)) analysis_unit() else NULL
            show_ind <- is.null(unit) || unit == "ind"
            show_hh <- is.null(unit) || unit %in% c("ind", "hh")
            show_firm <- is.null(unit) || unit == "firm"

            tagList(
              if (show_ind) {
                tagList(
                  h4("Individual characteristics"),
                  p(class = "text-muted small", "Summary statistics for individual-level variables"),
                  shiny::tags$div(
                    class = "wise-reactable-controls",
                    wise_reactable_csv_button(ns("ind_stats"), "survey_summary_ind")
                  ),
                  reactable::reactableOutput(ns("ind_stats"))
                )
              },
              if (show_hh) {
                tagList(
                  h4("Household characteristics"),
                  p(class = "text-muted small", "Summary statistics for household-level variables"),
                  shiny::tags$div(
                    class = "wise-reactable-controls",
                    wise_reactable_csv_button(ns("hh_stats"), "survey_summary_hh")
                  ),
                  reactable::reactableOutput(ns("hh_stats"))
                )
              },
              if (show_firm) {
                tagList(
                  h4("Firm characteristics"),
                  p(class = "text-muted small", "Summary statistics for firm-level variables"),
                  shiny::tags$div(
                    class = "wise-reactable-controls",
                    wise_reactable_csv_button(ns("firm_stats"), "survey_summary_firm")
                  ),
                  reactable::reactableOutput(ns("firm_stats"))
                )
              },
              h4("Area characteristics"),
              p(class = "text-muted small", "Summary statistics for area-level variables"),
              shiny::tags$div(
                class = "wise-reactable-controls",
                wise_reactable_csv_button(ns("area_stats"), "survey_summary_area")
              ),
              reactable::reactableOutput(ns("area_stats"))
            )
          })

          # Selection summary card (replaces the old DT table) ----
          # Binds live to selected_surveys()/analysis_unit() so the card follows
          # the sidebar selection.

          wise_export_table(
            key = "survey_summary_policy",
            label = "Survey summary - policy-relevant variables",
            step = 1L,
            fun = function() {
              build_stats_table(survey_data, variable_list,
                vars = policy_vars,
                base = stats_base
              )
            },
            description = paste(
              "Weighted summary statistics for the variables that Step 3's",
              "policy levers act on, by country and survey wave."
            )
          )

          selected_surveys_df <- function() {
            sel <- selected_surveys()
            if (is.null(sel)) {
              return(NULL)
            }
            sel |> dplyr::select(-dplyr::any_of(c("fname", "fpath")))
          }

          wise_export_table(
            key = "selected_surveys",
            label = "Selected surveys",
            step = 1L,
            fun = selected_surveys_df,
            description = paste(
              "The survey rounds included in the analysis: country, year,",
              "survey name and sample metadata."
            )
          )

          output$selected_surveys_card <- renderUI({
            ss <- selected_surveys()
            req(nrow(ss) > 0)
            sd <- survey_data()
            req(!is.null(sd))

            unit <- if (is.function(analysis_unit)) analysis_unit() else NULL
            badge <- analysis_unit_label(unit) %||%
              analysis_unit_label(unique(ss$level)[1])
            sample_n <- paste0("N = ", format(nrow(sd), big.mark = ",", scientific = FALSE))
            badge <- paste(c(badge, sample_n), collapse = " | ")

            econ_rows <- lapply(
              sort(unique(ss$code)),
              function(code) {
                s <- ss[ss$code == code, ]
                programs <- sort(unique(s$survname))
                selection_card_row(
                  name  = as.character(s$economy[1]),
                  sub   = if (length(programs)) paste(programs, collapse = " / "),
                  pills = as.character(sort(unique(s$year)))
                )
              }
            )

            selection_summary_card(
              title = "Selected sample",
              rows  = econ_rows,
              badge = badge
            )
          })

          output$policy_stats <- make_stats_reactable(survey_data, variable_list,
            vars = policy_vars,
            base = stats_base
          )

          # Outcome summary moved to the Outcome stats tab's selection card ----

          # Append Survey stats tab to parent tabset
          tryCatch(
            shiny::appendTab(
              inputId = tabset_id,
              shiny::tabPanel(
                title = "Survey stats",
                value = "desc_stats",
                uiOutput(ns("selected_surveys_card")),
                bslib::layout_columns(
                  col_widths = c(6, 6),
                  # gap = 0: bslib's default body gap would otherwise put
                  # 24px between the heading and the plot; the heading's own
                  # margin is the spacing that remains.
                  bslib::card(
                    bslib::card_body(
                      gap = 0,
                      h4(
                        "Timing of interviews",
                        class = "mb-2",
                        info_popover(
                          title = "Timing of interviews",
                          p("Monthly breakdown of interview waves.")
                        )
                      ),
                      wise_chart_output(ns("interview_date"),
                        "Bar chart of the distribution of interview dates across the selected surveys",
                        height = "300px"
                      )
                    )
                  ),
                  # Pairing a definite card height with a 100%-height map is what
                  # lets the map fill the card in both the normal and the
                  # expanded state; a fixed pixel height would stay small when
                  # the card fans out. The title shares one row with the wave
                  # toggle so the map keeps as much of the card as possible,
                  # expanded or not.
                  bslib::card(
                    full_screen = TRUE,
                    height = "400px",
                    # The explicit card_body with gap = 0: bslib's default body
                    # gap would otherwise put 24px between the controls row and
                    # the map; the controls' own mb-2 is the spacing that
                    # remains.
                    bslib::card_body(
                      gap = 0,
                      shiny::div(
                        class = paste(
                          "d-flex align-items-center",
                          "justify-content-between flex-wrap gap-2 mb-2"
                        ),
                        h4(
                          "Location of interviews",
                          class = "mb-0",
                          info_popover(
                            title = "Location of interviews",
                            p(paste(
                              "Geographic distribution of sampled interviews.",
                              "Each hexagon is an H3 cell shaded by how many",
                              "sampled units fall in it; cells tile without",
                              "overlapping, so dense areas read directly off the",
                              "colour. Pick the survey wave on the right."
                            ))
                          )
                        ),
                        shiny::uiOutput(ns("map_wave_ui"), inline = TRUE)
                      ),
                      # The MapLibre hex map. hexmap_ui() is placed directly in
                      # the card (no renderUI): the container persists for the
                      # session and the payload observer drives everything.
                      hexmap_ui(
                        ns("density_map"),
                        height = "100%",
                        aria_label = paste0(
                          "Map of sample density: number of sampled units ",
                          "per hexagonal area cell"
                        ),
                        legend = shiny::uiOutput(ns("map_legend_ui"))
                      ) |>
                        bslib::as_fill_carrier()
                    )
                  )
                ),
                shiny::uiOutput(ns("outcome_stats_section_ui")),
                h4("Policy variables"),
                p(class = "text-muted small", "Variables that can be adjusted in Step 3 policy scenarios"),
                shiny::tags$div(
                  class = "wise-reactable-controls",
                  wise_reactable_csv_button(ns("policy_stats"), "survey_summary_policy")
                ),
                reactable::reactableOutput(ns("policy_stats")),
                uiOutput(ns("characteristic_tables_ui"))
              ),
              select = TRUE,
              session = tabset_session
            ),
            error = function(e) {
              notify(wise_user_error(e, "Adding the Survey stats tab"), type = "error")
            }
          )

          survey_tab_added(TRUE)
        }

        if (survey_tab_added()) select_tab("desc_stats")
      },
      ignoreInit = TRUE,
      ignoreNULL = TRUE
    )

    # Return API ----

    list(
      survey_data = survey_data,
      cell_data = cell_data,
      survey_version = survey_version,
      survey_data_generation = survey_data_generation,
      load_done = load_done,
      load_status = load_status
    )
  })
}

#' Per-cell bounding box of H3 cells, computed with the h3 extension only.
#'
#' R2-PERF-14: the bbox used to come from the `spatial` extension
#' (`st_extent(st_geomfromtext(h3_cell_to_boundary_wkt(h3)))`), which cost a
#' 1.5 s extension load per process for this one query. The same boundary WKT
#' ("POLYGON ((lng lat, lng lat, ...))") is parsed here with DuckDB string
#' functions, so the min/max are taken over exactly the same vertex
#' coordinates.
#'
#' @param cells Lazy DuckDB table with an `h3` column (cell id string).
#' @return Lazy table with `h3`, `xmin`, `ymin`, `xmax`, `ymax`.
#' @noRd
.h3_cell_bbox <- function(cells) {
  cells |>
    dplyr::mutate(wkt = dplyr::sql("h3_cell_to_boundary_wkt(h3)")) |>
    dplyr::mutate(
      lng = dplyr::sql(
        "CAST(regexp_extract_all(wkt, '(-?[0-9.]+) -?[0-9.]+', 1) AS DOUBLE[])"
      ),
      lat = dplyr::sql(
        "CAST(regexp_extract_all(wkt, '-?[0-9.]+ (-?[0-9.]+)', 1) AS DOUBLE[])"
      )
    ) |>
    dplyr::transmute(
      h3,
      xmin = dplyr::sql("list_min(lng)"), ymin = dplyr::sql("list_min(lat)"),
      xmax = dplyr::sql("list_max(lng)"), ymax = dplyr::sql("list_max(lat)")
    )
}
